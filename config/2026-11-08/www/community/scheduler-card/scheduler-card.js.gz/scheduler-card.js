var SchedulerCard=function(e){"use strict";function t(e,t,i,s){var a,o=arguments.length,n=o<3?t:null===s?s=Object.getOwnPropertyDescriptor(t,i):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,s);else for(var r=e.length-1;r>=0;r--)(a=e[r])&&(n=(o<3?a(n):o>3?a(t,i,n):a(t,i))||n);return o>3&&n&&Object.defineProperty(t,i,n),n}"function"==typeof SuppressedError&&SuppressedError;
/**
     * @license
     * Copyright 2019 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
const i=window,s=i.ShadowRoot&&(void 0===i.ShadyCSS||i.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,a=Symbol(),o=new WeakMap;let n=class{constructor(e,t,i){if(this._$cssResult$=!0,i!==a)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o;const t=this.t;if(s&&void 0===e){const i=void 0!==t&&1===t.length;i&&(e=o.get(t)),void 0===e&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),i&&o.set(t,e))}return e}toString(){return this.cssText}};const r=(e,...t)=>{const i=1===e.length?e[0]:t.reduce((t,i,s)=>t+(e=>{if(!0===e._$cssResult$)return e.cssText;if("number"==typeof e)return e;throw Error("Value passed to 'css' function must be a 'css' function result: "+e+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(i)+e[s+1],e[0]);return new n(i,e,a)},d=s?e=>e:e=>e instanceof CSSStyleSheet?(e=>{let t="";for(const i of e.cssRules)t+=i.cssText;return(e=>new n("string"==typeof e?e:e+"",void 0,a))(t)})(e):e;
/**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */var l;const c=window,u=c.trustedTypes,h=u?u.emptyScript:"",m=c.reactiveElementPolyfillSupport,p={toAttribute(e,t){switch(t){case Boolean:e=e?h:null;break;case Object:case Array:e=null==e?e:JSON.stringify(e)}return e},fromAttribute(e,t){let i=e;switch(t){case Boolean:i=null!==e;break;case Number:i=null===e?null:Number(e);break;case Object:case Array:try{i=JSON.parse(e)}catch(e){i=null}}return i}},_=(e,t)=>t!==e&&(t==t||e==e),g={attribute:!0,type:String,converter:p,reflect:!1,hasChanged:_},v="finalized";let y=class extends HTMLElement{constructor(){super(),this._$Ei=new Map,this.isUpdatePending=!1,this.hasUpdated=!1,this._$El=null,this._$Eu()}static addInitializer(e){var t;this.finalize(),(null!==(t=this.h)&&void 0!==t?t:this.h=[]).push(e)}static get observedAttributes(){this.finalize();const e=[];return this.elementProperties.forEach((t,i)=>{const s=this._$Ep(i,t);void 0!==s&&(this._$Ev.set(s,i),e.push(s))}),e}static createProperty(e,t=g){if(t.state&&(t.attribute=!1),this.finalize(),this.elementProperties.set(e,t),!t.noAccessor&&!this.prototype.hasOwnProperty(e)){const i="symbol"==typeof e?Symbol():"__"+e,s=this.getPropertyDescriptor(e,i,t);void 0!==s&&Object.defineProperty(this.prototype,e,s)}}static getPropertyDescriptor(e,t,i){return{get(){return this[t]},set(s){const a=this[e];this[t]=s,this.requestUpdate(e,a,i)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)||g}static finalize(){if(this.hasOwnProperty(v))return!1;this[v]=!0;const e=Object.getPrototypeOf(this);if(e.finalize(),void 0!==e.h&&(this.h=[...e.h]),this.elementProperties=new Map(e.elementProperties),this._$Ev=new Map,this.hasOwnProperty("properties")){const e=this.properties,t=[...Object.getOwnPropertyNames(e),...Object.getOwnPropertySymbols(e)];for(const i of t)this.createProperty(i,e[i])}return this.elementStyles=this.finalizeStyles(this.styles),!0}static finalizeStyles(e){const t=[];if(Array.isArray(e)){const i=new Set(e.flat(1/0).reverse());for(const e of i)t.unshift(d(e))}else void 0!==e&&t.push(d(e));return t}static _$Ep(e,t){const i=t.attribute;return!1===i?void 0:"string"==typeof i?i:"string"==typeof e?e.toLowerCase():void 0}_$Eu(){var e;this._$E_=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$Eg(),this.requestUpdate(),null===(e=this.constructor.h)||void 0===e||e.forEach(e=>e(this))}addController(e){var t,i;(null!==(t=this._$ES)&&void 0!==t?t:this._$ES=[]).push(e),void 0!==this.renderRoot&&this.isConnected&&(null===(i=e.hostConnected)||void 0===i||i.call(e))}removeController(e){var t;null===(t=this._$ES)||void 0===t||t.splice(this._$ES.indexOf(e)>>>0,1)}_$Eg(){this.constructor.elementProperties.forEach((e,t)=>{this.hasOwnProperty(t)&&(this._$Ei.set(t,this[t]),delete this[t])})}createRenderRoot(){var e;const t=null!==(e=this.shadowRoot)&&void 0!==e?e:this.attachShadow(this.constructor.shadowRootOptions);return((e,t)=>{s?e.adoptedStyleSheets=t.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet):t.forEach(t=>{const s=document.createElement("style"),a=i.litNonce;void 0!==a&&s.setAttribute("nonce",a),s.textContent=t.cssText,e.appendChild(s)})})(t,this.constructor.elementStyles),t}connectedCallback(){var e;void 0===this.renderRoot&&(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),null===(e=this._$ES)||void 0===e||e.forEach(e=>{var t;return null===(t=e.hostConnected)||void 0===t?void 0:t.call(e)})}enableUpdating(e){}disconnectedCallback(){var e;null===(e=this._$ES)||void 0===e||e.forEach(e=>{var t;return null===(t=e.hostDisconnected)||void 0===t?void 0:t.call(e)})}attributeChangedCallback(e,t,i){this._$AK(e,i)}_$EO(e,t,i=g){var s;const a=this.constructor._$Ep(e,i);if(void 0!==a&&!0===i.reflect){const o=(void 0!==(null===(s=i.converter)||void 0===s?void 0:s.toAttribute)?i.converter:p).toAttribute(t,i.type);this._$El=e,null==o?this.removeAttribute(a):this.setAttribute(a,o),this._$El=null}}_$AK(e,t){var i;const s=this.constructor,a=s._$Ev.get(e);if(void 0!==a&&this._$El!==a){const e=s.getPropertyOptions(a),o="function"==typeof e.converter?{fromAttribute:e.converter}:void 0!==(null===(i=e.converter)||void 0===i?void 0:i.fromAttribute)?e.converter:p;this._$El=a,this[a]=o.fromAttribute(t,e.type),this._$El=null}}requestUpdate(e,t,i){let s=!0;void 0!==e&&(((i=i||this.constructor.getPropertyOptions(e)).hasChanged||_)(this[e],t)?(this._$AL.has(e)||this._$AL.set(e,t),!0===i.reflect&&this._$El!==e&&(void 0===this._$EC&&(this._$EC=new Map),this._$EC.set(e,i))):s=!1),!this.isUpdatePending&&s&&(this._$E_=this._$Ej())}async _$Ej(){this.isUpdatePending=!0;try{await this._$E_}catch(e){Promise.reject(e)}const e=this.scheduleUpdate();return null!=e&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){var e;if(!this.isUpdatePending)return;this.hasUpdated,this._$Ei&&(this._$Ei.forEach((e,t)=>this[t]=e),this._$Ei=void 0);let t=!1;const i=this._$AL;try{t=this.shouldUpdate(i),t?(this.willUpdate(i),null===(e=this._$ES)||void 0===e||e.forEach(e=>{var t;return null===(t=e.hostUpdate)||void 0===t?void 0:t.call(e)}),this.update(i)):this._$Ek()}catch(e){throw t=!1,this._$Ek(),e}t&&this._$AE(i)}willUpdate(e){}_$AE(e){var t;null===(t=this._$ES)||void 0===t||t.forEach(e=>{var t;return null===(t=e.hostUpdated)||void 0===t?void 0:t.call(e)}),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$Ek(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$E_}shouldUpdate(e){return!0}update(e){void 0!==this._$EC&&(this._$EC.forEach((e,t)=>this._$EO(t,this[t],e)),this._$EC=void 0),this._$Ek()}updated(e){}firstUpdated(e){}};
/**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
var f;y[v]=!0,y.elementProperties=new Map,y.elementStyles=[],y.shadowRootOptions={mode:"open"},null==m||m({ReactiveElement:y}),(null!==(l=c.reactiveElementVersions)&&void 0!==l?l:c.reactiveElementVersions=[]).push("1.6.3");const b=window,w=b.trustedTypes,k=w?w.createPolicy("lit-html",{createHTML:e=>e}):void 0,x="$lit$",$=`lit$${(Math.random()+"").slice(9)}$`,j="?"+$,O=`<${j}>`,S=document,z=()=>S.createComment(""),C=e=>null===e||"object"!=typeof e&&"function"!=typeof e,A=Array.isArray,E="[ \t\n\f\r]",T=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,D=/-->/g,M=/>/g,L=RegExp(`>|${E}(?:([^\\s"'>=/]+)(${E}*=${E}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,"g"),N=/'/g,P=/"/g,I=/^(?:script|style|textarea|title)$/i,q=(e=>(t,...i)=>({_$litType$:e,strings:t,values:i}))(1),R=Symbol.for("lit-noChange"),V=Symbol.for("lit-nothing"),H=new WeakMap,U=S.createTreeWalker(S,129,null,!1);function F(e,t){if(!Array.isArray(e)||!e.hasOwnProperty("raw"))throw Error("invalid template strings array");return void 0!==k?k.createHTML(t):t}const B=(e,t)=>{const i=e.length-1,s=[];let a,o=2===t?"<svg>":"",n=T;for(let t=0;t<i;t++){const i=e[t];let r,d,l=-1,c=0;for(;c<i.length&&(n.lastIndex=c,d=n.exec(i),null!==d);)c=n.lastIndex,n===T?"!--"===d[1]?n=D:void 0!==d[1]?n=M:void 0!==d[2]?(I.test(d[2])&&(a=RegExp("</"+d[2],"g")),n=L):void 0!==d[3]&&(n=L):n===L?">"===d[0]?(n=null!=a?a:T,l=-1):void 0===d[1]?l=-2:(l=n.lastIndex-d[2].length,r=d[1],n=void 0===d[3]?L:'"'===d[3]?P:N):n===P||n===N?n=L:n===D||n===M?n=T:(n=L,a=void 0);const u=n===L&&e[t+1].startsWith("/>")?" ":"";o+=n===T?i+O:l>=0?(s.push(r),i.slice(0,l)+x+i.slice(l)+$+u):i+$+(-2===l?(s.push(void 0),t):u)}return[F(e,o+(e[i]||"<?>")+(2===t?"</svg>":"")),s]};class W{constructor({strings:e,_$litType$:t},i){let s;this.parts=[];let a=0,o=0;const n=e.length-1,r=this.parts,[d,l]=B(e,t);if(this.el=W.createElement(d,i),U.currentNode=this.el.content,2===t){const e=this.el.content,t=e.firstChild;t.remove(),e.append(...t.childNodes)}for(;null!==(s=U.nextNode())&&r.length<n;){if(1===s.nodeType){if(s.hasAttributes()){const e=[];for(const t of s.getAttributeNames())if(t.endsWith(x)||t.startsWith($)){const i=l[o++];if(e.push(t),void 0!==i){const e=s.getAttribute(i.toLowerCase()+x).split($),t=/([.?@])?(.*)/.exec(i);r.push({type:1,index:a,name:t[2],strings:e,ctor:"."===t[1]?Y:"?"===t[1]?X:"@"===t[1]?ee:J})}else r.push({type:6,index:a})}for(const t of e)s.removeAttribute(t)}if(I.test(s.tagName)){const e=s.textContent.split($),t=e.length-1;if(t>0){s.textContent=w?w.emptyScript:"";for(let i=0;i<t;i++)s.append(e[i],z()),U.nextNode(),r.push({type:2,index:++a});s.append(e[t],z())}}}else if(8===s.nodeType)if(s.data===j)r.push({type:2,index:a});else{let e=-1;for(;-1!==(e=s.data.indexOf($,e+1));)r.push({type:7,index:a}),e+=$.length-1}a++}}static createElement(e,t){const i=S.createElement("template");return i.innerHTML=e,i}}function Z(e,t,i=e,s){var a,o,n,r;if(t===R)return t;let d=void 0!==s?null===(a=i._$Co)||void 0===a?void 0:a[s]:i._$Cl;const l=C(t)?void 0:t._$litDirective$;return(null==d?void 0:d.constructor)!==l&&(null===(o=null==d?void 0:d._$AO)||void 0===o||o.call(d,!1),void 0===l?d=void 0:(d=new l(e),d._$AT(e,i,s)),void 0!==s?(null!==(n=(r=i)._$Co)&&void 0!==n?n:r._$Co=[])[s]=d:i._$Cl=d),void 0!==d&&(t=Z(e,d._$AS(e,t.values),d,s)),t}class K{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){var t;const{el:{content:i},parts:s}=this._$AD,a=(null!==(t=null==e?void 0:e.creationScope)&&void 0!==t?t:S).importNode(i,!0);U.currentNode=a;let o=U.nextNode(),n=0,r=0,d=s[0];for(;void 0!==d;){if(n===d.index){let t;2===d.type?t=new G(o,o.nextSibling,this,e):1===d.type?t=new d.ctor(o,d.name,d.strings,this,e):6===d.type&&(t=new te(o,this,e)),this._$AV.push(t),d=s[++r]}n!==(null==d?void 0:d.index)&&(o=U.nextNode(),n++)}return U.currentNode=S,a}v(e){let t=0;for(const i of this._$AV)void 0!==i&&(void 0!==i.strings?(i._$AI(e,i,t),t+=i.strings.length-2):i._$AI(e[t])),t++}}class G{constructor(e,t,i,s){var a;this.type=2,this._$AH=V,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=i,this.options=s,this._$Cp=null===(a=null==s?void 0:s.isConnected)||void 0===a||a}get _$AU(){var e,t;return null!==(t=null===(e=this._$AM)||void 0===e?void 0:e._$AU)&&void 0!==t?t:this._$Cp}get parentNode(){let e=this._$AA.parentNode;const t=this._$AM;return void 0!==t&&11===(null==e?void 0:e.nodeType)&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=Z(this,e,t),C(e)?e===V||null==e||""===e?(this._$AH!==V&&this._$AR(),this._$AH=V):e!==this._$AH&&e!==R&&this._(e):void 0!==e._$litType$?this.g(e):void 0!==e.nodeType?this.$(e):(e=>A(e)||"function"==typeof(null==e?void 0:e[Symbol.iterator]))(e)?this.T(e):this._(e)}k(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}$(e){this._$AH!==e&&(this._$AR(),this._$AH=this.k(e))}_(e){this._$AH!==V&&C(this._$AH)?this._$AA.nextSibling.data=e:this.$(S.createTextNode(e)),this._$AH=e}g(e){var t;const{values:i,_$litType$:s}=e,a="number"==typeof s?this._$AC(e):(void 0===s.el&&(s.el=W.createElement(F(s.h,s.h[0]),this.options)),s);if((null===(t=this._$AH)||void 0===t?void 0:t._$AD)===a)this._$AH.v(i);else{const e=new K(a,this),t=e.u(this.options);e.v(i),this.$(t),this._$AH=e}}_$AC(e){let t=H.get(e.strings);return void 0===t&&H.set(e.strings,t=new W(e)),t}T(e){A(this._$AH)||(this._$AH=[],this._$AR());const t=this._$AH;let i,s=0;for(const a of e)s===t.length?t.push(i=new G(this.k(z()),this.k(z()),this,this.options)):i=t[s],i._$AI(a),s++;s<t.length&&(this._$AR(i&&i._$AB.nextSibling,s),t.length=s)}_$AR(e=this._$AA.nextSibling,t){var i;for(null===(i=this._$AP)||void 0===i||i.call(this,!1,!0,t);e&&e!==this._$AB;){const t=e.nextSibling;e.remove(),e=t}}setConnected(e){var t;void 0===this._$AM&&(this._$Cp=e,null===(t=this._$AP)||void 0===t||t.call(this,e))}}class J{constructor(e,t,i,s,a){this.type=1,this._$AH=V,this._$AN=void 0,this.element=e,this.name=t,this._$AM=s,this.options=a,i.length>2||""!==i[0]||""!==i[1]?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=V}get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}_$AI(e,t=this,i,s){const a=this.strings;let o=!1;if(void 0===a)e=Z(this,e,t,0),o=!C(e)||e!==this._$AH&&e!==R,o&&(this._$AH=e);else{const s=e;let n,r;for(e=a[0],n=0;n<a.length-1;n++)r=Z(this,s[i+n],t,n),r===R&&(r=this._$AH[n]),o||(o=!C(r)||r!==this._$AH[n]),r===V?e=V:e!==V&&(e+=(null!=r?r:"")+a[n+1]),this._$AH[n]=r}o&&!s&&this.j(e)}j(e){e===V?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,null!=e?e:"")}}class Y extends J{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===V?void 0:e}}const Q=w?w.emptyScript:"";class X extends J{constructor(){super(...arguments),this.type=4}j(e){e&&e!==V?this.element.setAttribute(this.name,Q):this.element.removeAttribute(this.name)}}class ee extends J{constructor(e,t,i,s,a){super(e,t,i,s,a),this.type=5}_$AI(e,t=this){var i;if((e=null!==(i=Z(this,e,t,0))&&void 0!==i?i:V)===R)return;const s=this._$AH,a=e===V&&s!==V||e.capture!==s.capture||e.once!==s.once||e.passive!==s.passive,o=e!==V&&(s===V||a);a&&this.element.removeEventListener(this.name,this,s),o&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){var t,i;"function"==typeof this._$AH?this._$AH.call(null!==(i=null===(t=this.options)||void 0===t?void 0:t.host)&&void 0!==i?i:this.element,e):this._$AH.handleEvent(e)}}class te{constructor(e,t,i){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(e){Z(this,e)}}const ie=b.litHtmlPolyfillSupport;null==ie||ie(W,G),(null!==(f=b.litHtmlVersions)&&void 0!==f?f:b.litHtmlVersions=[]).push("2.8.0");
/**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
var se,ae;class oe extends y{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){var e,t;const i=super.createRenderRoot();return null!==(e=(t=this.renderOptions).renderBefore)&&void 0!==e||(t.renderBefore=i.firstChild),i}update(e){const t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=((e,t,i)=>{var s,a;const o=null!==(s=null==i?void 0:i.renderBefore)&&void 0!==s?s:t;let n=o._$litPart$;if(void 0===n){const e=null!==(a=null==i?void 0:i.renderBefore)&&void 0!==a?a:null;o._$litPart$=n=new G(t.insertBefore(z(),e),e,void 0,null!=i?i:{})}return n._$AI(e),n})(t,this.renderRoot,this.renderOptions)}connectedCallback(){var e;super.connectedCallback(),null===(e=this._$Do)||void 0===e||e.setConnected(!0)}disconnectedCallback(){var e;super.disconnectedCallback(),null===(e=this._$Do)||void 0===e||e.setConnected(!1)}render(){return R}}oe.finalized=!0,oe._$litElement$=!0,null===(se=globalThis.litElementHydrateSupport)||void 0===se||se.call(globalThis,{LitElement:oe});const ne=globalThis.litElementPolyfillSupport;null==ne||ne({LitElement:oe}),(null!==(ae=globalThis.litElementVersions)&&void 0!==ae?ae:globalThis.litElementVersions=[]).push("3.3.3");const re=e=>t=>"function"==typeof t?((e,t)=>(customElements.define(e,t),t))(e,t):((e,t)=>{const{kind:i,elements:s}=t;return{kind:i,elements:s,finisher(t){customElements.define(e,t)}}})(e,t),de=(e,t)=>"method"===t.kind&&t.descriptor&&!("value"in t.descriptor)?{...t,finisher(i){i.createProperty(t.key,e)}}:{kind:"field",key:Symbol(),placement:"own",descriptor:{},originalKey:t.key,initializer(){"function"==typeof t.initializer&&(this[t.key]=t.initializer.call(this))},finisher(i){i.createProperty(t.key,e)}};
/**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */function le(e){return(t,i)=>void 0!==i?((e,t,i)=>{t.constructor.createProperty(i,e)})(e,t,i):de(e,t)}
/**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */function ce(e){return le({...e,state:!0})}
/**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */var ue;null===(ue=window.HTMLSlotElement)||void 0===ue||ue.prototype.assignedElements;const he=(e,t)=>{if(typeof e!=typeof t)return!1;if("object"==typeof e&&"object"==typeof t&&null!==e&&null!==t){const i=[...new Set([...Object.keys(e),...Object.keys(t)])];return!!i.every(i=>Object.keys(e).includes(i)&&Object.keys(t).includes(i))&&i.every(i=>he(e[i],t[i]))}return e===t};var me,pe,_e,ge,ve,ye,fe,be;!function(e){e.Single="single",e.Scheme="scheme"}(me||(me={})),function(e){e.Daily="daily",e.Workday="workday",e.Weekend="weekend",e.Monday="monday",e.Tuesday="tuesday",e.Wednesday="wednesday",e.Thursday="thursday",e.Friday="friday",e.Saturday="saturday",e.Sunday="sunday"}(pe||(pe={})),function(e){e.Or="or",e.And="and"}(_e||(_e={})),function(e){e.Equal="is",e.Unequal="not",e.Below="below",e.Above="above"}(ge||(ge={})),function(e){e.Name="name",e.RelativeTime="relative-time",e.AdditionalTasks="additional-tasks",e.Time="time",e.Days="days",e.Entity="entity",e.Action="action",e.Tags="tags",e.Default="default"}(ve||(ve={})),function(e){e.ItemCreated="scheduler_item_created",e.ItemUpdated="scheduler_item_updated",e.ItemRemoved="scheduler_item_removed",e.TimerFinished="scheduler_timer_finished",e.TimerUpdated="scheduler_timer_updated"}(ye||(ye={})),function(e){e.Repeat="repeat",e.Pause="pause",e.Single="single"}(fe||(fe={})),function(e){e.Fixed="fixed",e.Sunrise="sunrise",e.Sunset="sunset"}(be||(be={}));const we=e=>({service:e.service,service_data:e.service_data,target:{entity_id:e.entity_id?e.entity_id:void 0}}),ke=e=>({start:e.start,stop:e.stop,actions:je(e.actions.map(we)),conditions:{type:"and"==e.condition_type?_e.And:_e.Or,items:e.conditions||[],track_changes:Boolean(e.track_conditions)}}),xe=e=>{switch(e){case"mon":return pe.Monday;case"tue":return pe.Tuesday;case"wed":return pe.Wednesday;case"thu":return pe.Thursday;case"fri":return pe.Friday;case"sat":return pe.Saturday;case"sun":return pe.Sunday;case"workday":return pe.Workday;case"weekend":return pe.Weekend;default:return pe.Daily}},$e=e=>Object.assign(Object.assign({},Object.fromEntries(Object.entries(e).filter(([e])=>!["slots","weekdays",""].includes(e)))),{entries:[{slots:e.timeslots.map(ke),weekdays:e.weekdays.map(xe)}]}),je=e=>{if(1==e.length)return e;if(e.every(t=>he(Object.assign(Object.assign({},t),{target:void 0}),Object.assign(Object.assign({},e[0]),{target:void 0})))){const t=[...new Set(e.map(e=>{var t;return null===(t=e.target)||void 0===t?void 0:t.entity_id}).filter(e=>void 0!==e))];return[Object.assign(Object.assign({},e[0]),{target:{entity_id:t.length?t:void 0}})]}return e},Oe=e=>e.callWS({type:"scheduler"}).then(e=>e.map($e)),Se=(e,t)=>{let i=t.hours||0,s=t.minutes||0;(i<0||s<0)&&(i=-Math.abs(i),s=-Math.abs(s));let a=e.hours,o=e.minutes;return a<0&&o>0&&(o=-o),a+=i,o+=s,o>=60||o>0&&a<0&&e.mode!=be.Fixed?(a+=1,o-=60):(o<=-60||o<0&&e.mode==be.Fixed||o<0&&a>0&&e.mode!=be.Fixed)&&(a-=1,o+=60),a<0&&e.mode==be.Fixed?a+=24:a>=24&&e.mode==be.Fixed&&(a-=24),{mode:e.mode,hours:a,minutes:o}},ze=(e,t=1)=>{let i=3600*Math.abs(e.hours)+60*Math.abs(e.minutes)+(e.seconds||0);const s=e.hours<0||e.minutes<0?-1:1;let a=Math.floor(i/3600),o=Math.round((i-3600*a)/60);return o%t!=0&&(o=Math.round(o/t)*t),o>=60&&(a++,o-=60),s<0&&(a>0?a=-a:o=-o),Object.assign(Object.assign({},e),{hours:a,minutes:o})},Ce=e=>{if(e.match(/^([0-9:]+)$/)){const t=e.split(":").map(Number),i=ze({hours:t[0],minutes:t[1],seconds:t[2]});return{mode:be.Fixed,hours:i.hours,minutes:i.minutes}}const t=e.match(/^([a-z]+)([\+|-]{1})([0-9:]+)$/);if(t){let e=t[3].split(":").map(Number);const i=ze({hours:e[0],minutes:e[1],seconds:e[2]});let s=i.hours,a=i.minutes;return"-"==t[2]&&(s>0&&(s=-s),a=-a),{mode:"sunrise"==t[1]?be.Sunrise:be.Sunset,hours:s,minutes:a}}const i=new Date(e),s=ze({hours:i.getHours(),minutes:i.getMinutes(),seconds:i.getSeconds()});return{mode:be.Fixed,hours:s.hours,minutes:s.minutes}},Ae=(e,t)=>{if("string"==typeof e&&(e=Ce(e)),e.mode==be.Fixed)return 3600*e.hours+60*e.minutes;if(e.mode==be.Sunrise){const i=Ce(t.states["sun.sun"].attributes.next_rising),s=Se(i,e);return 3600*s.hours+60*s.minutes}{const i=Ce(t.states["sun.sun"].attributes.next_setting),s=Se(i,e);return 3600*s.hours+60*s.minutes}};var Ee,Te,De;!function(e){e.language="language",e.system="system",e.comma_decimal="comma_decimal",e.decimal_comma="decimal_comma",e.space_comma="space_comma",e.none="none"}(Ee||(Ee={})),function(e){e.language="language",e.system="system",e.am_pm="12",e.twenty_four="24"}(Te||(Te={})),function(e){e.local="local",e.server="server"}(De||(De={}));const Me=e=>{if(e.time_format===Te.language||e.time_format===Te.system){const t=e.time_format===Te.language?e.language:void 0;return new Date("January 1, 2023 22:00:00").toLocaleString(t).includes("10")}return e.time_format===Te.am_pm};var Le;!function(e){e.AM="AM",e.PM="PM"}(Le||(Le={}));const Ne=e=>({am_pm:e>=12?Le.PM:Le.AM,hours:e%12||12}),Pe=(e,t)=>t==Le.AM?12==e?0:e:12==e?12:e+12,Ie=(e,t={seconds:!0})=>{let i="";if(e.hours>=24&&(e.hours-=24),e.mode==be.Fixed&&t.am_pm){const s=Ne(e.hours).am_pm,a=Ne(e.hours).hours;i=String(a).padStart(2,"0")+":"+String(e.minutes).padStart(2,"0"),t.seconds&&(i+=":00"),i+=" "+(s===Le.AM?"am":"pm")}else e.mode==be.Fixed?(i=String(e.hours).padStart(2,"0")+":"+String(e.minutes).padStart(2,"0"),t.seconds&&(i+=":00")):(i=e.mode+(e.hours<0||e.minutes<0?"-":"+")+String(Math.abs(e.hours)).padStart(2,"0")+":"+String(Math.abs(e.minutes)).padStart(2,"0"),t.seconds&&(i+=":00"));return i},qe=(e,t)=>{const i=e=>{e=e.map(e=>Object.assign(Object.assign({},e),{start:Ae(e.start,t)<0?"00:00:00":e.start,stop:e.stop?Ae(e.stop,t)>86400?"00:00:00":e.stop:void 0})),(e=e.map(e=>{if(e.stop&&Ae(e.start,t)>Ae(e.stop,t)){if(0==Ae(e.stop,t))return Object.assign(Object.assign({},e),{stop:Ie(Se(Ce(e.stop),{hours:24}))});e=Object.assign(Object.assign({},e),{start:e.stop,stop:e.start})}return e.stop&&Ae(e.stop,t)-Ae(e.start,t)<60&&(e=Object.assign(Object.assign({},e),{stop:Ie(Se(Ce(e.start),{minutes:1}))})),e})).sort((e,i)=>Ae(e.start,t)>Ae(i.start,t)?1:Ae(e.start,t)<Ae(i.start,t)?-1:Ae(e.stop||e.start,t)>Ae(i.stop||i.start,t)?1:-1);let i="00:00:00",s=e.length;for(let a=0;a<s;a++){const o=e[a];Ae(o.start,t)>Ae(i,t)?(e.splice(a,0,Object.assign(Object.assign({},o),{start:i,stop:o.start,actions:[],conditions:o.conditions})),s++,a++):Ae(o.start,t)<Ae(i,t)&&(e=Object.assign(e,{[a]:Object.assign(Object.assign({},o),{start:i})})),i=void 0!==o.stop?o.stop:Ie(Se(Ce(o.start),{minutes:1}))}return Ae(i,t)<86400&&Ae(i,t)>0&&e.push({start:i,stop:Ie({mode:be.Fixed,hours:24,minutes:0}),actions:[],conditions:e[0].conditions}),e};return e=Object.assign(Object.assign({},e),{entries:e.entries.map(e=>Object.assign(Object.assign({},e),{slots:i(e.slots)}))})},Re=["relative-time","state"],Ve="default",He=["relative-time","additional-tasks"],Ue=["*"],Fe={actions:[],conditions:{type:_e.Or,items:[],track_changes:!1}},Be={entries:[{weekdays:[pe.Daily],slots:[Object.assign(Object.assign({},Fe),{start:"00:00:00",stop:"08:00:00"}),Object.assign(Object.assign({},Fe),{start:"08:00:00",stop:"16:00:00"}),Object.assign(Object.assign({},Fe),{start:"16:00:00",stop:"00:00:00"})]}],repeat_type:fe.Repeat,next_entries:[],timestamps:[],enabled:!0},We=Object.assign(Object.assign({},Be),{entries:[{weekdays:[pe.Daily],slots:[Object.assign(Object.assign({},Fe),{start:"00:00:00",stop:"12:00:00"}),Object.assign(Object.assign({},Fe),{start:"12:00:00"}),Object.assign(Object.assign({},Fe),{start:"12:01:00",stop:"00:00:00"})]}]});function Ze(e){return null!=e}const Ke=(e,t)=>Object.keys(e).includes(t),Ge=e=>"boolean"==typeof e,Je=e=>"number"==typeof e,Ye=e=>"string"==typeof e,Qe=e=>"object"==typeof e&&!Array.isArray(e),Xe=e=>Array.isArray(e)&&e.every(e=>"string"==typeof e),et=(e,t)=>Qe(t)?Ke(t,"states")&&!(Xe(t.states)||Qe(t.states)&&Ke(t.states,"min")&&Je(t.states.min)&&Ke(t.states,"max")&&Je(t.states.max))?`In 'customize' [${e}].states' must be a list of strings or a range of numbers`:void 0:`'In customize, ${e}' must be a struct`;var tt={generic:{turn_on:"Включи",turn_off:"изключи",parameter_to_value:"{parameter} на {value}",action_with_parameter:"{action} с {parameter}"},climate:{set_temperature:"задай температура[ на {temperature}]",set_temperature_hvac_mode_heat:"отопление[ на {temperature}]",set_temperature_hvac_mode_cool:"охлаждане[ на {temperature}]",set_temperature_hvac_mode_heat_cool:"отопление/охлаждане[ на {temperature}]",set_temperature_hvac_mode_heat_cool_range:"отопление/охлаждане[ на {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"автоматично[ на {temperature}]",set_hvac_mode:"задай режим[ на {hvac_mode}]",set_preset_mode:"задай предварителна настройка[ на {preset_mode}]",set_fan_mode:"задай режим на вентилатор[ на {fan_mode}]",set_swing_mode:"задай режим на въртене[ на {swing_mode}]"},cover:{close_cover:"затвори",open_cover:"отвори",set_cover_position:"задай позиция[ на {position}]",set_cover_tilt_position:"задай позиция на наклон[ на {tilt_position}]"},fan:{set_percentage:"задай скорост[ на {percentage}]",set_direction:"задай посока[ на {direction}]",oscillate:"задай осцилация[ на {oscillate}]"},humidifier:{set_humidity:"задай влажност[ на {humidity}]",set_mode:"задай режим[ на {mode}]"},input_number:{set_value:"задай стойност[ на {value}]"},input_select:{select_option:"избери опция[ {option}]"},select:{select_option:"избери опция[ {option}]"},light:{turn_on:"включи[ с {brightness} яркост]"},media_player:{select_source:"избери източник[ {source}]"},notify:{send_message:"изпрати известие"},script:{execute:"изпълни"},vacuum:{start_pause:"старт / пауза"},water_heater:{set_operation_mode:"задай режим[ на {operation_mode}]",set_away_mode:"задай режим 'не съм вкъщи'"}},it={components:{date:{day_types_short:{daily:"дневно",workdays:"работни дни",weekend:"уикенд"},day_types_long:{daily:"всеки ден",workdays:"в работни дни",weekend:"през уикенда"},days:"дни",tomorrow:"утре",repeated_days:"всеки {days}",repeated_days_except:"всеки ден освен {excludedDays}",days_range:"от {startDay} до {endDay}",next_week_day:"следващ {weekday}"},time:{absolute:"в {time}",interval:"от {startTime} до {endTime}",at_midnight:"в полунощ",at_noon:"на обяд",at_sun_event:"при {sunEvent}"}},dialog:{enable_schedule:{title:"Завърши промените",description:"Графикът, който сте променили, е деактивиран. Искате ли да го активирате?"},confirm_delete:{title:"Премахни обект?",description:"Сигурни ли сте, че искате да премахнете този обект?"},confirm_migrate:{title:"Актуализирай графика",description:"Някои настройки ще бъдат загубени при тази промяна. Искате ли да продължите?"},weekday_picker:{title:"Повтарящи се дни за графика",choose:"Избери..."},entity_picker:{title:"Изберете обекти",choose:"Избери...",no_results:"Няма намерени съвпадения"},action_picker:{title:"Изберете действие",show_all:"Показване на всички поддържани обекти"}},panel:{common:{title:"Планировчик",new_schedule:"Нов график",default_name:"График #{id}"},overview:{no_entries:"Няма елементи за показване",backend_error:"Не може да се свърже с компонента за планиране. Той трябва да бъде инсталиран като интеграция, преди тази карта да може да се използва.",excluded_items:"{number} изключен {if number is 1} елемент {else} елемента",hide_excluded:"скрий изключените елементи",additional_tasks:"{number} още {if number is 1} задача {else} задачи"},editor:{repeated_days:"Повтарящи се дни",start_time:"Начален час",stop_time:"Краен час",action:"Действие",add_action:"Добави действие",select_timeslot:"Изберете времеви слот",toggle_single_mode:"В единичен режим",toggle_scheme_mode:"В режим на схема",validation_errors:{overlapping_time:"Графикът има припокриващи се времеви слотове",missing_target_entity:"Едно или повече действия нямат целеви обект",missing_service_parameter:"Едно или повече действия нямат задължителна настройка",missing_action:"Графикът няма действия"}},options:{conditions:{header:"Условия",add_condition:"Добави условие",new_condition:"Нов условие",types:{equal_to:"{entity} е равно на {value}",unequal_to:"{entity} не е равно на {value}",above:"{entity} е над {value}",below:"{entity} е под {value}"},options:{logic_and:"Всички условия трябва да са изпълнени",logic_or:"Поне едно условие трябва да е изпълнено",track_changes:"Преоценка при промяна на условията"}},period:{header:"Период",start_date:"От",end_date:"До"},repeat_type:"поведение след завършване",tags:"Етикети"},card_editor:{tabs:{entities:"Обекти",other:"Други"},fields:{title:{heading:"Заглавие на картата",options:{standard:"стандартно",hidden:"скрито",custom:"персонализирано"},custom_title:"Персонализирано заглавие"},discover_existing:{heading:"Покажи всички графици",description:"Това задава параметъра 'discover existing'. Предварително създадени графици ще бъдат автоматично добавени към картата. "},time_step:{heading:"Времева стъпка",description:"Резолюция (в минути) за създаване на графици",unit_minutes:"мин"},default_editor:{heading:"Редактор по подразбиране",options:{single:"Режим на единичен график",scheme:"Режим на времева схема"}},sort_by:{heading:"Опции за сортиране",description:"Ред, в който се показват графиците в картата",options:{relative_time:"Оставащо време до следващото действие",title:"Показано заглавие на графика",state:"Покажи активните графици отгоре"}},display_format_primary:{heading:"Показана основна информация",description:"Конфигурирайте кой етикет се използва за графиците в прегледа",options:{default:"Име на графика",entity_action:"Резюме на задачата"}},display_format_secondary:{heading:"Показана допълнителна информация",description:"Конфигурирайте какви допълнителни свойства са видими в прегледа",options:{relative_time:"Оставащо време до следващото действие",time:"Конфигуриран час за следващо действие",days:"Повтарящи се дни от седмицата",additional_tasks:"Брой допълнителни задачи"}},show_header_toggle:{heading:"Покажи превключвател в заглавието",description:"Покажи превключвател в горната част на картата за активиране/деактивиране на всички обекти"},show_toggle_switches:{heading:"Покажи превключватели",description:"Покажи превключвател за всяко отделно задание в картата"},tags:{heading:"Етикети",description:"Използвайте етикети за разделяне на графиците между множество карти"},entities:{button_label:"Конфигурирай включени обекти",heading:"Включени обекти",description:"Изберете обектите, които искате да контролирате чрез планировчика. Можете да кликнете на група, за да я отворите. Имайте предвид, че някои обекти (като сензори) могат да се използват само за условия, не и за действия.",included_number:"{number}/{total} избрани"}}}}},st={services:tt,ui:it},at=Object.freeze({__proto__:null,default:st,services:tt,ui:it}),ot={generic:{turn_on:"Encén",turn_off:"Apaga",parameter_to_value:"{parameter} a {value}",action_with_parameter:"{action} amb {parameter}"},climate:{set_temperature:"estableix la temperatura[ a {temperature}]",set_temperature_hvac_mode_heat:"escalfa[ a {temperature}]",set_temperature_hvac_mode_cool:"refreda[ a {temperature}]",set_temperature_hvac_mode_heat_cool:"calor/fred[ a {temperature}]",set_temperature_hvac_mode_heat_cool_range:"calor/fred[ de {target_temp_low} a {target_temp_high}]",set_temperature_hvac_mode_auto:"automàtic[ a {temperature}]",set_hvac_mode:"estableix el mode[ a {hvac_mode}]",set_preset_mode:"estableix el preajust[ a {preset_mode}]",set_fan_mode:"estableix el mode del ventilador[ a {fan_mode}]",set_swing_mode:"estableix l'oscil·lació[ a {swing_mode}]"},cover:{close_cover:"tanca",open_cover:"obre",set_cover_position:"estableix la posició[ a {position}]",set_cover_tilt_position:"estableix la inclinació[ a {tilt_position}]"},fan:{set_percentage:"estableix la velocitat[ a {percentage}]",set_direction:"estableix la direcció[ a {direction}]",oscillate:"estableix l'oscil·lació[ a {oscillate}]"},humidifier:{set_humidity:"estableix la humitat[ a {humidity}]",set_mode:"estableix el mode[ a {mode}]"},input_number:{set_value:"estableix el valor[ a {value}]"},input_select:{select_option:"selecciona l'opció[ {option}]"},select:{select_option:"selecciona l'opció[ {option}]"},light:{turn_on:"encén[ amb brillantor {brightness}]"},media_player:{select_source:"selecciona la font[ {source}]"},notify:{send_message:"envia una notificació"},script:{execute:"executa"},vacuum:{start_pause:"inicia / pausa"},water_heater:{set_operation_mode:"estableix el mode[ a {operation_mode}]",set_away_mode:"estableix el mode absència"}},nt={components:{date:{day_types_short:{daily:"diari",workdays:"feiners",weekend:"cap de setmana"},day_types_long:{daily:"cada dia",workdays:"els dies feiners",weekend:"el cap de setmana"},days:"dies",tomorrow:"demà",repeated_days:"cada {days}",repeated_days_except:"cada dia excepte {excludedDays}",days_range:"de {startDay} a {endDay}",next_week_day:"el proper {weekday}"},time:{absolute:"a les {time}",interval:"de {startTime} a {endTime}",at_midnight:"a mitjanit",at_noon:"al migdia",at_sun_event:"a {sunEvent}"}},dialog:{enable_schedule:{title:"Completa les modificacions",description:"L'horari que has modificat està actualment desactivat. El vols activar?"},confirm_delete:{title:"Eliminar entitat?",description:"Segur que vols eliminar aquesta entitat?"},confirm_migrate:{title:"Actualitza l'horari",description:"Amb aquest canvi es perdran alguns paràmetres. Vols continuar?"},weekday_picker:{title:"Dies repetits per a l'horari",choose:"Escull..."},entity_picker:{title:"Escull entitats",choose:"Escull...",no_results:"No s'han trobat elements coincidents"},action_picker:{title:"Escull una acció",show_all:"Mostra totes les entitats compatibles"}},panel:{common:{title:"Programador",new_schedule:"Nou horari",default_name:"Horari #{id}"},overview:{no_entries:"No hi ha cap element per mostrar",backend_error:"No s'ha pogut connectar amb el component scheduler. Cal instal·lar-lo com a integració abans de fer servir aquesta targeta.",excluded_items:"{number} {if number is 1} element exclòs {else} elements exclosos",hide_excluded:"amaga els elements exclosos",additional_tasks:"{number} {if number is 1} tasca més {else} tasques més"},editor:{repeated_days:"Dies repetits",start_time:"Hora d'inici",stop_time:"Hora de fi",action:"Acció",add_action:"Afegeix acció",select_timeslot:"Selecciona una franja horària",toggle_single_mode:"Canvia a mode simple",toggle_scheme_mode:"Canvia a mode esquema",validation_errors:{overlapping_time:"L'horari té franges superposades",missing_target_entity:"A una o més accions els falta una entitat de destinació",missing_service_parameter:"A una o més accions els falta un paràmetre obligatori",missing_action:"L'horari no té cap acció"}},options:{conditions:{header:"Condicions",add_condition:"Afegeix condició",new_condition:"Nova condició",types:{equal_to:"{entity} és igual a {value}",unequal_to:"{entity} és diferent de {value}",above:"{entity} és superior a {value}",below:"{entity} és inferior a {value}"},options:{logic_and:"Totes les condicions han de ser certes",logic_or:"Qualsevol condició ha de ser certa",track_changes:"Torna a avaluar quan canviïn les condicions"}},period:{header:"Període",start_date:"Des de",end_date:"Fins a"},repeat_type:"comportament en finalitzar",tags:"Etiquetes"},card_editor:{tabs:{entities:"Entitats",other:"Altres"},fields:{title:{heading:"Títol de la targeta",options:{standard:"estàndard",hidden:"ocult",custom:"personalitzat"},custom_title:"Títol personalitzat"},discover_existing:{heading:"Mostra tots els horaris",description:"Això defineix el paràmetre 'discover existing'. Els horaris creats prèviament s'afegiran automàticament a la targeta."},time_step:{heading:"Pas de temps",description:"Resolució (en minuts) per crear horaris",unit_minutes:"min"},default_editor:{heading:"Editor horari per defecte",options:{single:"Mode horari simple",scheme:"Mode esquema horari"}},sort_by:{heading:"Opcions d'ordenació",description:"Ordre en què apareixen els horaris a la targeta",options:{relative_time:"Temps restant fins a la següent acció",title:"Títol visible de l'horari",state:"Mostra primer els horaris actius"}},display_format_primary:{heading:"Informació principal mostrada",description:"Configura quina etiqueta es fa servir per als horaris a la vista general",options:{default:"Nom de l'horari",entity_action:"Resum de la tasca"}},display_format_secondary:{heading:"Informació secundària mostrada",description:"Configura quines propietats addicionals són visibles a la vista general",options:{relative_time:"Temps restant fins a la següent acció",time:"Hora configurada per a la següent acció",days:"Dies repetits de la setmana",additional_tasks:"Nombre de tasques addicionals"}},show_header_toggle:{heading:"Mostra l'interruptor de capçalera",description:"Mostra l'interruptor a la part superior de la targeta per activar/desactivar totes les entitats"},show_toggle_switches:{heading:"Mostra interruptors",description:"Mostra un interruptor per a cada horari individual de la targeta"},tags:{heading:"Etiquetes",description:"Fes servir etiquetes per dividir els horaris entre múltiples targetes"},entities:{button_label:"Configura les entitats incloses",heading:"Entitats incloses",description:"Selecciona les entitats que vols controlar amb el programador. Pots fer clic a un grup per obrir-lo. Tingues en compte que algunes entitats, com ara els sensors, només es poden fer servir per a condicions, no per a accions.",included_number:"{number}/{total} seleccionades"}}}}},rt={services:ot,ui:nt},dt=Object.freeze({__proto__:null,default:rt,services:ot,ui:nt}),lt={generic:{turn_on:"Zapnout",turn_off:"Vypnout",parameter_to_value:"{parameter} na {value}",action_with_parameter:"{action} s {parameter}"},climate:{set_temperature:"nastavit teplotu[ na {temperature}]",set_temperature_hvac_mode_heat:"topení[ na {temperature}]",set_temperature_hvac_mode_cool:"chlazení[ na {temperature}]",set_temperature_hvac_mode_heat_cool:"topení/chlazení[ na {temperature}]",set_temperature_hvac_mode_heat_cool_range:"topení/chlazení[ na {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"automatika[ na {temperature}]",set_hvac_mode:"nastavit režim[ na {hvac_mode}]",set_preset_mode:"nastavit předvolbu[ {preset_mode}]",set_fan_mode:"set fan mode[ to {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"zavřít",open_cover:"otevřít",set_cover_position:"nastavit polohu[ na {position}]",set_cover_tilt_position:"set tilt position[ to {tilt_position}]"},fan:{set_percentage:"nastavit rychlost[ na {speed}]",set_direction:"nastavit směr[ na {direction}]",oscillate:"nastavit oscilaci[ na {oscillate}]"},humidifier:{set_humidity:"nastavit vlhkost[ na {humidity}]",set_mode:"nastavit režim[ na {mode}]"},input_number:{set_value:"nastavit hodnotu[ na {value}]"},input_select:{select_option:"vybrat možnost[ {option}]"},select:{select_option:"vybrat možnost[ {option}]"},light:{turn_on:"zapnout[ na {brightness} jas]"},media_player:{select_source:"vybrat zdroj[ {source}]"},notify:{send_message:"send notification"},script:{execute:"spustit"},vacuum:{start_pause:"start / pauza"},water_heater:{set_operation_mode:"nastavit režim[ na {operation_mode}]",set_away_mode:"vypnout režim"}},ct={components:{date:{day_types_short:{daily:"denně",workdays:"pracovní dny",weekend:"víkendy"},day_types_long:{daily:"každý den",workdays:"v pracovní dny",weekend:"o víkendu"},days:"dnů",tomorrow:"zítra",repeated_days:"každý {days}",repeated_days_except:"každý den kromě {excludedDays}",days_range:"od {startDay} do {endDay}",next_week_day:"příští {weekday}"},time:{absolute:"od {time}",interval:"od {startTime} do {endTime}",at_midnight:"od půlnoc",at_noon:"od poledne",at_sun_event:"na {sunEvent}"}},dialog:{enable_schedule:{title:"Dokončete úpravy",description:"Plán, který byl změněn, je aktuálně zakázán, měl by být povolen?"},confirm_delete:{title:"Odebrat entitu?",description:"Opravdu chcete tuto entitu odebrat?"},confirm_migrate:{title:"Aktualizovat plán",description:"Některá nastavení budou touto změnou ztracena. Chceš pokračovat?"},weekday_picker:{title:"Repeated days for schedule",choose:"Choose..."},entity_picker:{title:"Choose entities",choose:"Choose...",no_results:"No matching items found"},action_picker:{title:"Choose action",show_all:"Show all supported entities"}},panel:{common:{title:"Plánovač",new_schedule:"Nový plán",default_name:"Plán #{id}"},overview:{no_entries:"Nejsou žádné položky k zobrazení",backend_error:"Could not connect with the scheduler component. It needs to be installed as integration before this card can be used.",excluded_items:"{number} vyloučeno {if number is 1} položka {else} položek",hide_excluded:"skrýt vyloučené položky",additional_tasks:"{number} a více {if number is 1} úkol {else} úkolů"},editor:{repeated_days:"Repeated days",start_time:"Start time",stop_time:"End time",action:"Action",add_action:"Add action",select_timeslot:"Nejprve vyberte časový úsek",toggle_single_mode:"Do režimu jednoho",toggle_scheme_mode:"Do režimu schématu",validation_errors:{overlapping_time:"Schedule has overlapping timeslots",missing_target_entity:"One or more actions are missing a target entity",missing_service_parameter:"One or more actions are missing a required setting",missing_action:"Schedule has no actions"}},options:{conditions:{header:"Conditions",add_condition:"Add condition",new_condition:"New condition",types:{equal_to:"{entity} is equal to {value}",unequal_to:"{entity} is unequal to {value}",above:"{entity} is above {value}",below:"{entity} is below {value}"},options:{logic_and:"All conditions must be true",logic_or:"Any condition must be true",track_changes:"Re-evaluate when conditions change"}},period:{header:"Období",start_date:"From",end_date:"To"},repeat_type:"behaviour after completion",tags:"Tags"},card_editor:{tabs:{entities:"Entities",other:"Other"},fields:{title:{heading:"Title of the card",options:{standard:"standard",hidden:"hidden",custom:"custom"},custom_title:"Custom title"},discover_existing:{heading:"Show all schedules",description:"This sets the 'discover existing' parameter. Previously created schedules will be automatically added to the card. "},time_step:{heading:"Time step",description:"Resolution (in minutes) for creating schedules",unit_minutes:"min"},default_editor:{heading:"Default time editor",options:{single:"Single schedule mode",scheme:"Time scheme mode"}},sort_by:{heading:"Sorting options",description:"Order in which the schedules appear in the card",options:{relative_time:"Time remaining until next action",title:"Displayed title of the schedule",state:"Show active schedules on top"}},display_format_primary:{heading:"Displayed primary info",description:"Configure which label is used for schedules in the overview",options:{default:"Schedule name",entity_action:"Summary of task"}},display_format_secondary:{heading:"Displayed secondary info",description:"Configure what additional properties are visible in the overview",options:{relative_time:"Time remaining until next action",time:"Configured time for next action",days:"Repeated days of the week",additional_tasks:"Number of additional tasks"}},show_header_toggle:{heading:"Show header toggle",description:"Show toggle switch at the top of the card for enabling/disabling all entities"},show_toggle_switches:{heading:"Show toggle switches",description:"Show toggle switch for each individual schedule in the card"},tags:{heading:"Tags",description:"Use tags to divide schedules between multiple cards"},entities:{button_label:"Configure included entities",heading:"Included entities",description:"Select the entities that you want to control using the scheduler. You can click on a group to open it. Note that some entities (such as sensors) can only be used for conditions, not for actions.",included_number:"{number}/{total} selected"}}}}},ut={services:lt,ui:ct},ht=Object.freeze({__proto__:null,default:ut,services:lt,ui:ct}),mt={generic:{turn_on:"Einschalten",turn_off:"Ausschalten",parameter_to_value:"{parameter} auf {value}",action_with_parameter:"{action} mit {parameter}"},climate:{set_temperature:"Temperatur einstellen[ auf {temperature}]",set_temperature_hvac_mode_heat:"Heizen[ auf {temperature}]",set_temperature_hvac_mode_cool:"Kühlen[ auf {temperature}]",set_temperature_hvac_mode_heat_cool:"Heizen/Kühlen[ auf {temperature}]",set_temperature_hvac_mode_heat_cool_range:"Heizen/Kühlen[ auf {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"Automatisch[ auf {temperature}]",set_hvac_mode:"Modus setzen[ auf {hvac_mode}]",set_preset_mode:"Voreinstellung setzen[ auf {preset_mode}]",set_fan_mode:"Lüftermodus einstellen[ auf {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"Schließen",open_cover:"Öffnen",set_cover_position:"Position setzen[ auf {position}]",set_cover_tilt_position:"Neigungsposition setzen[ auf {tilt_position}]"},fan:{set_percentage:"Geschwindigkeit setzen[ auf {speed}]",set_direction:"Richtung setzen[ auf {direction}]",oscillate:"Oszillation setzen[ auf {oscillate}]"},humidifier:{set_humidity:"Luftfeuchtigkeit setzen[ auf {humidity}]",set_mode:"Modus setzen[ auf {mode}]"},input_number:{set_value:"Wert setzen[ auf {value}]"},input_select:{select_option:"Option[ {option}] auswählen"},select:{select_option:"Option[ {option}] auswählen"},light:{turn_on:"Anschalten[ mit {brightness} Helligkeit]"},media_player:{select_source:"Quelle[ {source}] auswählen"},notify:{send_message:"Nachricht senden"},script:{execute:"Ausführen"},vacuum:{start_pause:"Start/Pause"},water_heater:{set_operation_mode:"Modus setzen[ auf {operation_mode}]",set_away_mode:"Abwesenheitsmodus setzen"}},pt={components:{date:{day_types_short:{daily:"Täglich",workdays:"Werktags",weekend:"Wochenende"},day_types_long:{daily:"Jeden Tag",workdays:"An Werktagen",weekend:"Am Wochenende"},days:"Tage",tomorrow:"Morgen",repeated_days:"Jeden {days}",repeated_days_except:"Täglich außer {excludedDays}",days_range:"von {startDay} bis {endDay}",next_week_day:"nächsten {weekday}"},time:{absolute:"um {time}",interval:"von {startTime} bis {endTime}",at_midnight:"um Mitternacht",at_noon:"zum Mittag",at_sun_event:"beim {sunEvent}"}},dialog:{enable_schedule:{title:"Modifikationen beenden",description:"Der geänderte Zeitplan ist derzeit deaktiviert, soll er aktiviert werden?"},confirm_delete:{title:"Entität entfernen?",description:"Bist du dir sicher, dass du diese Entität löschen möchtest?"},confirm_migrate:{title:"Zeitplan ändern",description:"Einige Einstellungen gehen durch diese Änderung verloren. Möchtest du fortfahren?"},weekday_picker:{title:"Wiederholungen für den Zeitplan",choose:"Auswahl..."},entity_picker:{title:"Entitäten auswählen",choose:"Auswahl...",no_results:"Keine passenden Elemente gefunden"},action_picker:{title:"Aktion auswählen",show_all:"Alle unterstützten Entitäten anzeigen"}},panel:{common:{title:"Zeitplaner",new_schedule:"Neuer Zeitplan",default_name:"Zeitplan #{id}"},overview:{no_entries:"Es gibt keine Einträge, die angezeigt werden können",backend_error:"Es konnte keine Verbindung mit der Scheduler-Komponente hergestellt werden. Es muss als Integration installiert werden, bevor diese Karte verwendet werden kann.",excluded_items:"{number} {if number is 1} ausgeschlossener Eintrag {else} ausgeschlossene Einträge",hide_excluded:"Verstecke ausgeschlossene Einträge",additional_tasks:"{number} weitere {if number is 1} Aufgabe {else} Aufgaben"},editor:{repeated_days:"Wiederholen",start_time:"Startzeit",stop_time:"Endzeit",action:"Aktion",add_action:"Aktion hinzufügen",select_timeslot:"Wähle ein Zeitfenster aus",toggle_single_mode:"Zum Einzelmodus",toggle_scheme_mode:"Zum Schemamodus",validation_errors:{overlapping_time:"Der Zeitplan weist Überschneidungen auf.",missing_target_entity:"Bei einer oder mehreren Aktionen fehlt eine Zielentität.",missing_service_parameter:"Bei einer oder mehreren Aktionen fehlt eine erforderliche Einstellung.",missing_action:"Zeitplan enthält keine Aktionen"}},options:{conditions:{header:"Bedingungen",add_condition:"Bedingung hinzufügen",new_condition:"Neuer Zustand",types:{equal_to:"{entity} ist {value}",unequal_to:"{entity} ist nicht {value}",above:"{entity} ist über {value}",below:"{entity} ist unter {value}"},options:{logic_and:"Alle Bedingungen müssen zutreffen.",logic_or:"Eine Bedingung muss zutreffen.",track_changes:"Erneut prüfen wenn sich die Zustände ändern"}},period:{header:"Zeitraum",start_date:"Von",end_date:"Bis"},repeat_type:"Verhalten nach Abschluss",tags:"Tags"},card_editor:{tabs:{entities:"Entities",other:"Other"},fields:{title:{heading:"Title of the card",options:{standard:"standard",hidden:"hidden",custom:"custom"},custom_title:"Custom title"},discover_existing:{heading:"Show all schedules",description:"This sets the 'discover existing' parameter. Previously created schedules will be automatically added to the card. "},time_step:{heading:"Time step",description:"Resolution (in minutes) for creating schedules",unit_minutes:"min"},default_editor:{heading:"Default time editor",options:{single:"Single schedule mode",scheme:"Time scheme mode"}},sort_by:{heading:"Sorting options",description:"Order in which the schedules appear in the card",options:{relative_time:"Time remaining until next action",title:"Displayed title of the schedule",state:"Show active schedules on top"}},display_format_primary:{heading:"Displayed primary info",description:"Configure which label is used for schedules in the overview",options:{default:"Schedule name",entity_action:"Summary of task"}},display_format_secondary:{heading:"Displayed secondary info",description:"Configure what additional properties are visible in the overview",options:{relative_time:"Time remaining until next action",time:"Configured time for next action",days:"Repeated days of the week",additional_tasks:"Number of additional tasks"}},show_header_toggle:{heading:"Show header toggle",description:"Show toggle switch at the top of the card for enabling/disabling all entities"},show_toggle_switches:{heading:"Show toggle switches",description:"Show toggle switch for each individual schedule in the card"},tags:{heading:"Tags",description:"Use tags to divide schedules between multiple cards"},entities:{button_label:"Configure included entities",heading:"Included entities",description:"Select the entities that you want to control using the scheduler. You can click on a group to open it. Note that some entities (such as sensors) can only be used for conditions, not for actions.",included_number:"{number}/{total} selected"}}}}},_t={services:mt,ui:pt},gt=Object.freeze({__proto__:null,default:_t,services:mt,ui:pt}),vt={generic:{turn_on:"Ενεργοποίηση",turn_off:"Απενεργοποίηση",parameter_to_value:"{parameter} σε {value}",action_with_parameter:"{action} με {parameter}"},climate:{set_temperature:"ορισμός θερμοκρασίας[ σε {temperature}]",set_temperature_hvac_mode_heat:"θέρμανση[ σε {temperature}]",set_temperature_hvac_mode_cool:"ψύξη[ σε {temperature}]",set_temperature_hvac_mode_heat_cool:"θέρμανση/ψύξη[ σε {temperature}]",set_temperature_hvac_mode_heat_cool_range:"θέρμανση/ψύξη[ σε {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"auto[ σε {temperature}]",set_hvac_mode:"ορισμός λειτουργίας[ σε {hvac_mode}]",set_preset_mode:"ορισμός προκαθορισμένης ρύθμισης[ σε {preset_mode}]",set_fan_mode:"όρισμός ανεμιστήρα[ σε {fan_mode}]",set_swing_mode:"ορισμός κατεύθυνσης[ σε {swing_mode}]"},cover:{close_cover:"κλείσιμο",open_cover:"άνοιγμα",set_cover_position:"ορισμός θέσησ[ σε {position}]",set_cover_tilt_position:"ορισμός κλίσης[ σε {tilt_position}]"},fan:{set_percentage:"ορισμός ταχύτητας[ σε {percentage}]",set_direction:"ορισμός κατεύθυνσης[ σε {direction}]",oscillate:"ορισμός ταλάντωσης[ σε {oscillate}]"},humidifier:{set_humidity:"ορισμός υγρασίας[ σε {humidity}]",set_mode:"ορισμός λειτουργίας[ σε {mode}]"},input_number:{set_value:"ορισμός τιμής[ σε {value}]"},input_select:{select_option:"επιλογή παραμέτρου[ {option}]"},select:{select_option:"επιλογή παραμέτρου[ {option}]"},light:{turn_on:"άναμα[ με φωτεινότητα {brightness} ]"},media_player:{select_source:"επιλογή πηγής[ {source}]"},notify:{send_message:"αποστολή ειδοποίησης"},script:{execute:"εκτέλεση"},vacuum:{start_pause:"έναρξη / παύση"},water_heater:{set_operation_mode:"ορισμός λειτουργίας[ σε {operation_mode}]",set_away_mode:"ορισμός λειτουργίας απουσίας"}},yt={components:{date:{day_types_short:{daily:"ημερήσια",workdays:"εργάσιμες",weekend:"σαββατοκύριακο"},day_types_long:{daily:"κάθε μέρα",workdays:"τις καθημερινές",weekend:"το σαββατοκύριακο"},days:"ημέρες",tomorrow:"αύριο",repeated_days:"κάθε {days}",repeated_days_except:"κάθε μέρα εκτός {excludedDays}",days_range:"από {startDay} έως {endDay}",next_week_day:"επόμενη/-ο {weekday}"},time:{absolute:"στις {time}",interval:"από {startTime} ως {endTime}",at_midnight:"τα μεσάνυχτα",at_noon:"το μεσημέρι",at_sun_event:"το {sunEvent}"}},dialog:{enable_schedule:{title:"Ολοκλήρωση τροποποιήσεων",description:"Το πρόγραμμα που τροποποιήθηκε είναι απενεργοποιημένο, επιθυμείτε να το ενεργοποιήσετε;"},confirm_delete:{title:"Αφαίρεση οντότητας",description:"Είστε σίγουροι ότι θέλετε να αφαιρεθεί αυτή η οντότητα;"},confirm_migrate:{title:"Ενημέρωση προγράμματος",description:"Κάποιες ρυθμίσεις θα χαθούν από αυτή την αλλαγή. Θέλετε να συνεχίσετε;"},weekday_picker:{title:"Επαναλαμβανόμενες ημέρες για το πρόγραμμα",choose:"Επιλογή ημερών..."},entity_picker:{title:"Επιλογή οντοτήτων",choose:"Επιλογή...",no_results:"Δεν βρέθηκε οντότητα"},action_picker:{title:"Επιλογή ενέργειας",show_all:"Εμφάνιση όλων των υποστηριζόμενων οντοτήτων"}},panel:{common:{title:"Χρονοπρογραμματισμός",new_schedule:"Νέο Πρόγραμμα",default_name:"Πρόγραμμα #{id}"},overview:{no_entries:"Δεν βρέθηκαν καταχωρήσεις προς προβολή",backend_error:"Δεν είναι δυνατή η σύνδεη με το scheduler component. Πρέπει να εγκατασταθεί σαν integration πριν την χρήση αυτής της κάρτας.",excluded_items:"{number} {if number is 1} εξαιρούμενο αντικείμενο {else} εξαιρούμενα αντικείμενα",hide_excluded:"απόκρυψη εξαιρούμενων αντικειμένων",additional_tasks:"{number} επιπλέον {if number is 1} εργασία {else} εργασίες"},editor:{repeated_days:"Επαναλαμβανόμενες ημέρες",start_time:"Ώρα έναρξης",stop_time:"Ώρα ολοκλήρωσης",action:"Ενέργεια",add_action:"Προσθήκη ενέργειας",select_timeslot:"Επιλογή μιας ώρας",toggle_single_mode:"Μεμονωμένη λειτουργία",toggle_scheme_mode:"Λειτουργία προγραμματισμού",validation_errors:{overlapping_time:"Το πρόγραμμα παρουσιάζει αλληλοεπικαλύψεις ώρας",missing_target_entity:"Μια ή περισσότερες ενέργειες δεν διαθέτουν οντότητα - στόχο",missing_service_parameter:"Μια ή περισσότερες ενέργειες δεν διαθέτουν μια απαιτούμενη ρύθμιση",missing_action:"Το πρόγραμμα δεν διαθέτει ενέργειες"}},options:{conditions:{header:"Συνθήκες",add_condition:"Προσθήκη συνθήκης",new_condition:"Νέα συνθήκη",types:{equal_to:"{entity} ισούται με {value}",unequal_to:"{entity} δεν ισούται με {value}",above:"{entity} είναι περισσότερο από {value}",below:"{entity} είναι λιγότερο από {value}"},options:{logic_and:"Όλες οι συνθήκες πρέπει να αληθεύουν",logic_or:"Οποιαδήποτε συνθήκη πρέπει να αληθεύει",track_changes:"Επαναξιολόγηση όταν οι συνθήκες αλλάξουν"}},period:{header:"Περίοδος",start_date:"Από",end_date:"Έως"},repeat_type:"συμπεριφορά μετά την ολοκλήρωση",tags:"Tags"},card_editor:{tabs:{entities:"Οντότητες",other:"Λοιπά"},fields:{title:{heading:"Τίτλος της κάρτας",options:{standard:"τυπικό",hidden:"κρυφό",custom:"προσαρμοσμένο"},custom_title:"Προσαρμοσμενος τίτλος"},discover_existing:{heading:"Προβολή όλων των προγραμμάτων",description:"Αυτό ρυθμίζει την παράμμετρο 'ανακάλυψη υπαρχόντων'. Τα ήδη δημιουργημένα προγράμματα θα προστεθούν αυτόματα στην κάρτα. "},time_step:{heading:"Βήμα χρόνου",description:"Ανάλυση (σε λεπτά) για τη δημιουργία προγραμμάτων",unit_minutes:"λεπτά"},default_editor:{heading:"Προεπιλεγμένος επεξεργαστής χρόνου",options:{single:"Λειτουργία μονής χρονικής περιόδου",scheme:"Λειτουργία χρονικού σχήματος"}},sort_by:{heading:"Επιλογές ταξινόμησης",description:"Σειρά με την οποία εμφανίζονται τα προγράμματα στην κάρτα",options:{relative_time:"Υπολειπόμενος χρόνος έως την επόμενη ενέργεια",title:"Εμφανιζόμενος τίτλος του προγράμματος",state:"Εμφάνιση των ενεργών προγραμμάτων στην κορυφή"}},display_format_primary:{heading:"Προβαλλόμενη κύρια πληροφορία",description:"Ρυθμίστε ποια ετικέτα χρησιμοποιείται για τα προγράμματα στην επισκόπηση",options:{default:"Όνομα προγράμματος",entity_action:"Σύνοψη ενέργειας"}},display_format_secondary:{heading:"Προβαλλόμενη δευτερεύουσα πληροφορία",description:"Ρυθμίστε ποιες πρόσθετες ιδιότητες εμφανίζονται στην επισκόπηση",options:{relative_time:"Υπολειπόμενος χρόνος μέχρι την επόμενη ενέργεια",time:"Προγραμματισμένη ώρα για την επόμενη ενέργεια",days:"Επαναλαμβανόμενες ημέρες της εβδομάδας",additional_tasks:"Αριθμός πρόσθετων εργασιών"}},show_header_toggle:{heading:"Εμφάνιση διακόπτη κεφαλίδας",description:"Εμφάνιση διακόπτη στο επάνω μέρος της κάρτας για ενεργοποίηση/απενεργοποίηση όλων των οντοτήτων"},show_toggle_switches:{heading:"Εμφάνιση διακοπτών εναλλαγής",description:"Εμφάνιση διακόπτη εναλλαγής για κάθε μεμονωμένο πρόγραμμα στην κάρτα"},tags:{heading:"Ετικέτες",description:"Χρησιμοποιήστε ετικέτες για να χωρίσετε τα προγράμματα μεταξύ πολλών καρτών"},entities:{button_label:"Ρύθμιση συμπεριλαμβανόμενων οντοτήτων",heading:"Συμπεριλαμβανόμενες οντότητες",description:"Επιλέξτε τις οντότητες που θέλετε να ελέγχετε μέσω του χρονοπρογραμματιστή. Μπορείτε να κάνετε κλικ σε μια ομάδα για να την ανοίξετε. Λάβετε υπόψη ότι ορισμένες οντότητες (όπως αισθητήρες) μπορούν να χρησιμοποιηθούν μόνο για συνθήκες και όχι για ενέργειες.",included_number:"{number}/{total} επιλεγμένες"}}}}},ft={services:vt,ui:yt},bt=Object.freeze({__proto__:null,default:ft,services:vt,ui:yt}),wt={generic:{turn_on:"Turn on",turn_off:"Turn off",parameter_to_value:"{parameter} to {value}",action_with_parameter:"{action} with {parameter}"},climate:{set_temperature:"set temperature[ to {temperature}]",set_temperature_hvac_mode_heat:"heat[ to {temperature}]",set_temperature_hvac_mode_cool:"cool[ to {temperature}]",set_temperature_hvac_mode_heat_cool:"heat/cool[ to {temperature}]",set_temperature_hvac_mode_heat_cool_range:"heat/cool[ to {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"auto[ to {temperature}]",set_hvac_mode:"set mode[ to {hvac_mode}]",set_preset_mode:"set preset[ to {preset_mode}]",set_fan_mode:"set fan mode[ to {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"close",open_cover:"open",set_cover_position:"set position[ to {position}]",set_cover_tilt_position:"set tilt position[ to {tilt_position}]"},fan:{set_percentage:"set speed[ to {percentage}]",set_direction:"set direction[ to {direction}]",oscillate:"set oscillation[ to {oscillate}]"},humidifier:{set_humidity:"set humidity[ to {humidity}]",set_mode:"set mode[ to {mode}]"},input_number:{set_value:"set value[ to {value}]"},input_select:{select_option:"select option[ {option}]"},select:{select_option:"select option[ {option}]"},light:{turn_on:"turn on[ with {brightness} brightness]"},media_player:{select_source:"select source[ {source}]"},notify:{send_message:"send notification"},script:{execute:"execute"},vacuum:{start_pause:"start / pause"},water_heater:{set_operation_mode:"set mode[ to {operation_mode}]",set_away_mode:"set away mode"}},kt={components:{date:{day_types_short:{daily:"daily",workdays:"workdays",weekend:"weekend"},day_types_long:{daily:"every day",workdays:"on workdays",weekend:"in the weekend"},days:"days",tomorrow:"tomorrow",repeated_days:"every {days}",repeated_days_except:"every day except {excludedDays}",days_range:"from {startDay} to {endDay}",next_week_day:"next {weekday}"},time:{absolute:"at {time}",interval:"from {startTime} to {endTime}",at_midnight:"at midnight",at_noon:"at noon",at_sun_event:"at {sunEvent}"}},dialog:{enable_schedule:{title:"Complete modifications",description:"The schedule you have changed is currently disabled, do you want to enable it?"},confirm_delete:{title:"Remove entity?",description:"Are you sure you want to remove this entity?"},confirm_migrate:{title:"Update schedule",description:"Some settings will be lost by this change. Do you want to continue?"},weekday_picker:{title:"Repeated days for schedule",choose:"Choose..."},entity_picker:{title:"Choose entities",choose:"Choose...",no_results:"No matching items found"},action_picker:{title:"Choose action",show_all:"Show all supported entities"}},panel:{common:{title:"Scheduler",new_schedule:"New schedule",default_name:"Schedule #{id}"},overview:{no_entries:"There are no items to show",backend_error:"Could not connect with the scheduler component. It needs to be installed as integration before this card can be used.",excluded_items:"{number} excluded {if number is 1} item {else} items",hide_excluded:"hide excluded items",additional_tasks:"{number} more {if number is 1} task {else} tasks"},editor:{repeated_days:"Repeated days",start_time:"Start time",stop_time:"End time",action:"Action",add_action:"Add action",select_timeslot:"Select a timeslot",toggle_single_mode:"To single mode",toggle_scheme_mode:"To scheme mode",validation_errors:{overlapping_time:"Schedule has overlapping timeslots",missing_target_entity:"One or more actions are missing a target entity",missing_service_parameter:"One or more actions are missing a required setting",missing_action:"Schedule has no actions"}},options:{conditions:{header:"Conditions",add_condition:"Add condition",new_condition:"New condition",types:{equal_to:"{entity} is equal to {value}",unequal_to:"{entity} is unequal to {value}",above:"{entity} is above {value}",below:"{entity} is below {value}"},options:{logic_and:"All conditions must be true",logic_or:"Any condition must be true",track_changes:"Re-evaluate when conditions change"}},period:{header:"Period",start_date:"From",end_date:"To"},repeat_type:"behaviour after completion",tags:"Tags"},card_editor:{tabs:{entities:"Entities",other:"Other"},fields:{title:{heading:"Title of the card",options:{standard:"standard",hidden:"hidden",custom:"custom"},custom_title:"Custom title"},discover_existing:{heading:"Show all schedules",description:"This sets the 'discover existing' parameter. Previously created schedules will be automatically added to the card. "},time_step:{heading:"Time step",description:"Resolution (in minutes) for creating schedules",unit_minutes:"min"},default_editor:{heading:"Default time editor",options:{single:"Single schedule mode",scheme:"Time scheme mode"}},sort_by:{heading:"Sorting options",description:"Order in which the schedules appear in the card",options:{relative_time:"Time remaining until next action",title:"Displayed title of the schedule",state:"Show active schedules on top"}},display_format_primary:{heading:"Displayed primary info",description:"Configure which label is used for schedules in the overview",options:{default:"Schedule name",entity_action:"Summary of task"}},display_format_secondary:{heading:"Displayed secondary info",description:"Configure what additional properties are visible in the overview",options:{relative_time:"Time remaining until next action",time:"Configured time for next action",days:"Repeated days of the week",additional_tasks:"Number of additional tasks"}},show_header_toggle:{heading:"Show header toggle",description:"Show toggle switch at the top of the card for enabling/disabling all entities"},show_toggle_switches:{heading:"Show toggle switches",description:"Show toggle switch for each individual schedule in the card"},tags:{heading:"Tags",description:"Use tags to divide schedules between multiple cards"},entities:{button_label:"Configure included entities",heading:"Included entities",description:"Select the entities that you want to control using the scheduler. You can click on a group to open it. Note that some entities (such as sensors) can only be used for conditions, not for actions.",included_number:"{number}/{total} selected"}}}}},xt={services:wt,ui:kt},$t=Object.freeze({__proto__:null,default:xt,services:wt,ui:kt}),jt={generic:{turn_on:"Encender",turn_off:"Apagar",parameter_to_value:"{parameter} a {value}",action_with_parameter:"{action} con {parameter}"},climate:{set_temperature:"establecer temperatura[ a {temperature}]",set_temperature_hvac_mode_heat:"calefacción[ a {temperature}]",set_temperature_hvac_mode_cool:"frío[ a {temperature}]",set_temperature_hvac_mode_heat_cool:"calefacción/frío[ a {temperature}]",set_temperature_hvac_mode_heat_cool_range:"calefacción/frío[ a {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"automático[ a {temperature}]",set_hvac_mode:"establecer modo[ a {hvac_mode}]",set_preset_mode:"establecer preajuste[ {preset_mode}]",set_fan_mode:"establecer ventilador[ a {fan_mode}]",set_swing_mode:"establecer oscilación[ a {swing_mode}]"},cover:{close_cover:"cerrado",open_cover:"abierto",set_cover_position:"establecer posición[ a {position}]",set_cover_tilt_position:"establecer inclinación[ a {tilt_position}]"},fan:{set_percentage:"establecer velocidad[ a {speed}]",set_direction:"establecer dirección[ a {direction}]",oscillate:"establecer oscilación[ a {oscillate}]"},humidifier:{set_humidity:"establecer humedad[ a {humidity}]",set_mode:"establecer modo[ a {mode}]"},input_number:{set_value:"establecer valor[ a {value}]"},input_select:{select_option:"seleccionar opción[ a {option}]"},select:{select_option:"seleccionar opción[ {option}]"},light:{turn_on:"encender[ con brillo en {brightness}]"},media_player:{select_source:"seleccionar fuente[ {source}]"},notify:{send_message:"enviar notificación"},script:{execute:"ejecutar"},vacuum:{start_pause:"iniciar / pausar"},water_heater:{set_operation_mode:"establecer modo[ a {operation_mode}]",set_away_mode:"establecer modo fuera de casa"}},Ot={components:{date:{day_types_short:{daily:"todos los días",workdays:"días hábiles",weekend:"fin de semana"},day_types_long:{daily:"todos los días",workdays:"días hábiles",weekend:"fin de semana"},days:"días",tomorrow:"mañana",repeated_days:"cada {days}",repeated_days_except:"cada dia excepto {excludedDays}",days_range:"de {startDay} a {endDay}",next_week_day:"próximo {weekday}"},time:{absolute:"a la(s) {time}",interval:"desde la(s) {startTime} hasta la(s) {endTime}",at_midnight:"a la medianoche",at_noon:"al mediodía",at_sun_event:"al {sunEvent}"}},dialog:{enable_schedule:{title:"Completar modificaciones",description:"El horario que ha modificado está actualmente deshabilitado, ¿Desea habilitarlo?"},confirm_delete:{title:"¿Eliminar entidad?",description:"¿Está seguro de que deseas eliminar esta entidad?"},confirm_migrate:{title:"Modificar horario",description:"Algunas configuraciones se perderán con este cambio. ¿Desea proceder?"},weekday_picker:{title:"Días repetidos para el horario",choose:"Elegir..."},entity_picker:{title:"Elegir entidades",choose:"Elegir...",no_results:"No se encontraron artículos coincidentes"},action_picker:{title:"Elija Acción",show_all:"Mostrar todas las entidades admitidas"}},panel:{common:{title:"Planificador",new_schedule:"Nuevo horario",default_name:"Horario #{id}"},overview:{no_entries:"No hay ningún elemento que mostrar",backend_error:"Fallo de conexión con el componente planificador (Scheduler component). Debe ser instalado como integración antes de poder usar este panel.",excluded_items:"{number} {if number is 1} elemento excluido {else} elementos excluidos",hide_excluded:"ocultar elementos excluidos",additional_tasks:"{number} {if number is 1} tarea adicional {else} tareas adicionales"},editor:{repeated_days:"Días repetidos",start_time:"Inicio",stop_time:"Finalización",action:"Acción",add_action:"Agregar acción",select_timeslot:"Seleccione un bloque de tiempo",toggle_single_mode:"Al modo simple",toggle_scheme_mode:"Al modo esquema",validation_errors:{overlapping_time:"El esquema tiene bloques de tiempo sobrepuestos",missing_target_entity:"Una o más acciones carecen de una entidad asociada",missing_service_parameter:"Una o más acciones carecen de una configuración requerida",missing_action:"El horario no tiene acciones"}},options:{conditions:{header:"Condiciones",add_condition:"Agregar condición",new_condition:"Nueva condición",types:{equal_to:"{entity} es igual a {value}",unequal_to:"{entity} es diferente a {value}",above:"{entity} es mayor que {value}",below:"{entity} es menor que {value}"},options:{logic_and:"Todas las condiciones deben ser válidas",logic_or:"Cualquier condición debe ser válida",track_changes:"Reevaluar si una condición cambia"}},period:{header:"Período",start_date:"De",end_date:"A"},repeat_type:"comportamiento despues de finalizar ",tags:"Etiquetas"},card_editor:{tabs:{entities:"Entidades",other:"Otros"},fields:{title:{heading:"Títujo de la tarjeta",options:{standard:"estándar",hidden:"oculta",custom:"personalizada"},custom_title:"Título personalizado"},discover_existing:{heading:"Mostrar todos los horarios",description:"Esto ajustará el parámetro 'descubrir existentes (discover existing)'. Los horarios creados anteriormente deberán de ser agregados automáticamente a la tarjeta."},time_step:{heading:"Paso de tiempo",description:"Resolución (en minutos) para la creación de horarios.",unit_minutes:"min"},default_editor:{heading:"Editor de tiempo por defecto",options:{single:"Modo de horario sencillo",scheme:"Modo de esquema de tiempo"}},sort_by:{heading:"Opciones de clasificación",description:"Orden en que los horarios aparecen en la tarjeta",options:{relative_time:"Tiempo restante hasta la siguiente acción",title:"Título mostrado del horario",state:"Mostrar los horarios activos primero"}},display_format_primary:{heading:"Mostrar información primaria",description:"Configura que etiqueta se utiliza para los horarios en la vista principal",options:{default:"Nombre del horario",entity_action:"Resumen de la tarea"}},display_format_secondary:{heading:"Mostrar información secundaria",description:"Configura que propiedades adicionales son visibles en la vista principal",options:{relative_time:"Tiempo restante hasta la siguiente acción",time:"Tiempo configurado para la siguiente acción",days:"Días repetidos de la semana",additional_tasks:"Número de tareas adicionales"}},show_header_toggle:{heading:"Mostrar el interruptor del encabezado",description:"Muestra el interruptor en la parte alta de la tarjeta para habilitar/desabilitar todas las entidades Show toggle switch at the top of the card for enabling/disabling all entities"},show_toggle_switches:{heading:"Mostrar interruptores",description:"Mostrar el interruptor para cada programación individual en la tarjeta"},tags:{heading:"Etiquetas",description:"Use etiquetas para dividir los horarios entre múltiples tarjetas"},entities:{button_label:"Configurar entidades incluidas",heading:"Entidades incluidas",description:"Seleccione las entidades que desea controlar usando el planificador. Puede hacer click en un grupo para abrirlo. Note que algunas entidades (como los sensores) solo pueden ser usados para condiciones, no para acciones.",included_number:"{number}/{total} seleccionados"}}}}},St={services:jt,ui:Ot},zt=Object.freeze({__proto__:null,default:St,services:jt,ui:Ot}),Ct={generic:{turn_on:"Lülita sisse",turn_off:"Lülita välja",parameter_to_value:"{parameter} {value} jaoks",action_with_parameter:"{action} väärtusega {parameter}"},climate:{set_temperature:"vali temperatuur [{temperature}]",set_temperature_hvac_mode_heat:"küte[ @ {temperature}]",set_temperature_hvac_mode_cool:"jahutus [ @ {temperature}]",set_temperature_hvac_mode_heat_cool:"küte/jahutus[ @ {temperature}]",set_temperature_hvac_mode_heat_cool_range:"küte/jahutus[ @ {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"automaatne[ @ {temperature}]",set_hvac_mode:"vali režiim [{hvac_mode}]",set_preset_mode:"eelseade[ {preset_mode}]",set_fan_mode:"set fan mode[ to {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"sulge",open_cover:"ava",set_cover_position:"sea asendisse[{position}]",set_cover_tilt_position:"sea ribide kalle [ asendisse {tilt_position}]"},fan:{set_percentage:"vali kiirus[ @ {speed}]",set_direction:"vali suund[ @ {direction}]",oscillate:"vali hajutus[ @ {oscillate}]"},humidifier:{set_humidity:"sea niiskus[ {humidity}]",set_mode:"vali režiim [{mode}]"},input_number:{set_value:"vali väärtus[ {value}]"},input_select:{select_option:"valik[ {option}]"},select:{select_option:"valik[ {option}]"},light:{turn_on:"lülita sisse[ heledusega {brightness}]"},media_player:{select_source:"vali sisend[ {source}]"},notify:{send_message:"send notification"},script:{execute:"käivita"},vacuum:{start_pause:"alusta/ootele"},water_heater:{set_operation_mode:"vali režiim [{operation_mode}]",set_away_mode:"kodust ära"}},At={components:{date:{day_types_short:{daily:"iga päev",workdays:"tööpäevadel",weekend:"nädalavahetusel"},day_types_long:{daily:"iga päev",workdays:"tööpäevadel",weekend:"nädalavahetusel"},days:"päeva",tomorrow:"homme",repeated_days:"iga {days} järel",repeated_days_except:"iga päev aga mitte {excludedDays}",days_range:"{startDay} kuni {endDay}",next_week_day:"järgmisel {weekday}"},time:{absolute:"{time}",interval:"{startTime} kuni {endTime}",at_midnight:"keskööl",at_noon:"keskpäeval",at_sun_event:"{sunEvent}"}},dialog:{enable_schedule:{title:"Viige muudatused lõpule",description:"Muudetud ajakava on praegu keelatud, kas see peaks olema lubatud?"},confirm_delete:{title:"Kas eemaldan olemi?",description:"Oled kindel, et soovid selle olemi eemaldada?"},confirm_migrate:{title:"Muutke ajakava",description:"Selle muudatusega lähevad mõned seaded kaotsi. Kas soovite jätkata?"},weekday_picker:{title:"Repeated days for schedule",choose:"Choose..."},entity_picker:{title:"Choose entities",choose:"Choose...",no_results:"No matching items found"},action_picker:{title:"Choose action",show_all:"Show all supported entities"}},panel:{common:{title:"Ajastaja",new_schedule:"Uus ajakava",default_name:"Ajakava #{id}"},overview:{no_entries:"Ajastused puuduvad",backend_error:"Ajastaja sidumine puudub. Sidumine tuleb luua enne selle kaardi kasutamist.",excluded_items:"välja on jäetud {number}  {if number is 1} ajastus {else} ajastust",hide_excluded:"peida välja jäetud ajastused",additional_tasks:"veel {number} {if number is 1} ajastus {else} ajastust"},editor:{repeated_days:"Repeated days",start_time:"Start time",stop_time:"End time",action:"Action",add_action:"Add action",select_timeslot:"Alustuseks vali ajavahemik",toggle_single_mode:"Üksikrežiimile",toggle_scheme_mode:"Skeemirežiimile",validation_errors:{overlapping_time:"Schedule has overlapping timeslots",missing_target_entity:"One or more actions are missing a target entity",missing_service_parameter:"One or more actions are missing a required setting",missing_action:"Schedule has no actions"}},options:{conditions:{header:"Conditions",add_condition:"Add condition",new_condition:"New condition",types:{equal_to:"{entity} is equal to {value}",unequal_to:"{entity} is unequal to {value}",above:"{entity} is above {value}",below:"{entity} is below {value}"},options:{logic_and:"All conditions must be true",logic_or:"Any condition must be true",track_changes:"Re-evaluate when conditions change"}},period:{header:"Periood",start_date:"From",end_date:"To"},repeat_type:"toiming peale käivitumist",tags:"Tags"},card_editor:{tabs:{entities:"Entities",other:"Other"},fields:{title:{heading:"Title of the card",options:{standard:"standard",hidden:"hidden",custom:"custom"},custom_title:"Custom title"},discover_existing:{heading:"Show all schedules",description:"This sets the 'discover existing' parameter. Previously created schedules will be automatically added to the card. "},time_step:{heading:"Time step",description:"Resolution (in minutes) for creating schedules",unit_minutes:"min"},default_editor:{heading:"Default time editor",options:{single:"Single schedule mode",scheme:"Time scheme mode"}},sort_by:{heading:"Sorting options",description:"Order in which the schedules appear in the card",options:{relative_time:"Time remaining until next action",title:"Displayed title of the schedule",state:"Show active schedules on top"}},display_format_primary:{heading:"Displayed primary info",description:"Configure which label is used for schedules in the overview",options:{default:"Schedule name",entity_action:"Summary of task"}},display_format_secondary:{heading:"Displayed secondary info",description:"Configure what additional properties are visible in the overview",options:{relative_time:"Time remaining until next action",time:"Configured time for next action",days:"Repeated days of the week",additional_tasks:"Number of additional tasks"}},show_header_toggle:{heading:"Show header toggle",description:"Show toggle switch at the top of the card for enabling/disabling all entities"},show_toggle_switches:{heading:"Show toggle switches",description:"Show toggle switch for each individual schedule in the card"},tags:{heading:"Tags",description:"Use tags to divide schedules between multiple cards"},entities:{button_label:"Configure included entities",heading:"Included entities",description:"Select the entities that you want to control using the scheduler. You can click on a group to open it. Note that some entities (such as sensors) can only be used for conditions, not for actions.",included_number:"{number}/{total} selected"}}}}},Et={services:Ct,ui:At},Tt=Object.freeze({__proto__:null,default:Et,services:Ct,ui:At}),Dt={generic:{turn_on:"Laita päälle",turn_off:"Sammuta",parameter_to_value:"{parameter} {value}",action_with_parameter:"{action} {parameter}"},climate:{set_temperature:"aseta lämpötilaksi[ {temperature}]",set_temperature_hvac_mode_heat:"lämmitä[ {temperature} asteeseen]",set_temperature_hvac_mode_cool:"jäähdytä[ {temperature} asteeseen]",set_temperature_hvac_mode_heat_cool:"lämmitä/jäähdytä[ {temperature} asteeseen]",set_temperature_hvac_mode_heat_cool_range:"lämmitä/jäähdytä[ välillä {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"automaatilla[ {temperature} asteeseen]",set_hvac_mode:"aseta tilaksi[ {hvac_mode}]",set_preset_mode:"aseta esivalinta[ {preset_mode}]",set_fan_mode:"aseta tuuletus[ {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"sulje",open_cover:"avaa",set_cover_position:"aseta sijainniksi[ {position}]",set_cover_tilt_position:"aseta kallistus[ {tilt_position}]"},fan:{set_percentage:"aseta nopeus[ {speed}]",set_direction:"asenta suunta[ {direction}]",oscillate:"aseta pyörimisnopeus[ {oscillate}]"},humidifier:{set_humidity:"aseta kosteus[ {humidity}]",set_mode:"aseta tilaksi {mode}"},input_number:{set_value:"aseta arvo {value}"},input_select:{select_option:"valitse[ {option}]"},select:{select_option:"valitse[ {option}]"},light:{turn_on:"kytke päälle[ {brightness} kirkkaudella]"},media_player:{select_source:"valitse lähteeksi[ {source}]"},notify:{send_message:"lähetä ilmoitus"},script:{execute:"suorita"},vacuum:{start_pause:"aloita / keskeytä"},water_heater:{set_operation_mode:"aseta tilaksi[ {operation_mode}]",set_away_mode:"aseta poissa-tila"}},Mt={components:{date:{day_types_short:{daily:"päivittäin",workdays:"työpäivisin",weekend:"viikonloppuisin"},day_types_long:{daily:"päivittäin",workdays:"työpäivisin",weekend:"viikonloppuisin"},days:"päivää",tomorrow:"huomenna",repeated_days:"joka {days}",repeated_days_except:"joka päivä paitsi {excludedDays}",days_range:"{startDay} {endDay}",next_week_day:"seuraava {weekday}"},time:{absolute:"{time}",interval:"{startTime} - {endTime}",at_midnight:"keskiyöllä",at_noon:"keskipäivällä",at_sun_event:"{sunEvent}"}},dialog:{enable_schedule:{title:"Suorita muutokset loppuun",description:"Muutettu aikataulu on tällä hetkellä poissa käytöstä, pitäisikö se ottaa käyttöön?"},confirm_delete:{title:"Poistetaanko kohde?",description:"Haluatko varmasti poistaa tämän kohteen?"},confirm_migrate:{title:"Muokkaa aikataulua",description:"Jotkut asetukset menetetään tämän muutoksen seurauksena. Haluatko edetä?"},weekday_picker:{title:"Repeated days for schedule",choose:"Choose..."},entity_picker:{title:"Choose entities",choose:"Choose...",no_results:"No matching items found"},action_picker:{title:"Choose action",show_all:"Show all supported entities"}},panel:{common:{title:"Ajastin",new_schedule:"Uusi aikataulu",default_name:"Aikataulu #{id}"},overview:{no_entries:"Ei näytettäviä kohteita",backend_error:"Ei voitu yhdistää scheduler komponenttiin. Kortin käyttäminen vaatii scheduler integraation asentamisen.",excluded_items:"{number} {if number is 1} poissuljettu kohde {else} poissuljettua kohdetta",hide_excluded:"piilota poissuljetut kohteet",additional_tasks:"{number} {if number is 1} tehtävä {else} tehtävää"},editor:{repeated_days:"Repeated days",start_time:"Start time",stop_time:"End time",action:"Action",add_action:"Add action",select_timeslot:"Valitse aikaikkuna ensin",toggle_single_mode:"To single mode",toggle_scheme_mode:"To scheme mode",validation_errors:{overlapping_time:"Schedule has overlapping timeslots",missing_target_entity:"One or more actions are missing a target entity",missing_service_parameter:"One or more actions are missing a required setting",missing_action:"Schedule has no actions"}},options:{conditions:{header:"Conditions",add_condition:"Add condition",new_condition:"New condition",types:{equal_to:"{entity} is equal to {value}",unequal_to:"{entity} is unequal to {value}",above:"{entity} is above {value}",below:"{entity} is below {value}"},options:{logic_and:"All conditions must be true",logic_or:"Any condition must be true",track_changes:"Re-evaluate when conditions change"}},period:{header:"Ajanjakso",start_date:"From",end_date:"To"},repeat_type:"toiminta tapahtuman jälkeen",tags:"Tags"},card_editor:{tabs:{entities:"Kohteet",other:"Muu"},fields:{title:{heading:"Kortin otsikko",options:{standard:"normaali",hidden:"piilotettu",custom:"muokattu"},custom_title:"Muokattu otsikko"},discover_existing:{heading:"Näytä kaikki ajoitukset",description:"Tämä kytkee käyttöön 'näytä olemassa olevat -attribuutin'. Aiemmin luodut ajastukset lisätään automaattisesti korttiin. "},time_step:{heading:"Ajastusvälit",description:"Ajastusväli minuutteina ajastusten luontiin",unit_minutes:"min"},default_editor:{heading:"Default time editor",options:{single:"Yksittäistilaan",scheme:"Kaaviotilaan"}},sort_by:{heading:"Lajitteluasetukset",description:"Järjestys miten ajastukset näkyvät kortissa",options:{relative_time:"Aikaa jäljellä seuraavaan toimintoon",title:"Ajastuksen otsikko",state:"Aktiiviset ajastukset ylhäällä"}},display_format_primary:{heading:"Ensisijainen tieto",description:"Valitse mitä näytetään yhteenvedossa",options:{default:"Ajastuksen nimi",entity_action:"Ajastuksen yhteenveto"}},display_format_secondary:{heading:"Toissijainen tieto",description:"Valitse mitkä lisätiedot näkyvät yhteenvedossa",options:{relative_time:"Aikaa jäljellä seuraavaan toimintoon",time:"Seuraavalle toiminnolle määritetty aika",days:"Toistuvat viikonpäivät",additional_tasks:"Lisätoimintojen määrä"}},show_header_toggle:{heading:"Näytä otsikkokytkin",description:"Näytä kytkin kortin yläreunassa usean ajastuksen päälle/pois kytkemiseen"},show_toggle_switches:{heading:"Näytä kytkimet",description:"Näytä kytkin jokaiselle yksittäiselle ajastukselle kortissa"},tags:{heading:"Tunniste",description:"Käytä tunnisteita ajastusten jakamiseen korttien välillä"},entities:{button_label:"Sisällytettyjen entiteettien määrittäminen",heading:"Ajastettavat kohteet",description:"Valitse kohteet, joille haluat luoda ajastuksia. Voit klikata ryhmään laajentaaksesi sen. Huom: joitain kohteita voi käyttää vain ehtoina (esim. sensorit), ei toimintoihin",included_number:"{number} / {total} valittu"}}}}},Lt={services:Dt,ui:Mt},Nt=Object.freeze({__proto__:null,default:Lt,services:Dt,ui:Mt}),Pt={generic:{turn_on:"Allumer",turn_off:"Éteindre",parameter_to_value:"{parameter} vers {value}",action_with_parameter:"{action} avec {parameter}"},climate:{set_temperature:"ajuster la température[ à {temperature}]",set_temperature_hvac_mode_heat:"chauffe[ à {temperature}]",set_temperature_hvac_mode_cool:"refroidit[ à {temperature}]",set_temperature_hvac_mode_heat_cool:"chauffe/refroidit[ à {temperature}]",set_temperature_hvac_mode_heat_cool_range:"chauffe/refroidit[ à {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"auto[ à {temperature}]",set_hvac_mode:"ajuster le mode[ à {hvac_mode}]",set_preset_mode:"choisir le pré-réglage[ {preset_mode}]",set_fan_mode:"ajuster le mode de ventilation[ à {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"fermer",open_cover:"ouvrir",set_cover_position:"ajuster la position[ à {position}]",set_cover_tilt_position:"régler les volets[ à {tilt_position}]"},fan:{set_percentage:"ajuster la vitesse[ à {speed}]",set_direction:"ajuster l'orientation[ vers {direction}]",oscillate:"ajuster l'oscillation[ à {oscillate}]"},humidifier:{set_humidity:"ajuster l'humidité[ à {humidity}]",set_mode:"ajuster le mode[ à {mode}]"},input_number:{set_value:"ajuster la valeur[ à {value}]"},input_select:{select_option:"choisir l'option[ {option}]"},select:{select_option:"choisir l'option[ {option}]"},light:{turn_on:"allumer[ avec une luminosité de {brightness}]"},media_player:{select_source:"choisir la source[ {source}]"},notify:{send_message:"envoyer une notification"},script:{execute:"exécuter"},vacuum:{start_pause:"démarrer / pause"},water_heater:{set_operation_mode:"ajuster le mode[ à {operation_mode}]",set_away_mode:"choisir le mode absent"}},It={components:{date:{day_types_short:{daily:"quotidien",workdays:"jours de travail",weekend:"weekend"},day_types_long:{daily:"chaque jour",workdays:"en semaine",weekend:"le weekend"},days:"jours",tomorrow:"demain",repeated_days:"chaque {days}",repeated_days_except:"chaque jour sauf {excludedDays}",days_range:"de {startDay} à {endDay}",next_week_day:"{weekday} prochain"},time:{absolute:"à {time}",interval:"de {startTime} à {endTime}",at_midnight:"à minuit",at_noon:"à midi",at_sun_event:"au {sunEvent}"}},dialog:{enable_schedule:{title:"Compléter les modifications",description:"Le planning qui a été modifié est actuellement désactivé, doit-il être activé ?"},confirm_delete:{title:"Supprimer l'entité ?",description:"Voulez-vous vraiment supprimer cette entité ?"},confirm_migrate:{title:"Modifier l'horaire",description:"Certains paramètres seront perdus par ce changement. Voulez-vous poursuivre?"},weekday_picker:{title:"Jours de répétition",choose:"Choisir les jours..."},entity_picker:{title:"Choisir les entités",choose:"Choisir...",no_results:"Aucune entité trouvée"},action_picker:{title:"Choisir une action",show_all:"Afficher toutes les entités prises en charge"}},panel:{common:{title:"Planificateur",new_schedule:"Nouvel horaire",default_name:"Horaire #{id}"},overview:{no_entries:"il n'y a pas d'entrée à montrer",backend_error:"Impossible de se connecter au composant du planificateur. Il doit être installé en tant qu'intégration avant que cette carte ne puisse être utilisée.",excluded_items:"{number} {if number is 1}entrée exclue{else}entrées exclues",hide_excluded:"cacher les entrées exclues",additional_tasks:"{number} {if number is 1}tâche à venir{else}tâches à venir"},editor:{repeated_days:"Jours de répétition",start_time:"Heure de début",stop_time:"Heure de fin",action:"Action",add_action:"Ajouter une action",select_timeslot:"Choisir d'abord une plage horaire",toggle_single_mode:"Vers mode simple",toggle_scheme_mode:"Vers mode schéma",validation_errors:{overlapping_time:"Certaines plages horaires se chevauchent",missing_target_entity:"Certaines actions n'ont pas d'entité sélectionnée",missing_service_parameter:"Certaines actions ne sont pas totalement configurées",missing_action:"Le planning n'a aucune action définie"}},options:{conditions:{header:"Conditions",add_condition:"Ajouter une condition",new_condition:"Nouvelle condition",types:{equal_to:"{entity} est égal à {value}",unequal_to:"{entity} n'est pas égal à {value}",above:"{entity} est supérieur à {value}",below:"{entity} est inférieur à {value}"},options:{logic_and:"Toutes les conditions doivent être valides",logic_or:"Au moins une condition doit être valide",track_changes:"Ré-évaluer lorsque la condition change"}},period:{header:"Période",start_date:"Du",end_date:"Au"},repeat_type:"Comportement après l'achèvement",tags:"Tags"},card_editor:{tabs:{entities:"Entities",other:"Other"},fields:{title:{heading:"Title of the card",options:{standard:"standard",hidden:"hidden",custom:"custom"},custom_title:"Custom title"},discover_existing:{heading:"Show all schedules",description:"This sets the 'discover existing' parameter. Previously created schedules will be automatically added to the card. "},time_step:{heading:"Time step",description:"Resolution (in minutes) for creating schedules",unit_minutes:"min"},default_editor:{heading:"Default time editor",options:{single:"Single schedule mode",scheme:"Time scheme mode"}},sort_by:{heading:"Sorting options",description:"Order in which the schedules appear in the card",options:{relative_time:"Time remaining until next action",title:"Displayed title of the schedule",state:"Show active schedules on top"}},display_format_primary:{heading:"Displayed primary info",description:"Configure which label is used for schedules in the overview",options:{default:"Schedule name",entity_action:"Summary of task"}},display_format_secondary:{heading:"Displayed secondary info",description:"Configure what additional properties are visible in the overview",options:{relative_time:"Time remaining until next action",time:"Configured time for next action",days:"Repeated days of the week",additional_tasks:"Number of additional tasks"}},show_header_toggle:{heading:"Show header toggle",description:"Show toggle switch at the top of the card for enabling/disabling all entities"},show_toggle_switches:{heading:"Show toggle switches",description:"Show toggle switch for each individual schedule in the card"},tags:{heading:"Tags",description:"Use tags to divide schedules between multiple cards"},entities:{button_label:"Configure included entities",heading:"Included entities",description:"Select the entities that you want to control using the scheduler. You can click on a group to open it. Note that some entities (such as sensors) can only be used for conditions, not for actions.",included_number:"{number}/{total} selected"}}}}},qt={services:Pt,ui:It},Rt=Object.freeze({__proto__:null,default:qt,services:Pt,ui:It}),Vt={generic:{turn_on:"הפעלה",turn_off:"כיבוי",parameter_to_value:"{parameter} ל {value}",action_with_parameter:"{action} עם {parameter}"},climate:{set_temperature:"קבע טמפרטורה[ ל {temperature}]",set_temperature_hvac_mode_heat:"חימום[ ל {temperature}]",set_temperature_hvac_mode_cool:"קירור[ ל {temperature}]",set_temperature_hvac_mode_heat_cool:"חימום/קירור[ ל {temperature}]",set_temperature_hvac_mode_heat_cool_range:"חימום/קירור[ ל {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"אוטומטי[ ל {temperature}]",set_hvac_mode:"קבע מצב עבודה[ ל {hvac_mode}]",set_preset_mode:"קבע הגדרה[ ל {preset_mode}]",set_fan_mode:"הגדר מצב מאוורר[ ל {fan_mode}]",set_swing_mode:"הגדר מצב תנודת תריס[ ל {swing_mode}]"},cover:{close_cover:"סגירה",open_cover:"פתיחה",set_cover_position:"קבע מיקום[ ל {position}]",set_cover_tilt_position:"קבע הטיה[ ל {tilt_position}]"},fan:{set_percentage:"קבע מהירות[ ל {speed}]",set_direction:"קבע כיוון[ ל {direction}]",oscillate:"קבע תנודת תריס[ ל {oscillate}]"},humidifier:{set_humidity:"קבע לחות[ ל {humidity}]",set_mode:"קבע מצב עבודה[ ל {mode}]"},input_number:{set_value:"קבע ערך[ ל {value}]"},input_select:{select_option:"בחר אפשרות[ {option}]"},select:{select_option:"בחר אפשרות[ {option}]"},light:{turn_on:"הדלקה[ בעוצמה של {brightness}]"},media_player:{select_source:"בחר מקור[ {source}]"},notify:{send_message:"שלח התראה"},script:{execute:"בצע"},vacuum:{start_pause:"התחל / הפסק"},water_heater:{set_operation_mode:"קבע מצב עבודה[ ל {operation_mode}]",set_away_mode:"קבע מצב מוץ לבית"}},Ht={components:{date:{day_types_short:{daily:"כל יום",workdays:"ימי חול",weekend:"סוף שבוע"},day_types_long:{daily:"כל יום",workdays:"בימי חול",weekend:"בסוף השבוע"},days:"ימים",tomorrow:"מחר",repeated_days:"בכל {days}",repeated_days_except:"בכל יום פרט ל  {excludedDays}",days_range:"מ- {startDay} ועד- {endDay}",next_week_day:"הבא {weekday}"},time:{absolute:"בשעה {time}",interval:"משעה {startTime} עד שעה {endTime}",at_midnight:"בחצות הלילה",at_noon:"בחצות היום",at_sun_event:"ב {sunEvent}"}},dialog:{enable_schedule:{title:"השלם את השינויים",description:"לוח הזמנים ששונה מושבת כעת, האם צריך להפעיל אותו?"},confirm_delete:{title:"להסיר את הישות?",description:"האם בוודאות ברצונך להסיר ישות זו?"},confirm_migrate:{title:"שנה את לוח הזמנים",description:"חלק מההגדרות יאבדו על ידי פעולה זו. האם אתה רוצה להמשיך?"},weekday_picker:{title:"ימים לחזרה עבור לוח זמנים",choose:"בחר..."},entity_picker:{title:"בחר ישויות",choose:"בחר...",no_results:"לא נמצאו פריטים תואמים"},action_picker:{title:"בחר פעולה",show_all:"הצג את כל הישויות הנתמכות"}},panel:{common:{title:"לוח זמנים",new_schedule:"לוח זמנים חדש",default_name:"לוח זמנים #{id}"},overview:{no_entries:"אין פריטים להצגה",backend_error:"אין אפשרות להתחבר לרכיב התזמונים. נדרש להתקין את הרכיב באינטגרציה לפני השימוש בכרטיס.",excluded_items:"{number} לא נכלל {if number is 1} פריט {else} פריטים",hide_excluded:"הסתר פריטים לא כלולים",additional_tasks:"{number} נוסף {if number is 1} משימה {else} משימות"},editor:{repeated_days:"ימים לחזרה",start_time:"זמן התחלה",stop_time:"זמן סיום",action:"פעולה",add_action:"הוספת פעולה",select_timeslot:"בחר משבצת זמן קודם",toggle_single_mode:"למצב פשוט",toggle_scheme_mode:"למצב דיאגרמה",validation_errors:{overlapping_time:"לוח הזמנים כולל משבצות זמן חופפות",missing_target_entity:"אחת או יותר מהפעולות חסרות ישות יעד",missing_service_parameter:"אחת או יותר מהפעולות חסרות הגדרה נדרשת",missing_action:"לוח הזמנים אינו כולל פעולות"}},options:{conditions:{header:"תנאים",add_condition:"הוספת תנאי",new_condition:"תנאי חדש",types:{equal_to:"{entity} שווה ל-{value}",unequal_to:"{entity} לא שווה ל-{value}",above:"{entity} מעל {value}",below:"{entity} מתחת {value}"},options:{logic_and:"כל התנאים חייבים להיות נכונים",logic_or:"כל תנאי חייב להיות נכון",track_changes:"הערכה מחדש כאשר התנאים משתנים"}},period:{header:"פרק זמן",start_date:"מ",end_date:"ל"},repeat_type:"התנהגות לאחר הפעלה",tags:"תגים"},card_editor:{tabs:{entities:"ישויות",other:"אחר"},fields:{title:{heading:"כותרת הכרטיס",options:{standard:"רגילה",hidden:"מוסתרת",custom:"מותאמת אישית"},custom_title:"כותרת מותאמת אישית"},discover_existing:{heading:"הצג את כל לוחות הזמנים",description:"הגדרה זו קובעת את הפרמטר 'discover existing'. לוחות זמנים שנוצרו בעבר יתווספו אוטומטית לכרטיס"},time_step:{heading:"מרווח זמן",description:"רזולוציה (בדקות) ליצירת לוחות זמנים",unit_minutes:"דק'"},default_editor:{heading:"עורך זמן ברירת מחדל",options:{single:"מצב לוח זמנים בודד",scheme:"מצב תבנית זמנים"}},sort_by:{heading:"אפשרויות מיון",description:"סדר הופעת לוחות הזמנים בכרטיס",options:{relative_time:"זמן שנותר עד הפעולה הבאה",title:"כותרת לוח הזמנים המוצגת",state:"הצג לוחות זמנים פעילים בראש"}},display_format_primary:{heading:"מידע ראשי מוצג",description:"הגדר איזו תווית תשמש עבור לוחות הזמנים בסקירה הכללית",options:{default:"שם לוח הזמנים",entity_action:"סיכום המשימה"}},display_format_secondary:{heading:"מידע משני מוצג",description:"הגדר אילו מאפיינים נוספים יהיו גלויים בסקירה הכללית",options:{relative_time:"זמן שנותר עד הפעולה הבאה",time:"זמן מוגדר לפעולה הבאה",days:"ימים חוזרים בשבוע",additional_tasks:"מספר משימות נוספות"}},show_header_toggle:{heading:"הצג מתג בכותרת",description:"הצג מתג הפעלה/כיבוי בראש הכרטיס להפעלה/השבתה של כל הישויות"},show_toggle_switches:{heading:"הצג מתגים",description:"הצג מתג עבור כל לוח זמנים בודד בכרטיס"},tags:{heading:"תגיות",description:"השתמש בתגיות כדי לחלק לוחות זמנים בין כרטיסים שונים"},entities:{button_label:"הגדר ישויות כלולות",heading:"ישויות כלולות",description:"בחר את הישויות שברצונך לשלוט בהן באמצעות המתזמן. ניתן ללחוץ על קבוצה כדי לפתוח אותה. שים לב שחלק מהישויות (כמו חיישנים) יכולות לשמש רק לתנאים, ולא לפעולות.",included_number:"{number}/{total} נבחרו"}}}}},Ut={services:Vt,ui:Ht},Ft=Object.freeze({__proto__:null,default:Ut,services:Vt,ui:Ht}),Bt={generic:{turn_on:"Bekapcsolás",turn_off:"Kikapcsolás",parameter_to_value:"{parameter} to {value}",action_with_parameter:"{action} with {parameter}"},climate:{set_temperature:"hőmérséklet[ to {temperature}]",set_temperature_hvac_mode_heat:"melegíteni[ to {temperature}]",set_temperature_hvac_mode_cool:"hűtés[ to {temperature}]",set_temperature_hvac_mode_heat_cool:"melegíteni/hűtés[ to {temperature}]",set_temperature_hvac_mode_heat_cool_range:"melegíteni/hűtés[ to {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"automatikus[ to {temperature}]",set_hvac_mode:"mód beállítása[ to {hvac_mode}]",set_preset_mode:"preset beállítása[ {preset_mode}]",set_fan_mode:"set fan mode[ to {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"zárás",open_cover:"nyitás",set_cover_position:"változtass pozíciót[ to {position}]",set_cover_tilt_position:"set tilt position[ to {tilt_position}]"},fan:{set_percentage:"set speed[ to {speed}]",set_direction:"set direction[ to {direction}]",oscillate:"set oscillation[ to {oscillate}]"},humidifier:{set_humidity:"set humidity[ to {humidity}]",set_mode:"mód beállítása[ to {mode}]"},input_number:{set_value:"érték beállítása[ to {value}]"},input_select:{select_option:"opció kiválasztása[ {option}]"},select:{select_option:"opció kiválasztása[ {option}]"},light:{turn_on:"bekapcsolás[ with {brightness} brightness]"},media_player:{select_source:"forrás kiválasztása[ {source}]"},notify:{send_message:"send notification"},script:{execute:"kezdés"},vacuum:{start_pause:"start / pause"},water_heater:{set_operation_mode:"mód beállítása[ to {operation_mode}]",set_away_mode:"set away mode"}},Wt={components:{date:{day_types_short:{daily:"minden nap",workdays:"munkanapokon",weekend:"hétvégén"},day_types_long:{daily:"minden nap",workdays:"munkanapokon",weekend:"hétvégén"},days:"Napokon",tomorrow:"tomorrow",repeated_days:"every {days}",repeated_days_except:"every day except {excludedDays}",days_range:"from {startDay} to {endDay}",next_week_day:"következő {weekday}"},time:{absolute:"{time}-kor",interval:"{startTime} - {endTime}",at_midnight:"éjfélkor",at_noon:"délben",at_sun_event:"{sunEvent}kor"}},dialog:{enable_schedule:{title:"Végezze el a módosításokat",description:"A módosított ütemezés jelenleg le van tiltva, engedélyezni kell?"},confirm_delete:{title:"Biztos benne, hogy eltávolítja az entitást?",description:"Biztos benne, hogy el szeretné távolítani ezt az entitást?"},confirm_migrate:{title:"Ütemezés módosítása",description:"Ezzel a művelettel bizonyos beállítások elvesznek. Akarod folytatni?"},weekday_picker:{title:"Repeated days for schedule",choose:"Choose..."},entity_picker:{title:"Choose entities",choose:"Choose...",no_results:"No matching items found"},action_picker:{title:"Choose action",show_all:"Show all supported entities"}},panel:{common:{title:"Időzítések",new_schedule:"Új ütemezés",default_name:"Ütemterv #{id}"},overview:{no_entries:"Nincs megjeleníthető elem",backend_error:"Could not connect with the scheduler component. It needs to be installed as integration before this card can be used.",excluded_items:"{number} excluded {if number is 1} item {else} items",hide_excluded:"hide excluded items",additional_tasks:"még {number} feladat"},editor:{repeated_days:"Repeated days",start_time:"Start time",stop_time:"End time",action:"Action",add_action:"Add action",select_timeslot:"Select a timeslot",toggle_single_mode:"Egyszerű módba",toggle_scheme_mode:"Diagram módba",validation_errors:{overlapping_time:"Schedule has overlapping timeslots",missing_target_entity:"One or more actions are missing a target entity",missing_service_parameter:"One or more actions are missing a required setting",missing_action:"Schedule has no actions"}},options:{conditions:{header:"Conditions",add_condition:"Add condition",new_condition:"New condition",types:{equal_to:"{entity} is equal to {value}",unequal_to:"{entity} is unequal to {value}",above:"{entity} is above {value}",below:"{entity} is below {value}"},options:{logic_and:"All conditions must be true",logic_or:"Any condition must be true",track_changes:"Re-evaluate when conditions change"}},period:{header:"Időszak",start_date:"From",end_date:"To"},repeat_type:"behaviour after completion",tags:"Tags"},card_editor:{tabs:{entities:"Entities",other:"Other"},fields:{title:{heading:"Title of the card",options:{standard:"standard",hidden:"hidden",custom:"custom"},custom_title:"Custom title"},discover_existing:{heading:"Show all schedules",description:"This sets the 'discover existing' parameter. Previously created schedules will be automatically added to the card. "},time_step:{heading:"Time step",description:"Resolution (in minutes) for creating schedules",unit_minutes:"min"},default_editor:{heading:"Default time editor",options:{single:"Single schedule mode",scheme:"Time scheme mode"}},sort_by:{heading:"Sorting options",description:"Order in which the schedules appear in the card",options:{relative_time:"Time remaining until next action",title:"Displayed title of the schedule",state:"Show active schedules on top"}},display_format_primary:{heading:"Displayed primary info",description:"Configure which label is used for schedules in the overview",options:{default:"Schedule name",entity_action:"Summary of task"}},display_format_secondary:{heading:"Displayed secondary info",description:"Configure what additional properties are visible in the overview",options:{relative_time:"Time remaining until next action",time:"Configured time for next action",days:"Repeated days of the week",additional_tasks:"Number of additional tasks"}},show_header_toggle:{heading:"Show header toggle",description:"Show toggle switch at the top of the card for enabling/disabling all entities"},show_toggle_switches:{heading:"Show toggle switches",description:"Show toggle switch for each individual schedule in the card"},tags:{heading:"Tags",description:"Use tags to divide schedules between multiple cards"},entities:{button_label:"Configure included entities",heading:"Included entities",description:"Select the entities that you want to control using the scheduler. You can click on a group to open it. Note that some entities (such as sensors) can only be used for conditions, not for actions.",included_number:"{number}/{total} selected"}}}}},Zt={services:Bt,ui:Wt},Kt=Object.freeze({__proto__:null,default:Zt,services:Bt,ui:Wt}),Gt={generic:{turn_on:"Accendi",turn_off:"Spegni",parameter_to_value:"{parameter} a {value}",action_with_parameter:"{action} con {parameter}"},climate:{set_temperature:"imposta temperatura[ a {temperature}]",set_temperature_hvac_mode_heat:"riscaldamento[ a {temperature}]",set_temperature_hvac_mode_cool:"raffrescamento[ a {temperature}]",set_temperature_hvac_mode_heat_cool:"riscaldamento/raffrescamento[ a {temperature}]",set_temperature_hvac_mode_heat_cool_range:"riscaldamento/raffrescamento[ a {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"auto[ a {temperature}]",set_hvac_mode:"imposta modalità[ a {hvac_mode}]",set_preset_mode:"imposta programmazione[ {preset_mode}]",set_fan_mode:"set fan mode[ to {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"chiuso",open_cover:"aperto",set_cover_position:"imposta posizione[ su {position}]",set_cover_tilt_position:"imposta inclinazione[ su {tilt_position}]"},fan:{set_percentage:"imposta velocità[ a {speed}]",set_direction:"imposta direzione[ a {direction}]",oscillate:"imposta oscillazione[ a {oscillate}]"},humidifier:{set_humidity:"imposta umidità[ a {humidity}]",set_mode:"imposta modalità[ a {mode}]"},input_number:{set_value:"imposta valore[ a {value}]"},input_select:{select_option:"seleziona opzione[ {option}]"},select:{select_option:"seleziona opzione[ {option}]"},light:{turn_on:"accendi[ con il {brightness} di luminosità]"},media_player:{select_source:"seleziona sorgente[ {source}]"},notify:{send_message:"invia notifica"},script:{execute:"esegui"},vacuum:{start_pause:"avvia / pausa"},water_heater:{set_operation_mode:"imposta modalità[ a {operation_mode}]",set_away_mode:"imposta fuori casa"}},Jt={components:{date:{day_types_short:{daily:"giornaliero",workdays:"giorni lavorativi",weekend:"weekend"},day_types_long:{daily:"ogni giorno",workdays:"nei giorni lavorativi",weekend:"nel weekend"},days:"giorni",tomorrow:"domani",repeated_days:"ogni {days}",repeated_days_except:"ogni giorno tranne {excludedDays}",days_range:"{if startDay is domenica} dalla domenica {else} dal {startDay} {if endDay is domenica} alla domenica {else} al {endDay}",next_week_day:"prossimo {weekday}"},time:{absolute:"alle {time}",interval:"dalle {startTime} alle {endTime}",at_midnight:"a mezzanotte",at_noon:"a mezzogiorno",at_sun_event:"al {sunEvent}"}},dialog:{enable_schedule:{title:"Completa le modifiche",description:"La pianificazione modificata è attualmente disabilitata, dovrebbe essere abilitata?"},confirm_delete:{title:"Vuoi rimuovere l'entità?",description:"Sei sicuro di voler rimuovere questa entità?"},confirm_migrate:{title:"Modifica orario",description:"Alcune impostazioni andranno perse con questa azione. Vuoi procedere?"},weekday_picker:{title:"Giorni ripetuti per la pianificazione",choose:"Scegli..."},entity_picker:{title:"Scegli entità",choose:"Scegli...",no_results:"Nessun elemento corrispondente trovato"},action_picker:{title:"Scegli azione",show_all:"Mostra tutte le entità supportate"}},panel:{common:{title:"Schedulatore",new_schedule:"Nuovo orario",default_name:"Orario #{id}"},overview:{no_entries:"Non ci sono oggetti da visualizzare",backend_error:"Impossibile connettersi con il componente scheduler. Deve essere installato come integrazione prima di poter utilizzare questa card.",excluded_items:"{number} {if number is 1} oggetto escluso {else} oggetti esclusi",hide_excluded:"Nascondi oggetti esclusi",additional_tasks:"{number} attività in più"},editor:{repeated_days:"Giorni ripetuti",start_time:"Ora di inizio",stop_time:"Ora di fine",action:"Azione",add_action:"Aggiungi azione",select_timeslot:"Seleziona una fascia oraria",toggle_single_mode:"Alla modo semplice",toggle_scheme_mode:"Alla modo schema",validation_errors:{overlapping_time:"Il programma ha fasce orarie sovrapposte",missing_target_entity:"Una o più azioni mancano di un'entità target",missing_service_parameter:"Una o più azioni mancano di un'impostazione richiesta",missing_action:"Il programma non ha azioni"}},options:{conditions:{header:"Condizioni",add_condition:"Aggiungi condizione",new_condition:"Nuova condizione",types:{equal_to:"{entity} è uguale a {value}",unequal_to:"{entity} è diverso da {value}",above:"{entity} è superiore a {value}",below:"{entity} è inferiore a {value}"},options:{logic_and:"Tutte le condizioni devono essere vere",logic_or:"Qualsiasi condizione deve essere vera",track_changes:"Rivaluta quando cambiano le condizioni"}},period:{header:"Periodo",start_date:"From",end_date:"To"},repeat_type:"comportamento dopo il completamento",tags:"Tags"},card_editor:{tabs:{entities:"Entities",other:"Other"},fields:{title:{heading:"Title of the card",options:{standard:"standard",hidden:"hidden",custom:"custom"},custom_title:"Custom title"},discover_existing:{heading:"Show all schedules",description:"This sets the 'discover existing' parameter. Previously created schedules will be automatically added to the card. "},time_step:{heading:"Time step",description:"Resolution (in minutes) for creating schedules",unit_minutes:"min"},default_editor:{heading:"Default time editor",options:{single:"Single schedule mode",scheme:"Time scheme mode"}},sort_by:{heading:"Sorting options",description:"Order in which the schedules appear in the card",options:{relative_time:"Time remaining until next action",title:"Displayed title of the schedule",state:"Show active schedules on top"}},display_format_primary:{heading:"Displayed primary info",description:"Configure which label is used for schedules in the overview",options:{default:"Schedule name",entity_action:"Summary of task"}},display_format_secondary:{heading:"Displayed secondary info",description:"Configure what additional properties are visible in the overview",options:{relative_time:"Time remaining until next action",time:"Configured time for next action",days:"Repeated days of the week",additional_tasks:"Number of additional tasks"}},show_header_toggle:{heading:"Show header toggle",description:"Show toggle switch at the top of the card for enabling/disabling all entities"},show_toggle_switches:{heading:"Show toggle switches",description:"Show toggle switch for each individual schedule in the card"},tags:{heading:"Tags",description:"Use tags to divide schedules between multiple cards"},entities:{button_label:"Configure included entities",heading:"Included entities",description:"Select the entities that you want to control using the scheduler. You can click on a group to open it. Note that some entities (such as sensors) can only be used for conditions, not for actions.",included_number:"{number}/{total} selected"}}}}},Yt={services:Gt,ui:Jt},Qt=Object.freeze({__proto__:null,default:Yt,services:Gt,ui:Jt}),Xt={generic:{turn_on:"Įjungti",turn_off:"Išjungti",parameter_to_value:"{parameter} uz {value}",action_with_parameter:"{action} ar {parameter}"},climate:{set_temperature:"uzstādīt temperatūru[ uz {temperature}]",set_temperature_hvac_mode_heat:"sildīt[ līdz {temperature}]",set_temperature_hvac_mode_cool:"atdzesēt[ līdz {temperature}]",set_temperature_hvac_mode_heat_cool:"sildīt/atdzesēt[ līdz {temperature}]",set_temperature_hvac_mode_heat_cool_range:"sildīt/atdzesēt[ uz {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"auto[ uz {temperature}]",set_hvac_mode:"iestatīt[ uz {hvac_mode}]",set_preset_mode:"iestatīt režīmu[ uz {preset_mode}]",set_fan_mode:"iestatīt ventilatora režīmu[ uz {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"aizvērt",open_cover:"atvērt",set_cover_position:"uzstādīt pozīciju[ uz {position}]",set_cover_tilt_position:"uzstādīt slīpuma stāvokli[ uz {tilt_position}]"},fan:{set_percentage:"iestatīt ātrumu[ uz {speed}]",set_direction:"iestatīt virzienu[ uz {direction}]",oscillate:"iestatīt oscilāciju[ uz {oscillate}]"},humidifier:{set_humidity:"iestatīt mitrumu[ uz {humidity}]",set_mode:"iestatīt režīmu[ uz {mode}]"},input_number:{set_value:"iestatīt vērtību[ uz {value}]"},input_select:{select_option:"izvēlēties opciju[ {option}]"},select:{select_option:"izvēlēties opciju[ {option}]"},light:{turn_on:"ieslēgt[ ar {brightness} spilgtumu]"},media_player:{select_source:"izvēlēties avotu[ {source}]"},notify:{send_message:"nosūtīt paziņojumu"},script:{execute:"izpildīt"},vacuum:{start_pause:"sākt / pauze"},water_heater:{set_operation_mode:"iestatīt režīmu[ uz {operation_mode}]",set_away_mode:"iestatīt prombūtnes režīmu"}},ei={components:{date:{day_types_short:{daily:"ikdienišķs",workdays:"darba dienas",weekend:"nedēļas nogale"},day_types_long:{daily:"katru dienu",workdays:"darba dienās",weekend:"nedēļas nogalē"},days:"dienas",tomorrow:"rītdiena",repeated_days:"katras {days}",repeated_days_except:"katru dienu, izņemot {excludedDays}",days_range:"no {startDay} līdz {endDay}",next_week_day:"nākošo {weekday}"},time:{absolute:"kad {time}",interval:"no {startTime} līdz {endTime}",at_midnight:"kad midnight",at_noon:"kad noon",at_sun_event:"kad {sunEvent}"}},dialog:{enable_schedule:{title:"Pabeigt modificēšanu",description:"Izmainītais grafiks pašlaik ir atspējots, vai vēlaties to iespējot?"},confirm_delete:{title:"Vai dzēst vienību?",description:"Vai tiešām vēlaties dzēst šo vienību?"},confirm_migrate:{title:"Atjaunināt grafiku",description:"Šīs izmaiņas rezultātā daži iestatījumi tiks zaudēti. Vai vēlaties turpināt?"},weekday_picker:{title:"Repeated days for schedule",choose:"Choose..."},entity_picker:{title:"Choose entities",choose:"Choose...",no_results:"No matching items found"},action_picker:{title:"Choose action",show_all:"Show all supported entities"}},panel:{common:{title:"Plānotājs",new_schedule:"Jauns grafiks",default_name:"Grafiks #{id}"},overview:{no_entries:"Nav parādāmu vienību",backend_error:"Nevar izveidot savienojumu ar plānotāja komponenti. Pirms šīs kartes izmantošanas tā ir jāinstalē kā integrācija.",excluded_items:"{number} izslēgtas {if number is 1} vienība {else} vienības",hide_excluded:"paslēpt izslēgtās vienības",additional_tasks:"{number} papildu {if number is 1} uzdevums {else} uzdevumi"},editor:{repeated_days:"Repeated days",start_time:"Start time",stop_time:"End time",action:"Action",add_action:"Add action",select_timeslot:"Vispirms izvēlieties laika slotu",toggle_single_mode:"Uz vienkāršo režīmu",toggle_scheme_mode:"Uz shēmas režīmu",validation_errors:{overlapping_time:"Schedule has overlapping timeslots",missing_target_entity:"One or more actions are missing a target entity",missing_service_parameter:"One or more actions are missing a required setting",missing_action:"Schedule has no actions"}},options:{conditions:{header:"Conditions",add_condition:"Add condition",new_condition:"New condition",types:{equal_to:"{entity} is equal to {value}",unequal_to:"{entity} is unequal to {value}",above:"{entity} is above {value}",below:"{entity} is below {value}"},options:{logic_and:"All conditions must be true",logic_or:"Any condition must be true",track_changes:"Pārvērtēt, kad mainās nosacījumi"}},period:{header:"Periods",start_date:"From",end_date:"To"},repeat_type:"uzvedība pēc beigām",tags:"Tags"},card_editor:{tabs:{entities:"Vienības",other:"Cits"},fields:{title:{heading:"Kartes nosaukums",options:{standard:"standarta",hidden:"paslēpts",custom:"pielāgots"},custom_title:"Pielāgots nosaukums"},discover_existing:{heading:"Rādīt visus grafikus",description:"Šis iestata 'atklāt esošo' parametru. Iepriekš izveidotie grafiki automātiski tiks pievienoti kartei."},time_step:{heading:"Laika solis",description:"Izšķirtspēja (minūtēs) grafiku izveidei",unit_minutes:"min"},default_editor:{heading:"Default time editor",options:{single:"Single schedule mode",scheme:"Time scheme mode"}},sort_by:{heading:"Kārtošanas opcijas",description:"Kārtība, kādā grafiki parādās kartē",options:{relative_time:"Atlikušais laiks līdz nākamajai darbībai",title:"Grafika nosaukums",state:"Rādīt aktīvos grafikus augšā"}},display_format_primary:{heading:"Rādītā primārā informācija",description:"Konfigurējiet, kura informācija tiek izmantota grafiku pārskatā",options:{default:"Grafika nosaukums",entity_action:"Uzdevuma kopsavilkums"}},display_format_secondary:{heading:"Rādītā sekundārā informācija",description:"Konfigurējiet, kuras papildu īpašības ir redzamas pārskatā",options:{relative_time:"Atlikušais laiks līdz nākamajai darbībai",time:"Konfigurētais laiks nākamajai darbībai",days:"Atkārtotas nedēļas dienas",additional_tasks:"Papildu uzdevumu skaits"}},show_header_toggle:{heading:"Rādīt galvenes pārslēgšanu",description:"Rādīt pārslēgšanas slēdzi kartes augšdaļā, lai iespējotu/atspējotu visas vienības"},show_toggle_switches:{heading:"Rādīt pārslēgšanas slēdžus",description:"Rādīt pārslēgšanas slēdzi katram atsevišķam grafikam kartē"},tags:{heading:"Tagi",description:"Izmantojiet tagus, lai sadalītu grafikus starp vairākām kartēm"},entities:{button_label:"Iekļauto elementu konfigurēšana",heading:"Iekļautās vienības",description:"Izvēlieties vienības, kuras vēlaties kontrolēt, izmantojot plānotāju. Jūs varat noklikšķināt uz grupas, lai to atvērtu. Ņemiet vērā, ka dažas vienības (piemēram, sensori) var tikt izmantotas tikai nosacījumiem, nevis darbībām.",included_number:"{number}/{total} izvēlēts"}}}}},ti={services:Xt,ui:ei},ii=Object.freeze({__proto__:null,default:ti,services:Xt,ui:ei}),si={generic:{turn_on:"Aanzetten",turn_off:"Uitzetten",parameter_to_value:"{parameter} naar {value}",action_with_parameter:"{action} met {parameter}"},climate:{set_temperature:"temperatuur instellen[ naar {temperature}]",set_temperature_hvac_mode_heat:"verwarmen[ naar {temperature}]",set_temperature_hvac_mode_cool:"koelen[ naar {temperature}]",set_temperature_hvac_mode_heat_cool:"verwarmen/koelen[ naar {temperature}]",set_temperature_hvac_mode_heat_cool_range:"verwarmen/koelen[ naar {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"automatisch[ naar {temperature}]",set_hvac_mode:"modus aanpassen[ naar {hvac_mode}]",set_preset_mode:"programma[ {preset_mode}] instellen",set_fan_mode:"ventilatiemodus aanpassen[ naar {fan_mode}]",set_swing_mode:"oscillatiemodus aanpassen[ naar {swing_mode}]"},cover:{close_cover:"sluiten",open_cover:"openen",set_cover_position:"positie instellen[ naar {position}]",set_cover_tilt_position:"hellingshoek instellen[ naar {tilt_position}]"},fan:{set_percentage:"snelheid instellen[ op {percentage}]",set_direction:"richting instellen[ naar {direction}]",oscillate:"zet oscillatie[ naar {oscillate}]"},humidifier:{set_humidity:"luchtvochtigheid instellen [ op {humidity}]",set_mode:"modus aanpassen[ naar {mode}]"},input_number:{set_value:"waarde aanpassen[ naar {value}]"},input_select:{select_option:"selecteer optie[ {option}]"},select:{select_option:"selecteer optie[ {option}]"},light:{turn_on:"inschakelen[ met {brightness} helderheid]"},media_player:{select_source:"kies ingang[ {source}]"},notify:{send_message:"notificatie sturen"},script:{execute:"uitvoeren"},vacuum:{start_pause:"start / pauzeer"},water_heater:{set_operation_mode:"modus aanpassen[ naar {operation_mode}]",set_away_mode:"stel afwezigheidsmode in"}},ai={components:{date:{day_types_short:{daily:"dagelijks",workdays:"werkdagen",weekend:"weekend"},day_types_long:{daily:"iedere dag",workdays:"doordeweeks",weekend:"in het weekend"},days:"dagen",tomorrow:"morgen",repeated_days:"elke {days}",repeated_days_except:"elke dag behalve {excludedDays}",days_range:"van {startDay} tot {endDay}",next_week_day:"volgende week {weekday}"},time:{absolute:"om {time}",interval:"van {startTime} tot {endTime}",at_midnight:"om middernacht",at_noon:"om 12:00",at_sun_event:"bij {sunEvent}"}},dialog:{enable_schedule:{title:"Wijzigingen voltooid",description:"Deze planning is momenteel gedeactiveerd. Dient deze te worden ingeschakeld?"},confirm_delete:{title:"Entiteit verwijderen?",description:"Weet je zeker dat je dit item wilt verwijderen?"},confirm_migrate:{title:"Schema bijwerken",description:"Door deze actie gaan vorige instellingen verloren. Wil je doorgaan?"},weekday_picker:{title:"Herhaalde dagen voor tijdschema",choose:"Kies..."},entity_picker:{title:"Kies entiteiten",choose:"Kies...",no_results:"Geen overeenkomstige items gevonden"},action_picker:{title:"Kies actie",show_all:"Toon alle ondersteunde entiteiten"}},panel:{common:{title:"Tijdplanner",new_schedule:"Nieuw schema",default_name:"Schema #{id}"},overview:{no_entries:"Er zijn geen items aangemaakt",backend_error:"Er kon geen verbinding worden gemaakt met het Scheduler component. Deze moet als integratie zijn geinstalleerd voordat deze kaart gebruikt kan worden.",excluded_items:"{number} uitgesloten {if number is 1} item {else} items",hide_excluded:"verberg uitgesloten items",additional_tasks:"{number} overige {if number is 1} taak {else} taken"},editor:{repeated_days:"Herhaling",start_time:"Starttijd",stop_time:"Eindtijd",action:"Actie",add_action:"Actie toevoegen",select_timeslot:"Selecteer een tijdslot...",toggle_single_mode:"Naar enkele modus",toggle_scheme_mode:"Naar schema modus",validation_errors:{overlapping_time:"Schedule has overlapping timeslots",missing_target_entity:"One or more actions are missing a target entity",missing_service_parameter:"One or more actions are missing a required setting",missing_action:"Schedule has no actions"}},options:{conditions:{header:"Condities",add_condition:"Conditie toevoegen",new_condition:"Nieuwe conditie",types:{equal_to:"{entity} is gelijk aan {value}",unequal_to:"{entity} is ongelijk aan {value}",above:"{entity} is hoger dan {value}",below:"{entity} is lager dan {value}"},options:{logic_and:"Alle condities moeten zijn voldaan",logic_or:"Een van de condities moet zijn voldaan",track_changes:"Herevalueer als de condities veranderen"}},period:{header:"Periode",start_date:"Vanaf",end_date:"Tot"},repeat_type:"Gedrag na voltooiing",tags:"Tags"},card_editor:{tabs:{entities:"Entiteiten",other:"Overig"},fields:{title:{heading:"Titel van de kaart",options:{standard:"standaard",hidden:"verborgen",custom:"anders"},custom_title:"Eigen titel"},discover_existing:{heading:"Alle schema's tonen",description:"Hiermee wordt de 'discover existing' instelling geactiveerd. Eerder aangemaakte schema's zullen automatisch worden weergegeven."},time_step:{heading:"Stapgrootte voor tijd",description:"Resolutie (in minuten)",unit_minutes:"min"},default_editor:{heading:"Standaardmodus voor tijdsinvoer",options:{single:"Enkele modus",scheme:"Tijdschema-modus"}},sort_by:{heading:"Sorteer-opties",description:"Volgorde waarin de schema's worden weergegeven in de kaart",options:{relative_time:"Resterende tijd tot volgende actie",title:"Weergegeven titel van de schema's",state:"Actieve schema's eerst"}},display_format_primary:{heading:"Weergegeven primaire info",description:"Kies welk label wordt gebruikt in de weergave",options:{default:"Schema naam",entity_action:"Samenvatting van de actie"}},display_format_secondary:{heading:"Weergegeven secondaire info",description:"Kies welke aanvullende informatie zichtbaar is in de weergave",options:{relative_time:"Resterende tijd tot volgende actie",time:"Ingestelde tijd voor de volgende actie",days:"Herhaalde dagen van de week",additional_tasks:"Aantal resterende acties"}},show_header_toggle:{heading:"Hoofdschakelaar weergeven",description:"Schakelaar weergeven bovenin de kaart om alle schema's te (de)activeren"},show_toggle_switches:{heading:"Schakelknoppen weergeven",description:"Schakelknop weergeven voor elk individueel schema in de kaart"},tags:{heading:"Tags",description:"Tags kunnen gebruikt worden om schema's te verdelen over meerdere kaarten"},entities:{button_label:"Configureer zichtbare entiteiten",heading:"Zichtbare entiteiten",description:"Kies de entiteiten die je wilt bedienen vanuit schema's. Klik op een categorie om deze te openen. Merk op dat sommige entiteiten gebruikt worden om condities toe te wijzen.",included_number:"{number}/{total} geselecteerd"}}}}},oi={services:si,ui:ai},ni=Object.freeze({__proto__:null,default:oi,services:si,ui:ai}),ri={generic:{turn_on:"Skru på",turn_off:"Slå av",parameter_to_value:"{parameter} til {value}",action_with_parameter:"{action} med {parameter}"},climate:{set_temperature:"sett temperatur[ til {temperature}]",set_temperature_hvac_mode_heat:"oppvarming[ til {temperature}]",set_temperature_hvac_mode_cool:"kjøling[ til {temperature}]",set_temperature_hvac_mode_heat_cool:"oppvarming/kjøling[ til {temperature}]",set_temperature_hvac_mode_heat_cool_range:"oppvarming/kjøling[ til {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"auto[ til {temperature}]",set_hvac_mode:"sett modus[ til {hvac_mode}]",set_preset_mode:"sett forhåndsvalg[ {preset_mode}]",set_fan_mode:"set fan mode[ to {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"lukk",open_cover:"åpne",set_cover_position:"sett posisjon[ til {position}]",set_cover_tilt_position:"sett vippestilling[ til {tilt_position}]"},fan:{set_percentage:"sett hastighet[ til {speed}]",set_direction:"sett retning[ til {direction}]",oscillate:"sett svingning[ til {oscillate}]"},humidifier:{set_humidity:"sett luftfuktighet[ til {humidity}]",set_mode:"sett modus[ til {mode}]"},input_number:{set_value:"sett verdi[ til {value}]"},input_select:{select_option:"velg[ {option}]"},select:{select_option:"velg[ {option}]"},light:{turn_on:"slå på[ med {brightness} lysstyrke]"},media_player:{select_source:"velg kilde[ {source}]"},notify:{send_message:"send notifikasjon"},script:{execute:"utfør"},vacuum:{start_pause:"start / pause"},water_heater:{set_operation_mode:"sett modus[ til {operation_mode}]",set_away_mode:"sett bortemodus"}},di={components:{date:{day_types_short:{daily:"hver dag",workdays:"ukedager",weekend:"helg"},day_types_long:{daily:"hver dag",workdays:"ukedager",weekend:"helg"},days:"Dager",tomorrow:"imorgen",repeated_days:"hver {days}",repeated_days_except:"hver dag unntatt {excludedDays}",days_range:"fra {startDay} til {endDay}",next_week_day:"neste {weekday}"},time:{absolute:"kl. {time}",interval:"fra {startTime} til {endTime}",at_midnight:"ved midnatt",at_noon:"kl. 12.00",at_sun_event:"ved {sunEvent}"}},dialog:{enable_schedule:{title:"Fullfør endringene",description:"Tidsplanen som er endret er for øyeblikket deaktivert, bør den være aktivert?"},confirm_delete:{title:"Vil du fjerne entiteten?",description:"Er du sikker på at du vil fjerne denne entiteten?"},confirm_migrate:{title:"Endre tidsplanen",description:"Noen innstillinger vil gå tapt ved denne handlingen. Vil du fortsette?"},weekday_picker:{title:"Repeated days for schedule",choose:"Choose..."},entity_picker:{title:"Choose entities",choose:"Choose...",no_results:"No matching items found"},action_picker:{title:"Choose action",show_all:"Show all supported entities"}},panel:{common:{title:"Tidsplan",new_schedule:"Ny tidsplan",default_name:"Tidsplan #{id}"},overview:{no_entries:"Det er ingen definerte tidsplaner å vise",backend_error:"Kunne ikke koble til tidsplankomponenten. Den må installeres som en integrasjon før dette kortet kan benyttes.",excluded_items:"{number} ekskludert {if number is 1} element {else} elementer",hide_excluded:"skjul ekskluderte elementer",additional_tasks:"{number} flere {if number is 1} oppgaver {else} oppgaver"},editor:{repeated_days:"Repeated days",start_time:"Start time",stop_time:"End time",action:"Action",add_action:"Add action",select_timeslot:"Velg tidsluke",toggle_single_mode:"Til enkel modus",toggle_scheme_mode:"Til skjemamodus",validation_errors:{overlapping_time:"Schedule has overlapping timeslots",missing_target_entity:"One or more actions are missing a target entity",missing_service_parameter:"One or more actions are missing a required setting",missing_action:"Schedule has no actions"}},options:{conditions:{header:"Conditions",add_condition:"Add condition",new_condition:"New condition",types:{equal_to:"{entity} is equal to {value}",unequal_to:"{entity} is unequal to {value}",above:"{entity} is above {value}",below:"{entity} is below {value}"},options:{logic_and:"All conditions must be true",logic_or:"Any condition must be true",track_changes:"Re-evaluate when conditions change"}},period:{header:"Periode",start_date:"From",end_date:"To"},repeat_type:"oppførsel etter fullføring",tags:"Tags"},card_editor:{tabs:{entities:"Entities",other:"Other"},fields:{title:{heading:"Title of the card",options:{standard:"standard",hidden:"hidden",custom:"custom"},custom_title:"Custom title"},discover_existing:{heading:"Show all schedules",description:"This sets the 'discover existing' parameter. Previously created schedules will be automatically added to the card. "},time_step:{heading:"Time step",description:"Resolution (in minutes) for creating schedules",unit_minutes:"min"},default_editor:{heading:"Default time editor",options:{single:"Single schedule mode",scheme:"Time scheme mode"}},sort_by:{heading:"Sorting options",description:"Order in which the schedules appear in the card",options:{relative_time:"Time remaining until next action",title:"Displayed title of the schedule",state:"Show active schedules on top"}},display_format_primary:{heading:"Displayed primary info",description:"Configure which label is used for schedules in the overview",options:{default:"Schedule name",entity_action:"Summary of task"}},display_format_secondary:{heading:"Displayed secondary info",description:"Configure what additional properties are visible in the overview",options:{relative_time:"Time remaining until next action",time:"Configured time for next action",days:"Repeated days of the week",additional_tasks:"Number of additional tasks"}},show_header_toggle:{heading:"Show header toggle",description:"Show toggle switch at the top of the card for enabling/disabling all entities"},show_toggle_switches:{heading:"Show toggle switches",description:"Show toggle switch for each individual schedule in the card"},tags:{heading:"Tags",description:"Use tags to divide schedules between multiple cards"},entities:{button_label:"Configure included entities",heading:"Included entities",description:"Select the entities that you want to control using the scheduler. You can click on a group to open it. Note that some entities (such as sensors) can only be used for conditions, not for actions.",included_number:"{number}/{total} selected"}}}}},li={services:ri,ui:di},ci=Object.freeze({__proto__:null,default:li,services:ri,ui:di}),ui={generic:{turn_on:"Włącz",turn_off:"Wyłącz",parameter_to_value:"{parameter} na {value}",action_with_parameter:"{action} z parametrem {parameter}"},climate:{set_temperature:"ustaw temperaturę[ na {temperature}]",set_temperature_hvac_mode_heat:"ogrzewanie[ na {temperature}]",set_temperature_hvac_mode_cool:"chłodzenie[ na {temperature}]",set_temperature_hvac_mode_heat_cool:"ogrzewanie/chłodzenie[ na {temperature}]",set_temperature_hvac_mode_heat_cool_range:"ogrzewanie/chłodzenie[ {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"auto[ na {temperature}]",set_hvac_mode:"ustaw tryb[ na {hvac_mode}]",set_preset_mode:"ustaw tryb[ na {preset_mode}]",set_fan_mode:"ustaw tryb wentylatora[ na {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"zamknij",open_cover:"otwórz",set_cover_position:"ustaw pozycję[ na {position}]",set_cover_tilt_position:"ustaw kąt nachylenia[ na {tilt_position}]"},fan:{set_percentage:"ustaw prędkość[ na {percentage}]",set_direction:"ustaw kierunek[ na {direction}]",oscillate:"ustaw oscylację[ na {oscillate}]"},humidifier:{set_humidity:"ustaw wilgotność[ na {humidity}]",set_mode:"ustaw tryb[ na {mode}]"},input_number:{set_value:"ustaw wartość[ na {value}]"},input_select:{select_option:"wybierz opcję[ {option}]"},select:{select_option:"wybierz opcję[ {option}]"},light:{turn_on:"włącz[ z jasnością {brightness}]"},media_player:{select_source:"wybierz źródło[ {source}]"},notify:{send_message:"wyślij powiadomienie"},script:{execute:"wykonaj"},vacuum:{start_pause:"start / pauza"},water_heater:{set_operation_mode:"ustaw tryb[ na {operation_mode}]",set_away_mode:"ustaw tryb poza domem"}},hi={components:{date:{day_types_short:{daily:"codziennie",workdays:"dni robocze",weekend:"weekend"},day_types_long:{daily:"każdego dnia",workdays:"w dni robocze",weekend:"w weekend"},days:"dni",tomorrow:"jutro",repeated_days:"każde {days}",repeated_days_except:"każdego dnia oprócz {excludedDays}",days_range:"od {startDay} do {endDay}",next_week_day:"w {weekday}"},time:{absolute:"o {time}",interval:"od {startTime} do {endTime}",at_midnight:"o północy",at_noon:"w południe",at_sun_event:"o {sunEvent}"}},dialog:{enable_schedule:{title:"Zakończ modyfikacje",description:"Harmonogram, który zmieniłeś, jest obecnie wyłączony. Czy chcesz go włączyć?"},confirm_delete:{title:"Usunąć encję?",description:"Czy na pewno chcesz usunąć tę encję?"},confirm_migrate:{title:"Aktualizuj harmonogram",description:"Niektóre ustawienia zostaną utracone przy tej zmianie. Czy chcesz kontynuować?"},weekday_picker:{title:"Dni powtórzeń dla harmonogramu",choose:"Wybierz..."},entity_picker:{title:"Wybierz encje",choose:"Wybierz...",no_results:"Nie znaleziono pasujących elementów"},action_picker:{title:"Wybierz akcję",show_all:"Pokaż wszystkie obsługiwane jednostki"}},panel:{common:{title:"Harmonogram",new_schedule:"Nowy harmonogram",default_name:"Harmonogram #{id}"},overview:{no_entries:"Brak elementów do wyświetlenia",backend_error:"Nie można połączyć się z komponentem harmonogramu. Musi być zainstalowany jako integracja, zanim ta karta będzie mogła być używana.",excluded_items:"{number} wykluczonych {if number is 1} element {else} elementów",hide_excluded:"ukryj wykluczone elementy",additional_tasks:"{number} dodatkowych {if number is 1} zadanie {else} zadań"},editor:{repeated_days:"Powtarzane dni",start_time:"Czas rozpoczęcia",stop_time:"Czas zakończenia",action:"Akcja",add_action:"Dodaj akcję",select_timeslot:"Wybierz przedział czasowy",toggle_single_mode:"Do trybu prostego",toggle_scheme_mode:"Do trybu schematu",validation_errors:{overlapping_time:"Harmonogram ma nachodzące na siebie przedziały czasowe",missing_target_entity:"Jednej lub więcej akcji brakuje docelowej encji",missing_service_parameter:"Jednej lub więcej akcji brakuje wymaganego parametru",missing_action:"Harmonogram nie ma żadnych akcji"}},options:{conditions:{header:"Warunki",add_condition:"Dodaj warunek",new_condition:"Nowy warunek",types:{equal_to:"{entity} równa się {value}",unequal_to:"{entity} różni się od {value}",above:"{entity} jest powyżej {value}",below:"{entity} jest poniżej {value}"},options:{logic_and:"Wszystkie warunki muszą być spełnione",logic_or:"Dowolny warunek musi być spełniony",track_changes:"Ponownie sprawdzaj przy zmianie warunków"}},period:{header:"Okres",start_date:"Od",end_date:"Do"},repeat_type:"zachowanie po zakończeniu",tags:"Tagi"},card_editor:{tabs:{entities:"Encje",other:"Inne"},fields:{title:{heading:"Tytuł karty",options:{standard:"standardowy",hidden:"ukryty",custom:"niestandardowy"},custom_title:"Niestandardowy tytuł"},discover_existing:{heading:"Pokaż wszystkie harmonogramy",description:"Ustawia parametr 'discover existing'. Wcześniej utworzone harmonogramy będą automatycznie dodane do karty."},time_step:{heading:"Krok czasu",description:"Rozdzielczość (w minutach) przy tworzeniu harmonogramów",unit_minutes:"min"},default_editor:{heading:"Domyślny edytor czasu",options:{single:"Tryb prostego harmonogramu",scheme:"Tryb schematu czasu"}},sort_by:{heading:"Opcje sortowania",description:"Kolejność, w jakiej harmonogramy pojawiają się na karcie",options:{relative_time:"Czas do następnej akcji",title:"Wyświetlana nazwa harmonogramu",state:"Pokaż aktywne harmonogramy na górze"}},display_format_primary:{heading:"Wyświetlana główna informacja",description:"Określ, która etykieta jest używana dla harmonogramów w podglądzie",options:{default:"Nazwa harmonogramu",entity_action:"Podsumowanie zadania"}},display_format_secondary:{heading:"Wyświetlana dodatkowa informacja",description:"Skonfiguruj, które dodatkowe właściwości są widoczne w podglądzie",options:{relative_time:"Czas do następnej akcji",time:"Skonfigurowany czas następnej akcji",days:"Powtarzane dni tygodnia",additional_tasks:"Liczba dodatkowych zadań"}},show_header_toggle:{heading:"Pokaż przełącznik w nagłówku",description:"Pokaż przełącznik w nagłówku karty do włączania/wyłączania wszystkich encji"},show_toggle_switches:{heading:"Pokaż przełączniki",description:"Pokaż przełącznik dla każdego harmonogramu w karcie"},tags:{heading:"Tagi",description:"Używaj tagów do podziału harmonogramów pomiędzy wieloma kartami"},entities:{button_label:"Konfiguruj zawarte encje",heading:"Zawarte encje",description:"Wybierz encje, którymi chcesz sterować za pomocą harmonogramu. Możesz kliknąć na grupę, aby ją otworzyć. Zauważ, że niektóre encje (np. sensory) mogą być używane tylko jako warunki, a nie akcje.",included_number:"{number}/{total} wybrano"}}}}},mi={services:ui,ui:hi},pi=Object.freeze({__proto__:null,default:mi,services:ui,ui:hi}),_i={generic:{turn_on:"Ligar",turn_off:"Desligar",parameter_to_value:"{parameter} para {value}",action_with_parameter:"{action} com {parameter}"},climate:{set_temperature:"definir temperatura[ para {temperature}]",set_temperature_hvac_mode_heat:"aquecimento[ para {temperature}]",set_temperature_hvac_mode_cool:"arrefecimento[ para {temperature}]",set_temperature_hvac_mode_heat_cool:"aquecimento/arrefecimento[ para {temperature}]",set_temperature_hvac_mode_heat_cool_range:"aquecimento/arrefecimento[ para {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"auto[ para {temperature}]",set_hvac_mode:"definir modo[ para {hvac_mode}]",set_preset_mode:"definir predefinição[ {preset_mode}]",set_fan_mode:"definir modo ventoinha[ para {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"fechar",open_cover:"abrir",set_cover_position:"definir posição[ para {position}]",set_cover_tilt_position:"definir inclinação[ como {tilt_position}]"},fan:{set_percentage:"definir velocidade[ para {speed}]",set_direction:"definir direção[ para {direction}]",oscillate:"definir oscilação[ para {oscillate}]"},humidifier:{set_humidity:"definir humidade[ para {humidity}]",set_mode:"definir modo[ para {mode}]"},input_number:{set_value:"definir valor[ para {value}]"},input_select:{select_option:"selecionar opção[ {option}]"},select:{select_option:"selecionar opção[ {option}]"},light:{turn_on:"ligar[ com {brightness} brightness]"},media_player:{select_source:"selecionar origem[ {source}]"},notify:{send_message:"enviar notificação"},script:{execute:"executar"},vacuum:{start_pause:"iniciar / pausar"},water_heater:{set_operation_mode:"definir modo[ para {operation_mode}]",set_away_mode:"definir modo ausente"}},gi={components:{date:{day_types_short:{daily:"todos",workdays:"semana de trabalho",weekend:"fim-de-semana"},day_types_long:{daily:"todos os dias",workdays:"em dias de semana",weekend:"no fim-de-semana"},days:"dias",tomorrow:"amanhã",repeated_days:"a cada {days}",repeated_days_except:"a cada dia exceto {excludedDays}",days_range:"até {startDay} até {endDay}",next_week_day:"próximo {weekday}"},time:{absolute:"Às {time}",interval:"das {startTime} às {endTime}",at_midnight:"ao meia-noite",at_noon:"ao meio-dia",at_sun_event:"ao {sunEvent}"}},dialog:{enable_schedule:{title:"Conclua as modificações",description:"A programação que foi alterada está atualmente desabilitada, deveria ser habilitada?"},confirm_delete:{title:"Remover a entidade?",description:"Tem a certeza que deseja remover esta entidade?"},confirm_migrate:{title:"Modificar horário",description:"Algumas configurações serão perdidas por esta ação. Você quer prosseguir?"},weekday_picker:{title:"Repetições semanais",choose:"Escolha..."},entity_picker:{title:"Escolha entidades",choose:"Escolha...",no_results:"Sem resultados"},action_picker:{title:"Escolha a acção",show_all:"Mostrar todas as entidades suportadas"}},panel:{common:{title:"Agenda",new_schedule:"Novo horário",default_name:"Horário #{id}"},overview:{no_entries:"Não existem itens a mostrar",backend_error:"Não consegui ligar ao componente de agendamento. Essa integração tem que ser instalada antes da utilização deste cartão.",excluded_items:"{number}{if number is 1} item excluído {else} itens excluídos",hide_excluded:"ocultar itens excluídos",additional_tasks:"Mais {number} {if number is 1} tarefa {else} tarefas"},editor:{repeated_days:"Repetições semanais",start_time:"Hora início",stop_time:"Hora fim",action:"Acção",add_action:"Acrescentar acção",select_timeslot:"Selecionar um período horário",toggle_single_mode:"Para modo simples",toggle_scheme_mode:"Para modo esquema",validation_errors:{overlapping_time:"O Horário tem sobreposições",missing_target_entity:"Uma ou mais acções sem entidade definida",missing_service_parameter:"Unma ou mais acções sem uma definição obrigatória",missing_action:"O Horário não tem acções"}},options:{conditions:{header:"Condições",add_condition:"Acrescentar condição",new_condition:"Nova condição",types:{equal_to:"{entity} igual a {value}",unequal_to:"{entity} diferente de {value}",above:"{entity} acima de {value}",below:"{entity} abaixo de {value}"},options:{logic_and:"Todas as condições têm de ser verdadeiras",logic_or:"Uma das condições tem de ser verdadeira",track_changes:"Reavaliar em caso de alterações"}},period:{header:"Período",start_date:"Desde",end_date:"Até"},repeat_type:"Comportamento após a conclusão",tags:"Etiquetas"},card_editor:{tabs:{entities:"Entities",other:"Other"},fields:{title:{heading:"Title of the card",options:{standard:"standard",hidden:"hidden",custom:"custom"},custom_title:"Custom title"},discover_existing:{heading:"Show all schedules",description:"This sets the 'discover existing' parameter. Previously created schedules will be automatically added to the card. "},time_step:{heading:"Time step",description:"Resolution (in minutes) for creating schedules",unit_minutes:"min"},default_editor:{heading:"Default time editor",options:{single:"Single schedule mode",scheme:"Time scheme mode"}},sort_by:{heading:"Sorting options",description:"Order in which the schedules appear in the card",options:{relative_time:"Time remaining until next action",title:"Displayed title of the schedule",state:"Show active schedules on top"}},display_format_primary:{heading:"Displayed primary info",description:"Configure which label is used for schedules in the overview",options:{default:"Schedule name",entity_action:"Summary of task"}},display_format_secondary:{heading:"Displayed secondary info",description:"Configure what additional properties are visible in the overview",options:{relative_time:"Time remaining until next action",time:"Configured time for next action",days:"Repeated days of the week",additional_tasks:"Number of additional tasks"}},show_header_toggle:{heading:"Show header toggle",description:"Show toggle switch at the top of the card for enabling/disabling all entities"},show_toggle_switches:{heading:"Show toggle switches",description:"Show toggle switch for each individual schedule in the card"},tags:{heading:"Tags",description:"Use tags to divide schedules between multiple cards"},entities:{button_label:"Configure included entities",heading:"Included entities",description:"Select the entities that you want to control using the scheduler. You can click on a group to open it. Note that some entities (such as sensors) can only be used for conditions, not for actions.",included_number:"{number}/{total} selected"}}}}},vi={services:_i,ui:gi},yi=Object.freeze({__proto__:null,default:vi,services:_i,ui:gi}),fi={generic:{turn_on:"Ligar",turn_off:"Desligar",parameter_to_value:"{parameter} para {value}",action_with_parameter:"{action} com {parameter}"},climate:{set_temperature:"definir temperatura[ para {temperature}]",set_temperature_hvac_mode_heat:"aquecimento[ para {temperature}]",set_temperature_hvac_mode_cool:"arrefecimento[ para {temperature}]",set_temperature_hvac_mode_heat_cool:"aquecimento/arrefecimento[ para {temperature}]",set_temperature_hvac_mode_heat_cool_range:"aquecimento/arrefecimento[ para {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"auto[ para {temperature}]",set_hvac_mode:"definir modo[ para {hvac_mode}]",set_preset_mode:"definir predefinição[ {preset_mode}]",set_fan_mode:"definir modo do ventilador[ para {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"fechar",open_cover:"abrir",set_cover_position:"definir posição[ para {position}]",set_cover_tilt_position:"definir a posição de inclinação[ para {tilt_position}]"},fan:{set_percentage:"definir velocidade[ para {speed}]",set_direction:"definir direção[ para {direction}]",oscillate:"definir oscilação[ para {oscillate}]"},humidifier:{set_humidity:"definir humidade[ para {humidity}]",set_mode:"definir modo[ para {mode}]"},input_number:{set_value:"definir valor[ para {value}]"},input_select:{select_option:"selecionar opção[ {option}]"},select:{select_option:"selecionar opção[ {option}]"},light:{turn_on:"ligar[ com {brightness} brightness]"},media_player:{select_source:"selecionar origem[ {source}]"},notify:{send_message:"enviar notificação"},script:{execute:"executar"},vacuum:{start_pause:"iniciar / pausar"},water_heater:{set_operation_mode:"definir modo[ para {operation_mode}]",set_away_mode:"definir modo ausente"}},bi={components:{date:{day_types_short:{daily:"diário",workdays:"semana de trabalho",weekend:"fim-de-semana"},day_types_long:{daily:"todos os dias",workdays:"em dias de semana",weekend:"no fim-de-semana"},days:"dias",tomorrow:"amanhã",repeated_days:"a cada {days}",repeated_days_except:"a cada dia exceto {excludedDays}",days_range:"de {startDay} até {endDay}",next_week_day:"próximo {weekday}"},time:{absolute:"à {time}",interval:"das {startTime} às {endTime}",at_midnight:"ao meia-noite",at_noon:"ao meio-dia",at_sun_event:"ao {sunEvent}"}},dialog:{enable_schedule:{title:"Conclua as modificações",description:"A programação que foi alterada está atualmente desabilitada, deveria ser habilitada?"},confirm_delete:{title:"Remover entidade?",description:"Tem certeza de que deseja remover esta entidade?"},confirm_migrate:{title:"Modificar horário",description:"Algumas configurações serão perdidas por esta ação. Você quer prosseguir?"},weekday_picker:{title:"Repeated days for schedule",choose:"Choose..."},entity_picker:{title:"Choose entities",choose:"Choose...",no_results:"No matching items found"},action_picker:{title:"Choose action",show_all:"Show all supported entities"}},panel:{common:{title:"Agenda",new_schedule:"Novo horário",default_name:"Horário #{id}"},overview:{no_entries:"Não existem itens para mostrar",backend_error:"Não foi possível conectar com o componente agendador. Ele precisa ser instalado como integração antes que este cartão possa ser usado.",excluded_items:"{number}{if number is 1} item excluído {else} itens excluídos",hide_excluded:"ocultar itens excluídos",additional_tasks:"Mais {number} {if number is 1} tarefa {else} tarefas"},editor:{repeated_days:"Repeated days",start_time:"Start time",stop_time:"End time",action:"Action",add_action:"Add action",select_timeslot:"Selecionar um período horário",toggle_single_mode:"Para modo simples",toggle_scheme_mode:"Para modo esquema",validation_errors:{overlapping_time:"Schedule has overlapping timeslots",missing_target_entity:"One or more actions are missing a target entity",missing_service_parameter:"One or more actions are missing a required setting",missing_action:"Schedule has no actions"}},options:{conditions:{header:"Conditions",add_condition:"Add condition",new_condition:"New condition",types:{equal_to:"{entity} is equal to {value}",unequal_to:"{entity} is unequal to {value}",above:"{entity} is above {value}",below:"{entity} is below {value}"},options:{logic_and:"All conditions must be true",logic_or:"Any condition must be true",track_changes:"Reavaliar quando as condições mudarem"}},period:{header:"Período",start_date:"From",end_date:"To"},repeat_type:"comportamento após a conclusão",tags:"Tags"},card_editor:{tabs:{entities:"Entities",other:"Other"},fields:{title:{heading:"Title of the card",options:{standard:"standard",hidden:"hidden",custom:"custom"},custom_title:"Custom title"},discover_existing:{heading:"Show all schedules",description:"This sets the 'discover existing' parameter. Previously created schedules will be automatically added to the card. "},time_step:{heading:"Time step",description:"Resolution (in minutes) for creating schedules",unit_minutes:"min"},default_editor:{heading:"Default time editor",options:{single:"Single schedule mode",scheme:"Time scheme mode"}},sort_by:{heading:"Sorting options",description:"Order in which the schedules appear in the card",options:{relative_time:"Time remaining until next action",title:"Displayed title of the schedule",state:"Show active schedules on top"}},display_format_primary:{heading:"Displayed primary info",description:"Configure which label is used for schedules in the overview",options:{default:"Schedule name",entity_action:"Summary of task"}},display_format_secondary:{heading:"Displayed secondary info",description:"Configure what additional properties are visible in the overview",options:{relative_time:"Time remaining until next action",time:"Configured time for next action",days:"Repeated days of the week",additional_tasks:"Number of additional tasks"}},show_header_toggle:{heading:"Show header toggle",description:"Show toggle switch at the top of the card for enabling/disabling all entities"},show_toggle_switches:{heading:"Show toggle switches",description:"Show toggle switch for each individual schedule in the card"},tags:{heading:"Tags",description:"Use tags to divide schedules between multiple cards"},entities:{button_label:"Configure included entities",heading:"Included entities",description:"Select the entities that you want to control using the scheduler. You can click on a group to open it. Note that some entities (such as sensors) can only be used for conditions, not for actions.",included_number:"{number}/{total} selected"}}}}},wi={services:fi,ui:bi},ki=Object.freeze({__proto__:null,default:wi,services:fi,ui:bi}),xi={generic:{turn_on:"Pornește",turn_off:"Oprește",parameter_to_value:"{parameter} la {value}",action_with_parameter:"{action} cu {parameter}"},climate:{set_temperature:"setare temperatură[ la {temperature}]",set_temperature_hvac_mode_heat:"încălzire[ la {temperature}]",set_temperature_hvac_mode_cool:"răcire[ la {temperature}]",set_temperature_hvac_mode_heat_cool:"încălzire/răcire[ la {temperature}]",set_temperature_hvac_mode_heat_cool_range:"încălzire/răcire[ la {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"auto[ la {temperature}]",set_hvac_mode:"setare mod[ la {hvac_mode}]",set_preset_mode:"setare preset[ {preset_mode}]",set_fan_mode:"set fan mode[ to {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"închidere",open_cover:"deschidere",set_cover_position:"setare poziție[ la {position}]",set_cover_tilt_position:"set tilt position[ to {tilt_position}]"},fan:{set_percentage:"setare viteză[ la {speed}]",set_direction:"setare direcție[ la {direction}]",oscillate:"setare oscilare[ la {oscillate}]"},humidifier:{set_humidity:"setare umiditate[ la {humidity}]",set_mode:"setare mod[ la {mode}]"},input_number:{set_value:"setare valoare[ la {value}]"},input_select:{select_option:"selectare opțiune[ {option}]"},select:{select_option:"selectare opțiune[ {option}]"},light:{turn_on:"pornire[ cu luminozitate {brightness}]"},media_player:{select_source:"selectare sursă[ {source}]"},notify:{send_message:"send notification"},script:{execute:"executare"},vacuum:{start_pause:"start / pauză"},water_heater:{set_operation_mode:"setare mod[ la {operation_mode}]",set_away_mode:"setare mod plecat"}},$i={components:{date:{day_types_short:{daily:"zilnic",workdays:"zile lucrătoare",weekend:"sfârșit de săptămână"},day_types_long:{daily:"zilnic",workdays:"în timpul săptămânii",weekend:"la sfârșit de săptămână"},days:"zile",tomorrow:"mâine",repeated_days:"la fiecare {days} zile",repeated_days_except:"zilnic cu excepția {excludedDays}",days_range:"din {startDay} până în {endDay}",next_week_day:"{weekday} viitoare"},time:{absolute:"la {time}",interval:"de la {startTime} până la {endTime}",at_midnight:"la miezul nopții",at_noon:"la amiază",at_sun_event:"la {sunEvent}"}},dialog:{enable_schedule:{title:"Completați modificările",description:"Programul care a fost modificat este momentan dezactivat, ar trebui activat?"},confirm_delete:{title:"Ștergeți entitatea?",description:"Sigur doriți să eliminați această entitate?"},confirm_migrate:{title:"Modificați programul",description:"Unele setări se vor pierde prin această acțiune. Vrei sa continui?"},weekday_picker:{title:"Repeated days for schedule",choose:"Choose..."},entity_picker:{title:"Choose entities",choose:"Choose...",no_results:"No matching items found"},action_picker:{title:"Choose action",show_all:"Show all supported entities"}},panel:{common:{title:"Planificator",new_schedule:"Noul program",default_name:"Program #{id}"},overview:{no_entries:"Nu există elemente de afișat",backend_error:"Could not connect with the scheduler component. It needs to be installed as integration before this card can be used.",excluded_items:"{if number is 1}un element exclus {else}{number} elemente excluse",hide_excluded:"ascunde elementele excluse",additional_tasks:"{if number is 1}o sarcină suplimentară {else}{number} sarcini suplimentare"},editor:{repeated_days:"Repeated days",start_time:"Start time",stop_time:"End time",action:"Action",add_action:"Add action",select_timeslot:"Selectați un interval orar",toggle_single_mode:"Te lokho modo",toggle_scheme_mode:"Te sxeme modo",validation_errors:{overlapping_time:"Schedule has overlapping timeslots",missing_target_entity:"One or more actions are missing a target entity",missing_service_parameter:"One or more actions are missing a required setting",missing_action:"Schedule has no actions"}},options:{conditions:{header:"Conditions",add_condition:"Add condition",new_condition:"New condition",types:{equal_to:"{entity} is equal to {value}",unequal_to:"{entity} is unequal to {value}",above:"{entity} is above {value}",below:"{entity} is below {value}"},options:{logic_and:"All conditions must be true",logic_or:"Any condition must be true",track_changes:"Re-evaluate when conditions change"}},period:{header:"Perioadă",start_date:"From",end_date:"To"},repeat_type:"comportament după declanșare",tags:"Tags"},card_editor:{tabs:{entities:"Entities",other:"Other"},fields:{title:{heading:"Title of the card",options:{standard:"standard",hidden:"hidden",custom:"custom"},custom_title:"Custom title"},discover_existing:{heading:"Show all schedules",description:"This sets the 'discover existing' parameter. Previously created schedules will be automatically added to the card. "},time_step:{heading:"Time step",description:"Resolution (in minutes) for creating schedules",unit_minutes:"min"},default_editor:{heading:"Default time editor",options:{single:"Single schedule mode",scheme:"Time scheme mode"}},sort_by:{heading:"Sorting options",description:"Order in which the schedules appear in the card",options:{relative_time:"Time remaining until next action",title:"Displayed title of the schedule",state:"Show active schedules on top"}},display_format_primary:{heading:"Displayed primary info",description:"Configure which label is used for schedules in the overview",options:{default:"Schedule name",entity_action:"Summary of task"}},display_format_secondary:{heading:"Displayed secondary info",description:"Configure what additional properties are visible in the overview",options:{relative_time:"Time remaining until next action",time:"Configured time for next action",days:"Repeated days of the week",additional_tasks:"Number of additional tasks"}},show_header_toggle:{heading:"Show header toggle",description:"Show toggle switch at the top of the card for enabling/disabling all entities"},show_toggle_switches:{heading:"Show toggle switches",description:"Show toggle switch for each individual schedule in the card"},tags:{heading:"Tags",description:"Use tags to divide schedules between multiple cards"},entities:{button_label:"Configure included entities",heading:"Included entities",description:"Select the entities that you want to control using the scheduler. You can click on a group to open it. Note that some entities (such as sensors) can only be used for conditions, not for actions.",included_number:"{number}/{total} selected"}}}}},ji={services:xi,ui:$i},Oi=Object.freeze({__proto__:null,default:ji,services:xi,ui:$i}),Si={generic:{turn_on:"Включить",turn_off:"Выключить",parameter_to_value:"{parameter} к {value}",action_with_parameter:"{action} с {parameter}"},climate:{set_temperature:"установить температуру[ {temperature}]",set_temperature_hvac_mode_heat:"обогрев[ {temperature}]",set_temperature_hvac_mode_cool:"охлаждение[ {temperature}]",set_temperature_hvac_mode_heat_cool:"обогрев/охлаждение[ {temperature}]",set_temperature_hvac_mode_heat_cool_range:"обогрев/охлаждение[ {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"aвто[ {temperature}]",set_hvac_mode:"установить режим[ {hvac_mode}]",set_preset_mode:"выбрать набор настроек[ {preset_mode}]",set_fan_mode:"set fan mode[ to {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"закрыть",open_cover:"открыть",set_cover_position:"установить позицию[ {position}]",set_cover_tilt_position:"установить наклон[ {tilt_position}]"},fan:{set_percentage:"установить скорость[ {speed}]",set_direction:"установить направление[ {direction}]",oscillate:"установить колебание[ {oscillate}]"},humidifier:{set_humidity:"установить влажность[ {humidity}]",set_mode:"установить режим[ {mode}]"},input_number:{set_value:"установить значение[ в {value}]"},input_select:{select_option:"установить опцию[ {option}]"},select:{select_option:"установить опцию[ {option}]"},light:{turn_on:"включить[ с {brightness} яркостью]"},media_player:{select_source:"выбрать источник[ {source}]"},notify:{send_message:"послать сообщение"},script:{execute:"запустить"},vacuum:{start_pause:"старт / пауза"},water_heater:{set_operation_mode:"установить режим[ {operation_mode}]",set_away_mode:"установить режим вне дома"}},zi={components:{date:{day_types_short:{daily:"ежедневно",workdays:"рабочие дни",weekend:"выходные"},day_types_long:{daily:"каждый день",workdays:"по рабочим дням",weekend:"в выходные"},days:"дни",tomorrow:"завтра",repeated_days:"каждый {days}",repeated_days_except:"каждый день кроме {excludedDays}",days_range:"с {startDay} до {endDay}",next_week_day:"в следующую {weekday}"},time:{absolute:"в {time}",interval:"с {startTime} до {endTime}",at_midnight:"в полночь",at_noon:"в полдень",at_sun_event:"в {sunEvent}"}},dialog:{enable_schedule:{title:"Завершите модификации",description:"Расписание, которое было изменено, в настоящее время отключено, следует ли его включить?"},confirm_delete:{title:"Удалить объект?",description:"Вы уверены, что хотите удалить этот объект?"},confirm_migrate:{title:"Изменить расписание",description:"При этом некоторые настройки будут потеряны. Вы хотите продолжить?"},weekday_picker:{title:"Repeated days for schedule",choose:"Choose..."},entity_picker:{title:"Choose entities",choose:"Choose...",no_results:"No matching items found"},action_picker:{title:"Choose action",show_all:"Show all supported entities"}},panel:{common:{title:"Планировщик",new_schedule:"Новое расписание",default_name:"Расписание #{id}"},overview:{no_entries:"Отсутствуют элементы",backend_error:"Нет соединенияс scheduler component. Scheduler component должен быть установлен до применения этой карты.",excluded_items:"{number} исключено {if number is 1} элемент {else} элементов",hide_excluded:"скрыть исключенные элементы",additional_tasks:"{number} больше {if number is 1} задача {else} задач"},editor:{repeated_days:"Repeated days",start_time:"Start time",stop_time:"End time",action:"Action",add_action:"Add action",select_timeslot:"Выберите временной слот",toggle_single_mode:"В простой режим",toggle_scheme_mode:"В режим схемы",validation_errors:{overlapping_time:"Schedule has overlapping timeslots",missing_target_entity:"One or more actions are missing a target entity",missing_service_parameter:"One or more actions are missing a required setting",missing_action:"Schedule has no actions"}},options:{conditions:{header:"Conditions",add_condition:"Add condition",new_condition:"New condition",types:{equal_to:"{entity} is equal to {value}",unequal_to:"{entity} is unequal to {value}",above:"{entity} is above {value}",below:"{entity} is below {value}"},options:{logic_and:"All conditions must be true",logic_or:"Any condition must be true",track_changes:"Re-evaluate when conditions change"}},period:{header:"период",start_date:"From",end_date:"To"},repeat_type:"поведение после срабатывания",tags:"Tags"},card_editor:{tabs:{entities:"Entities",other:"Other"},fields:{title:{heading:"Title of the card",options:{standard:"standard",hidden:"hidden",custom:"custom"},custom_title:"Custom title"},discover_existing:{heading:"Show all schedules",description:"This sets the 'discover existing' parameter. Previously created schedules will be automatically added to the card. "},time_step:{heading:"Time step",description:"Resolution (in minutes) for creating schedules",unit_minutes:"min"},default_editor:{heading:"Default time editor",options:{single:"Single schedule mode",scheme:"Time scheme mode"}},sort_by:{heading:"Sorting options",description:"Order in which the schedules appear in the card",options:{relative_time:"Time remaining until next action",title:"Displayed title of the schedule",state:"Show active schedules on top"}},display_format_primary:{heading:"Displayed primary info",description:"Configure which label is used for schedules in the overview",options:{default:"Schedule name",entity_action:"Summary of task"}},display_format_secondary:{heading:"Displayed secondary info",description:"Configure what additional properties are visible in the overview",options:{relative_time:"Time remaining until next action",time:"Configured time for next action",days:"Repeated days of the week",additional_tasks:"Number of additional tasks"}},show_header_toggle:{heading:"Show header toggle",description:"Show toggle switch at the top of the card for enabling/disabling all entities"},show_toggle_switches:{heading:"Show toggle switches",description:"Show toggle switch for each individual schedule in the card"},tags:{heading:"Tags",description:"Use tags to divide schedules between multiple cards"},entities:{button_label:"Configure included entities",heading:"Included entities",description:"Select the entities that you want to control using the scheduler. You can click on a group to open it. Note that some entities (such as sensors) can only be used for conditions, not for actions.",included_number:"{number}/{total} selected"}}}}},Ci={services:Si,ui:zi},Ai=Object.freeze({__proto__:null,default:Ci,services:Si,ui:zi}),Ei={generic:{turn_on:"Zapnúť",turn_off:"Vypnúť",parameter_to_value:"{parameter} na {value}",action_with_parameter:"{action} s {parameter}"},climate:{set_temperature:"nastaviť teplotu[ na {temperature}]",set_temperature_hvac_mode_heat:"vykurovanie[ na {temperature}]",set_temperature_hvac_mode_cool:"chladenie[ na {temperature}]",set_temperature_hvac_mode_heat_cool:"vykurovanie/chladenie[ na {temperature}]",set_temperature_hvac_mode_heat_cool_range:"vykurovanie/chladenie[ na {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"automatika[ na {temperature}]",set_hvac_mode:"nastaviť režim[ na {hvac_mode}]",set_preset_mode:"nastaviť predvoľbu[ {preset_mode}]",set_fan_mode:"nastaviť režim ventilátora[ to {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"zatvoriť",open_cover:"otvoriť",set_cover_position:"nastaviť polohu[ na {position}]",set_cover_tilt_position:"nastaviť naklonenie[ na {tilt_position}]"},fan:{set_percentage:"nastaviť rýchlosť[ na {speed}]",set_direction:"nastaviť smer[ na {direction}]",oscillate:"nastaviť osciláciu[ na {oscillate}]"},humidifier:{set_humidity:"nastaviť vlhkosť[ na {humidity}]",set_mode:"nastaviť režim[ na {mode}]"},input_number:{set_value:"nastaviť hodnotu[ na {value}]"},input_select:{select_option:"vybrať možnosť[ {option}]"},select:{select_option:"vybrať možnosť[ {option}]"},light:{turn_on:"zapnúť[ na {brightness} jas]"},media_player:{select_source:"vybrať zdroj[ {source}]"},notify:{send_message:"poslať notifikáciu"},script:{execute:"spustiť"},vacuum:{start_pause:"štart / pauza"},water_heater:{set_operation_mode:"nastaviť režim[ na {operation_mode}]",set_away_mode:"nastaviť režim neprítomnosti"}},Ti={components:{date:{day_types_short:{daily:"denne",workdays:"pracovné dni",weekend:"víkendy"},day_types_long:{daily:"každý deň",workdays:"cez pracovné dni",weekend:"cez víkend"},days:"dni",tomorrow:"zajtra",repeated_days:"každý {days}",repeated_days_except:"každý deň okrem {excludedDays}",days_range:"od {startDay} do {endDay}",next_week_day:"budúcu {weekday}"},time:{absolute:"od {time}",interval:"od {startTime} do {endTime}",at_midnight:"od polnoci",at_noon:"od obeda",at_sun_event:"na {sunEvent}"}},dialog:{enable_schedule:{title:"Dokončite úpravy",description:"Plán, ktorý sa zmenil, je momentálne zakázaný, chcete ho povoliť?"},confirm_delete:{title:"Odstrániť entitu?",description:"Naozaj chcete odstrániť túto entitu?"},confirm_migrate:{title:"Aktualizovať plán",description:"Touto akciou sa stratia niektoré nastavenia. Chcete pokračovať?"},weekday_picker:{title:"Dni opakovania pre plán",choose:"Vyberte..."},entity_picker:{title:"Vyberte entity",choose:"Vyberte...",no_results:"Žiadne vyhovujúce položky neboli nájdené"},action_picker:{title:"Vyberte akciu",show_all:"Zobraziť všetky podporované entity"}},panel:{common:{title:"Plánovač",new_schedule:"Nový plán",default_name:"Plán #{id}"},overview:{no_entries:"Žiadne položky na zobrazenie",backend_error:"Nepodarilo sa pripojiť ku komponentu Scheduler. Pred tým, ako použijete túto kartu ho musíte nainštalovať ako integráciu.",excluded_items:"Vylúčené položky: {number}",hide_excluded:"skryť vylúčené položky",additional_tasks:"Ďalšie úlohy: {number}"},editor:{repeated_days:"Dni opakovania",start_time:"Čas začiatku",stop_time:"Čas konca",action:"Akcia",add_action:"Pridať akciu",select_timeslot:"Najprv vyberte časový úsek",toggle_single_mode:"Do režimu jedného",toggle_scheme_mode:"Do režimu schémy",validation_errors:{overlapping_time:"Plán obsahuje prekrývajúce sa časové intervaly",missing_target_entity:"Pre aspoň jednu akciu nie je zadaná cieľová entita",missing_service_parameter:"Pre aspoň jednu akciu nie je zadané vyžadované nastavenie",missing_action:"Plán neobsahuje žiadne akcie"}},options:{conditions:{header:"Podmienky",add_condition:"Pridať podmienku",new_condition:"Nová podmienka",types:{equal_to:"{entity} sa rovná {value}",unequal_to:"{entity} sa nerovná {value}",above:"{entity} je nad {value}",below:"{entity} je pod {value}"},options:{logic_and:"Všetky podmienky musia platiť",logic_or:"Akákoľvek podmienka musí platiť",track_changes:"Prehodnoťte, keď sa zmenia podmienky"}},period:{header:"Obdobie",start_date:"Od",end_date:"Do"},repeat_type:"správanie sa po spustení",tags:"Štítky"},card_editor:{tabs:{entities:"Entity",other:"Iné"},fields:{title:{heading:"Názov karty",options:{standard:"štandardné",hidden:"skryté",custom:"vlastné"},custom_title:"Vlastný názov"},discover_existing:{heading:"Zobraziť všetky plány",description:"Tým sa nastaví parameter „objaviť existujúce“. Predtým vytvorené plány sa automaticky pridajú na kartu."},time_step:{heading:"Časový krok",description:"Rozlíšenie (v minútach) pre vytváranie plánov",unit_minutes:"min"},default_editor:{heading:"Predvolený editor času",options:{single:"Režim jedného plánu",scheme:"Režim schémy"}},sort_by:{heading:"Možnosti triedenia",description:"Poradie, v akom sa rozvrhy zobrazujú na karte",options:{relative_time:"Zostávajúci čas do ďalšej akcie",title:"Zobrazený názov rozvrhu",state:"Zobraziť aktívne plány navrchu"}},display_format_primary:{heading:"Zobrazené primárne informácie",description:"V prehľade nakonfigurujte, ktorý štítok sa použije pre plány",options:{default:"Názov rozvrhu",entity_action:"Zhrnutie úlohy"}},display_format_secondary:{heading:"Zobrazené sekundárne informácie",description:"Nakonfigurujte, ktoré ďalšie vlastnosti sú viditeľné v prehľade",options:{relative_time:"Zostávajúci čas do ďalšej akcie",time:"Nastavený čas pre ďalšiu akciu",days:"Opakované dni v týždni",additional_tasks:"Počet dodatočných úloh"}},show_header_toggle:{heading:"Zobraziť prepínač hlavičky",description:"Zobraziť prepínač v hornej časti karty na povolenie/zakázanie všetkých entít"},show_toggle_switches:{heading:"Zobraziť prepínače",description:"Zobraziť prepínač pre každý jednotlivý harmonogram na karte"},tags:{heading:"Štítky",description:"Použite štítky na rozdelenie plánov medzi viacero kariet"},entities:{button_label:"Konfigurácia zahrnutých entít",heading:"Zahrnuté entity",description:"Vyberte entity, ktoré chcete ovládať pomocou plánovača. Kliknutím na skupinu ju otvoríte. Upozorňujeme, že niektoré entity (napríklad senzory) možno použiť iba na podmienky, nie na akcie.",included_number:"{number}/{total} vybraný"}}}}},Di={services:Ei,ui:Ti},Mi={generic:{turn_on:"Vklopi",turn_off:"Izklopi",parameter_to_value:"{parameter} v {value}",action_with_parameter:"{action} z {parameter}"},climate:{set_temperature:"nastavi temperaturo[ na {temperature}]",set_temperature_hvac_mode_heat:"ogrej[ na {temperature}]",set_temperature_hvac_mode_cool:"ohladi[ na {temperature}]",set_temperature_hvac_mode_heat_cool:"ogrej/ohladi[ na {temperature}]",set_temperature_hvac_mode_heat_cool_range:"ogrej/ohladi[ na {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"samodejno[ na {temperature}]",set_hvac_mode:"nastavi način[ na {hvac_mode}]",set_preset_mode:"nastavi preset[ na {preset_mode}]",set_fan_mode:"nastavi ventilator[ na {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"zapri",open_cover:"odpri",set_cover_position:"nastavi pozicijo[ na {position}]",set_cover_tilt_position:"nastavi naklon[ na {tilt_position}]"},fan:{set_percentage:"nastavi hitrost[ na {speed}]",set_direction:"nastavi smer[ na {direction}]",oscillate:"nastavi obračanje[ na {oscillate}]"},humidifier:{set_humidity:"nastavi vlažnost[ na {humidity}]",set_mode:"nastavi način[ na {mode}]"},input_number:{set_value:"nastavi vrednost[ na {value}]"},input_select:{select_option:"izberi možnost[ {option}]"},select:{select_option:"izberi možnost[ {option}]"},light:{turn_on:"vključi[ z {brightness} brightness]"},media_player:{select_source:"Izberi vir[ {source}]"},notify:{send_message:"pošlji sporočilo"},script:{execute:"izvedi"},vacuum:{start_pause:"zaženi / ustavi"},water_heater:{set_operation_mode:"nastavi način[ na {operation_mode}]",set_away_mode:"nastavi način odsoten"}},Li={components:{date:{day_types_short:{daily:"dnevno",workdays:"delovniki",weekend:"vikend"},day_types_long:{daily:"vsak dan",workdays:"ob delovnikih",weekend:"ob vikendih"},days:"dni",tomorrow:"jutri",repeated_days:"vsakih {days}",repeated_days_except:"vsak dan razen {excludedDays}",days_range:"od {startDay} do {endDay}",next_week_day:"naslednji {weekday}"},time:{absolute:"ob {time}",interval:"od {startTime} do {endTime}",at_midnight:"opolnoči",at_noon:"opoldne",at_sun_event:"ob {sunEvent}"}},dialog:{enable_schedule:{title:"Zaključi spremembe",description:"Urnik, katerega ste spremenili je trenutno izključen, ali ga želite omogočiti?"},confirm_delete:{title:"Ali želite odstraniti entiteto?",description:"Ali ste prepričani, da želite odstraniti to entiteto?"},confirm_migrate:{title:"Spremenite urnik",description:"Nekatere nastavitve bodo s tem dejanjem izgubljene. Želite nadaljevati?"},weekday_picker:{title:"Repeated days for schedule",choose:"Choose..."},entity_picker:{title:"Choose entities",choose:"Choose...",no_results:"No matching items found"},action_picker:{title:"Choose action",show_all:"Show all supported entities"}},panel:{common:{title:"Urnik",new_schedule:"Nov urnik",default_name:"Urnik #{id}"},overview:{no_entries:"Ni vpisov za prikaz",backend_error:"Ni povezave s komponento urnika. Komponenta mora biti nameščena kot integracija, preden lahko uporabite to kartico.",excluded_items:"{number}{if number is 1} izločen predmet {else} izločenih predmetov",hide_excluded:"skrij izločene predmete",additional_tasks:"še {number}{if number is 1} opravilo {else} opravil"},editor:{repeated_days:"Repeated days",start_time:"Start time",stop_time:"End time",action:"Action",add_action:"Add action",select_timeslot:"Najprej izberi časovni okvir",toggle_single_mode:"To single mode",toggle_scheme_mode:"To scheme mode",validation_errors:{overlapping_time:"Schedule has overlapping timeslots",missing_target_entity:"One or more actions are missing a target entity",missing_service_parameter:"One or more actions are missing a required setting",missing_action:"Schedule has no actions"}},options:{conditions:{header:"Conditions",add_condition:"Add condition",new_condition:"New condition",types:{equal_to:"{entity} is equal to {value}",unequal_to:"{entity} is unequal to {value}",above:"{entity} is above {value}",below:"{entity} is below {value}"},options:{logic_and:"All conditions must be true",logic_or:"Any condition must be true",track_changes:"Ponovno preglej ko se pogoji spremenijo"}},period:{header:"Perioda",start_date:"From",end_date:"To"},repeat_type:"obnašanje, ko končaš",tags:"Tags"},card_editor:{tabs:{entities:"Entitete",other:"Ostalo"},fields:{title:{heading:"Ime kartice",options:{standard:"standardno",hidden:"skrito",custom:"po meri"},custom_title:"Ime po želji"},discover_existing:{heading:"Prikaži vse urnike",description:"Tole nastavi parameter 'discover existing'. Prej kreirani urniki bodo samodejno dodani v kartico. "},time_step:{heading:"Časovni korak",description:"Ločljivost (v minutah) za kreiranje urnikov",unit_minutes:"min"},default_editor:{heading:"Default time editor",options:{single:"V enojni način",scheme:"V shematski način"}},sort_by:{heading:"Možnosti sortiranja",description:"Zaporedje, po katerem se prikažejo urniki na kartici",options:{relative_time:"Preostali čas do naslednje akcije",title:"Prikazano ime urnika",state:"Prikaži aktivne urnike na vrhu"}},display_format_primary:{heading:"Prikazane primarne informacije",description:"Nastavite, kaj se prikazuje v pregledu urnikov",options:{default:"Ime urnika",entity_action:"Povzetek operacije"}},display_format_secondary:{heading:"Prikazane sekundarne informacije",description:"Nastavite, katere dodatne informacije želite imeti prikazane v pregledu",options:{relative_time:"Preostali čas do naslednje akcije",time:"Nastavljen čas za naslednjo akcijo",days:"Katere dni/kdaj se sproži akcija",additional_tasks:"Število dodatnih opravil"}},show_header_toggle:{heading:"Prikaži glavo",description:"Na vrhu prikaže stikalo, s katerim lahko omogočite/izključite vse entitete naenkrat"},show_toggle_switches:{heading:"Prikaži stikala",description:"Prikaži stikalo za vsak posamezen urnik na kartici"},tags:{heading:"Tag-i",description:"Uporabite tag-e za ločevanje urnikov med več karticami"},entities:{button_label:"Konfiguriraj vključene entitete",heading:"Vključene entitete",description:"Izberite entitete, katere želike krmiliti s tem urnikom. Lahko kliknete na skupino, da jo odprete. Vedite, da lahko nekatere entitete (npr. senzorje) uporabite samo v pogojih, ne pa za akcije.",included_number:"{number}/{total} izbranih"}}}}},Ni={services:Mi,ui:Li},Pi={generic:{turn_on:"Slå på",turn_off:"Stäng av",parameter_to_value:"{parameter} till {value}",action_with_parameter:"{action} med {parameter}"},climate:{set_temperature:"ställ in temperaturen[ på {temperature}]",set_temperature_hvac_mode_heat:"värma[ till {temperature}]",set_temperature_hvac_mode_cool:"kyla[ till {temperature}]",set_temperature_hvac_mode_heat_cool:"värma/kyla[ till {temperature}]",set_temperature_hvac_mode_heat_cool_range:"värma/kyla[ till {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"auto[ till {temperature}]",set_hvac_mode:"ställ in läget[ till {hvac_mode}]",set_preset_mode:"ställ in förinställningen[ till {preset_mode}]",set_fan_mode:"ställ in fläktläge[ till {fan_mode}]",set_swing_mode:"ställ in svängningsläge[ till {swing_mode}]"},cover:{close_cover:"stäng",open_cover:"öppna",set_cover_position:"ställ in positionen[ till {position}]",set_cover_tilt_position:"ställ in lutningsposition[ till {tilt_position}]"},fan:{set_percentage:"ställ in hastighet[ till {percentage}]",set_direction:"ställ in riktning[ till {direction}]",oscillate:"ställ in oscillation[ till {oscillate}]"},humidifier:{set_humidity:"ställ in luftfuktighet[ till {humidity}]",set_mode:"ställ in läge[ till {mode}]"},input_number:{set_value:"ställ in den[ till {value}]"},input_select:{select_option:"välj alternativ[ {option}]"},select:{select_option:"välj alternativ[ {option}]"},light:{turn_on:"slå på[ med {brightness} brightness]"},media_player:{select_source:"välj källa[ {source}]"},notify:{send_message:"send notification"},script:{execute:"utföra"},vacuum:{start_pause:"starta / pausa"},water_heater:{set_operation_mode:"ställ in läget[ till {operation_mode}]",set_away_mode:"ställ in borta läget"}},Ii={components:{date:{day_types_short:{daily:"daglig",workdays:"arbetsdagar",weekend:"helgen"},day_types_long:{daily:"varje dag",workdays:"på arbetsdagar",weekend:"i helgen"},days:"dagar",tomorrow:"imorgon",repeated_days:"varje {days}",repeated_days_except:"varje dag utom {excludedDays}",days_range:"från {startDay} till {endDay}",next_week_day:"nästa {weekday}"},time:{absolute:"kl. {time}",interval:"från {startTime} till {endTime}",at_midnight:"vid midnatt",at_noon:"vid middagstid",at_sun_event:"vid {sunEvent}"}},dialog:{enable_schedule:{title:"Slutför modifieringar",description:"Schemat du har ändrat är för närvarande inaktiverat, vill du aktivera den?"},confirm_delete:{title:"Ta bort enheten?",description:"Är du säker på att du vill ta bort den här enheten?"},confirm_migrate:{title:"Uppdatera schema",description:"Vissa inställningar kommer att gå förlorade genom den här ändringen. Vill du fortsätta?"},weekday_picker:{title:"Upprepade dagar för schema",choose:"Välj..."},entity_picker:{title:"Välj enheter",choose:"Välj...",no_results:"Inga matchande objekt hittades"},action_picker:{title:"Välj åtgärd",show_all:"Visa alla enheter som stöds"}},panel:{common:{title:"Schemaläggare",new_schedule:"Ny schema",default_name:"Schema #{id}"},overview:{no_entries:"Det finns inga objekt att visa",backend_error:"Kunde inte ansluta till schemaläggarkomponenten. Den måste installeras som integration innan det här kortet kan användas.",excluded_items:"{number} utesluten {if number is 1} artikel {else} artiklar",hide_excluded:"dölj uteslutna objekt",additional_tasks:"{number} mer {if number is 1} uppgift {else} uppgifter"},editor:{repeated_days:"Upprepade dagar",start_time:"Starttid",stop_time:"Sluttid",action:"Åtgärd",add_action:"Lägg till åtgärd",select_timeslot:"Välj en tidslucka",toggle_single_mode:"Till enkelläge",toggle_scheme_mode:"Till schemaläge",validation_errors:{overlapping_time:"Schemat har överlappande tidsluckor",missing_target_entity:"En eller flera åtgärder saknar en målentitet",missing_service_parameter:"En eller flera åtgärder saknar en obligatorisk inställning",missing_action:"Schemat har inga åtgärder"}},options:{conditions:{header:"Villkor",add_condition:"Lägg till villkor",new_condition:"Nytt villkor",types:{equal_to:"{entity} är lika med {value}",unequal_to:"{entity} är ojämlik med {value}",above:"{entity} är över {value}",below:"{entity} är under {value}"},options:{logic_and:"Alla villkor måste vara sanna",logic_or:"Något av villkoren måste vara sant",track_changes:"Omvärdera när förutsättningarna förändras"}},period:{header:"Period",start_date:"Från",end_date:"Till"},repeat_type:"beteende efter avslutad",tags:"Taggar"},card_editor:{tabs:{entities:"Enheter",other:"Andra"},fields:{title:{heading:"Kortets titel",options:{standard:"standard",hidden:"dold",custom:"anpassad"},custom_title:"Anpassad titel"},discover_existing:{heading:"Visa alla scheman",description:"Detta ställer in parametern ''upptäck befintliga''. Tidigare skapade scheman läggs automatiskt till på kortet."},time_step:{heading:"Tidssteg",description:"Upplösning (i minuter) för att skapa scheman",unit_minutes:"min"},default_editor:{heading:"Standard tidsredigerare",options:{single:"Enkelt schemalagt läge",scheme:"Tidschemaläge"}},sort_by:{heading:"Sorteringsalternativ",description:"Ordning i vilken scheman visas på kortet",options:{relative_time:"Tid kvar till nästa åtgärd",title:"Visad titel på schemat",state:"Visa aktiva scheman överst"}},display_format_primary:{heading:"Visad primär information",description:"Konfigurera vilken etikett som används för scheman i översikten",options:{default:"Schemanamn",entity_action:"Sammanfattning av uppgiften"}},display_format_secondary:{heading:"Visad sekundär information",description:"Konfigurera vilka ytterligare egenskaper som ska synas i översikten",options:{relative_time:"Tid kvar till nästa åtgärd",time:"Konfigurerad tid för nästa åtgärd",days:"Upprepade dagar i veckan",additional_tasks:"Antal ytterligare uppgifter"}},show_header_toggle:{heading:"Visa rubrikväxling",description:"Visa växlingsknappen högst upp på kortet för att aktivera/inaktivera alla enheter"},show_toggle_switches:{heading:"Visa växlingsknappar",description:"Visa växlingsknappen för varje enskilt schema i kortet"},tags:{heading:"Taggar",description:"Använd taggar för att dela upp scheman mellan flera kort"},entities:{button_label:"Konfigurera inkluderade entiteter",heading:"Inkluderade enheter",description:"Välj de enheter som du vill styra med hjälp av schemaläggaren. Du kan klicka på en grupp för att öppna den. Observera att vissa enheter (t.ex. sensorer) bara kan användas för villkor, inte för åtgärder.",included_number:"{number}/{total} vald"}}}}},qi={services:Pi,ui:Ii},Ri={generic:{turn_on:"Ввімкнути",turn_off:"Вимкнути",parameter_to_value:"{parameter} до {value}",action_with_parameter:"{action} з {parameter}"},climate:{set_temperature:"встановити температуру[ to {temperature}]",set_temperature_hvac_mode_heat:"нагрів[ to {temperature}]",set_temperature_hvac_mode_cool:"охолодження[ to {temperature}]",set_temperature_hvac_mode_heat_cool:"нагрів/охолодження[ to {temperature}]",set_temperature_hvac_mode_heat_cool_range:"нагрів/охолодження[ to {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"aвтоматичний[ to {temperature}]",set_hvac_mode:"встановити режим[ to {hvac_mode}]",set_preset_mode:"вибрати пресет[ to {preset_mode}]",set_fan_mode:"set fan mode[ to {fan_mode}]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"закрити",open_cover:"відкрити",set_cover_position:"встановити позицію[ to {position}]",set_cover_tilt_position:"set tilt position[ to {tilt_position}]"},fan:{set_percentage:"встановити швидкість[ to {speed}]",set_direction:"встановити напрямок[ to {direction}]",oscillate:"встановити коливання[ to {oscillate}]"},humidifier:{set_humidity:"встановити вологість[ to {humidity}]",set_mode:"встановити режим[ to {mode}]"},input_number:{set_value:"встановити значення[ to {value}]"},input_select:{select_option:"встановити опцію[ {option}]"},select:{select_option:"встановити опцію[ {option}]"},light:{turn_on:"увімкнути[ з {brightness} якскравістю]"},media_player:{select_source:"вибрати джерело[ {source}]"},notify:{send_message:"send notification"},script:{execute:"виконати"},vacuum:{start_pause:"старт / пауза"},water_heater:{set_operation_mode:"встановити режим[ to {operation_mode}]",set_away_mode:"встановити режим Не вдома"}},Vi={components:{date:{day_types_short:{daily:"щоденно",workdays:"робочі дні",weekend:"вихідні"},day_types_long:{daily:"кожного дня",workdays:"в робочі дні",weekend:"по вихідних"},days:"дні",tomorrow:"завтра",repeated_days:"кожні {days}",repeated_days_except:"кожного дня окрім {excludedDays}",days_range:"з {startDay} до {endDay}",next_week_day:"наступної {weekday}"},time:{absolute:"о {time}",interval:"з {startTime} до {endTime}",at_midnight:"опівночі",at_noon:"опівдні",at_sun_event:"о {sunEvent}"}},dialog:{enable_schedule:{title:"Завершіть зміни",description:"Розклад, який було змінено, наразі вимкнено, чи потрібно його ввімкнути?"},confirm_delete:{title:"Видалити сутність?",description:"Ви дійсно бажаєте видалити цю сутність?"},confirm_migrate:{title:"Змінити розклад",description:"У результаті цієї дії деякі налаштування буде втрачено. Ви бажаєте продовжити?"},weekday_picker:{title:"Repeated days for schedule",choose:"Choose..."},entity_picker:{title:"Choose entities",choose:"Choose...",no_results:"No matching items found"},action_picker:{title:"Choose action",show_all:"Show all supported entities"}},panel:{common:{title:"Планувальник",new_schedule:"Новий розклад",default_name:"Розклад #{id}"},overview:{no_entries:"Елементи відсутні",backend_error:"Не вдалося підключитися до компонента планувальника. Перш ніж використовувати цю карту, її потрібно встановити як інтеграцію.",excluded_items:"{number} виключено {if number is 1} елемент {else} елементів",hide_excluded:"сховати виключені елементи",additional_tasks:"{number} більше {if number is 1} завдання {else} завдань"},editor:{repeated_days:"Repeated days",start_time:"Start time",stop_time:"End time",action:"Action",add_action:"Add action",select_timeslot:"Спершу виберіть часовий проміжок",toggle_single_mode:"До одиночного режиму",toggle_scheme_mode:"До схемного режиму",validation_errors:{overlapping_time:"Schedule has overlapping timeslots",missing_target_entity:"One or more actions are missing a target entity",missing_service_parameter:"One or more actions are missing a required setting",missing_action:"Schedule has no actions"}},options:{conditions:{header:"Conditions",add_condition:"Add condition",new_condition:"New condition",types:{equal_to:"{entity} is equal to {value}",unequal_to:"{entity} is unequal to {value}",above:"{entity} is above {value}",below:"{entity} is below {value}"},options:{logic_and:"All conditions must be true",logic_or:"Any condition must be true",track_changes:"Re-evaluate when conditions change"}},period:{header:"період",start_date:"From",end_date:"To"},repeat_type:"поведінка після спрацювання",tags:"Tags"},card_editor:{tabs:{entities:"Entities",other:"Other"},fields:{title:{heading:"Title of the card",options:{standard:"standard",hidden:"hidden",custom:"custom"},custom_title:"Custom title"},discover_existing:{heading:"Show all schedules",description:"This sets the 'discover existing' parameter. Previously created schedules will be automatically added to the card. "},time_step:{heading:"Time step",description:"Resolution (in minutes) for creating schedules",unit_minutes:"min"},default_editor:{heading:"Default time editor",options:{single:"Single schedule mode",scheme:"Time scheme mode"}},sort_by:{heading:"Sorting options",description:"Order in which the schedules appear in the card",options:{relative_time:"Time remaining until next action",title:"Displayed title of the schedule",state:"Show active schedules on top"}},display_format_primary:{heading:"Displayed primary info",description:"Configure which label is used for schedules in the overview",options:{default:"Schedule name",entity_action:"Summary of task"}},display_format_secondary:{heading:"Displayed secondary info",description:"Configure what additional properties are visible in the overview",options:{relative_time:"Time remaining until next action",time:"Configured time for next action",days:"Repeated days of the week",additional_tasks:"Number of additional tasks"}},show_header_toggle:{heading:"Show header toggle",description:"Show toggle switch at the top of the card for enabling/disabling all entities"},show_toggle_switches:{heading:"Show toggle switches",description:"Show toggle switch for each individual schedule in the card"},tags:{heading:"Tags",description:"Use tags to divide schedules between multiple cards"},entities:{button_label:"Configure included entities",heading:"Included entities",description:"Select the entities that you want to control using the scheduler. You can click on a group to open it. Note that some entities (such as sensors) can only be used for conditions, not for actions.",included_number:"{number}/{total} selected"}}}}},Hi={services:Ri,ui:Vi},Ui={generic:{turn_on:"پر سوئچ کریں",turn_off:"بند کر دیں",parameter_to_value:"{parameter} کو {value} پر سیٹ کریں",action_with_parameter:"{parameter} کے ساتھ {action}"},climate:{set_temperature:"درجہ حرارت سیٹ کریں[ {temperature} پر]",set_temperature_hvac_mode_heat:"ہیٹ[ {temperature} پر]",set_temperature_hvac_mode_cool:"کول[ {temperature} پر]",set_temperature_hvac_mode_heat_cool:"ہیٹ/کول[ {temperature} پر]",set_temperature_hvac_mode_heat_cool_range:"ہیٹ/کول[ {target_temp_low} سے {target_temp_high} تک]",set_temperature_hvac_mode_auto:"آٹو[ {temperature} پر]",set_hvac_mode:"موڈ سیٹ کریں[ {hvac_mode} پر]",set_preset_mode:"پری سیٹ موڈ سیٹ کریں[ {preset_mode} پر]",set_fan_mode:"فین موڈ سیٹ کریں[ {fan_mode} پر]",set_swing_mode:"set swing mode[ to {swing_mode}]"},cover:{close_cover:"بند کریں",open_cover:"کھولیں",set_cover_position:"پوزیشن سیٹ کریں[ {position} پر]",set_cover_tilt_position:"جھکاؤ پوزیشن سیٹ کریں[ {tilt_position} پر]"},fan:{set_percentage:"رفتار سیٹ کریں[ {percentage} پر]",set_direction:"سمت سیٹ کریں[ {direction} پر]",oscillate:"آسیلیشن سیٹ کریں[ {oscillate} پر]"},humidifier:{set_humidity:"نمی سیٹ کریں[ {humidity} پر]",set_mode:"موڈ سیٹ کریں[ {mode} پر]"},input_number:{set_value:"ویلیو سیٹ کریں[ {value} پر]"},input_select:{select_option:"آپشن منتخب کریں[ {option}]"},select:{select_option:"آپشن منتخب کریں[ {option}]"},light:{turn_on:"آن کریں[ {brightness} چمک کے ساتھ]"},media_player:{select_source:"سورس منتخب کریں[ {source}]"},notify:{send_message:"نوٹیفکیشن بھیجیں"},script:{execute:"چلائیں"},vacuum:{start_pause:"شروع / روکیں"},water_heater:{set_operation_mode:"موڈ سیٹ کریں[ {operation_mode} پر]",set_away_mode:"غیر موجودگی کا موڈ سیٹ کریں"}},Fi={components:{date:{day_types_short:{daily:"روزانہ",workdays:"کام کے دن",weekend:"ہفتہ اختتام"},day_types_long:{daily:"ہر دن",workdays:"کام کے دنوں میں",weekend:"ہفتے کے آخر میں"},days:"دن",tomorrow:"کل",repeated_days:"ہر {days}",repeated_days_except:"ہر دن سوائے {excludedDays}",days_range:"{startDay} سے {endDay} تک",next_week_day:"اگلا {weekday}"},time:{absolute:"{time} پر",interval:"{startTime} سے {endTime} تک",at_midnight:"آدھی رات کو",at_noon:"دوپہر کو",at_sun_event:"{sunEvent} کے وقت"}},dialog:{enable_schedule:{title:"ترمیم مکمل کریں",description:"جو شیڈول آپ نے بدلا ہے وہ اس وقت غیر فعال ہے، کیا آپ اسے فعال کرنا چاہتے ہیں؟"},confirm_delete:{title:"اینٹیٹی حذف کریں؟",description:"کیا آپ واقعی اس اینٹیٹی کو حذف کرنا چاہتے ہیں؟"},confirm_migrate:{title:"شیڈول اپ ڈیٹ کریں",description:"اس تبدیلی سے کچھ سیٹنگز ضائع ہو سکتی ہیں۔ کیا آپ جاری رکھنا چاہتے ہیں؟"},weekday_picker:{title:"شیڈول کے لیے دہرائے گئے دن",choose:"منتخب کریں..."},entity_picker:{title:"اینٹیٹیز منتخب کریں",choose:"منتخب کریں...",no_results:"کوئی مماثل آئٹمز نہیں ملے"},action_picker:{title:"عمل منتخب کریں",show_all:"تمام تعاون یافتہ اداروں کو دکھائیں۔"}},panel:{common:{title:"شیڈولر",new_schedule:"نیا شیڈول",default_name:"شیڈول #{id}"},overview:{no_entries:"دکھانے کے لیے کوئی آئٹمز نہیں ہیں",backend_error:"شیڈولر کمپوننٹ سے کنکشن نہیں ہو سکا۔ اسے کارڈ استعمال کرنے سے پہلے انٹیگریشن کے طور پر انسٹال کرنا ضروری ہے۔",excluded_items:"{number} خارج شدہ {if number is 1} آئٹم {else} آئٹمز",hide_excluded:"خارج شدہ آئٹمز چھپائیں",additional_tasks:"{number} مزید {if number is 1} کام {else} کام"},editor:{repeated_days:"دہرائے گئے دن",start_time:"آغاز کا وقت",stop_time:"اختتامی وقت",action:"عمل",add_action:"عمل شامل کریں",select_timeslot:"ٹائم سلاٹ منتخب کریں",toggle_single_mode:"سنگل موڈ پر جائیں",toggle_scheme_mode:"اسکیم موڈ پر جائیں",validation_errors:{overlapping_time:"شیڈول میں وقتوں کا اوورلیپ ہے",missing_target_entity:"ایک یا زیادہ اعمال میں ہدف اینٹیٹی غائب ہے",missing_service_parameter:"ایک یا زیادہ اعمال میں مطلوبہ سیٹنگ غائب ہے",missing_action:"شیڈول میں کوئی عمل موجود نہیں"}},options:{conditions:{header:"شرائط",add_condition:"شرط شامل کریں",new_condition:"نئی شرط",types:{equal_to:"{entity} {value} کے برابر ہے",unequal_to:"{entity} {value} کے برابر نہیں ہے",above:"{entity} {value} سے زیادہ ہے",below:"{entity} {value} سے کم ہے"},options:{logic_and:"تمام شرائط درست ہونی چاہئیں",logic_or:"کوئی ایک شرط درست ہونی چاہیے",track_changes:"جب شرائط بدلیں تو دوبارہ جانچ کریں"}},period:{header:"مدت",start_date:"سے",end_date:"تک"},repeat_type:"مکمل ہونے کے بعد کا برتاؤ",tags:"ٹیگز"},card_editor:{tabs:{entities:"اینٹیٹیز",other:"دیگر"},fields:{title:{heading:"کارڈ کا عنوان",options:{standard:"معیاری",hidden:"چھپا ہوا",custom:"حسبِ ضرورت"},custom_title:"اپنا عنوان"},discover_existing:{heading:"تمام شیڈولز دکھائیں",description:"یہ 'discover existing' پیرامیٹر سیٹ کرتا ہے۔ پہلے سے بنائے گئے شیڈولز خود بخود کارڈ میں شامل ہو جائیں گے۔"},time_step:{heading:"وقت کا وقفہ",description:"شیڈول بنانے کے لیے وقت کی ریزولوشن (منٹ میں)",unit_minutes:"منٹ"},default_editor:{heading:"ڈیفالٹ ٹائم ایڈیٹر",options:{single:"سنگل شیڈول موڈ",scheme:"ٹائم اسکیم موڈ"}},sort_by:{heading:"ترتیب کے اختیارات",description:"کارڈ میں شیڈولز کی ترتیب",options:{relative_time:"اگلے عمل تک باقی وقت",title:"شیڈول کا دکھایا گیا عنوان",state:"فعال شیڈولز اوپر دکھائیں"}},display_format_primary:{heading:"مرکزی معلومات کی نمائش",description:"اوورویو میں شیڈولز کے لیے لیبل کنفیگر کریں",options:{default:"شیڈول کا نام",entity_action:"کام کا خلاصہ"}},display_format_secondary:{heading:"ثانوی معلومات کی نمائش",description:"اوورویو میں اضافی خصوصیات دکھانے کا انتخاب کریں",options:{relative_time:"اگلے عمل تک باقی وقت",time:"اگلے عمل کا وقت",days:"ہفتے کے دہرائے گئے دن",additional_tasks:"اضافی کاموں کی تعداد"}},show_header_toggle:{heading:"ہیڈر ٹوگل دکھائیں",description:"کارڈ کے اوپر تمام اینٹیٹیز کو فعال/غیر فعال کرنے کے لیے سوئچ دکھائیں"},show_toggle_switches:{heading:"ٹوگل سوئچز دکھائیں",description:"کارڈ میں ہر انفرادی شیڈول کے لیے ٹوگل سوئچ دکھائیں"},tags:{heading:"ٹیگز",description:"شیڈولز کو مختلف کارڈز میں تقسیم کرنے کے لیے ٹیگز استعمال کریں"},entities:{button_label:"شامل اینٹیٹیز ترتیب دیں",heading:"شامل اینٹیٹیز",description:"وہ اینٹیٹیز منتخب کریں جنہیں آپ شیڈولر کے ذریعے کنٹرول کرنا چاہتے ہیں۔ آپ گروپ پر کلک کر کے اسے کھول سکتے ہیں۔ یاد رکھیں کہ کچھ اینٹیٹیز (جیسے سینسرز) صرف شرائط کے لیے استعمال ہو سکتی ہیں، اعمال کے لیے نہیں۔",included_number:"{number}/{total} منتخب شدہ"}}}}},Bi={services:Ui,ui:Fi},Wi={generic:{turn_on:"打开",turn_off:"关闭",parameter_to_value:"{parameter} 至 {value}",action_with_parameter:"{action} 使用 {parameter}"},climate:{set_temperature:"设定温度[ 至 {temperature}]",set_temperature_hvac_mode_heat:"制热模式[ 至 {temperature}]",set_temperature_hvac_mode_cool:"制冷模式[ 至 {temperature}]",set_temperature_hvac_mode_heat_cool:"制热模式/制冷模式[ 至 {temperature}]",set_temperature_hvac_mode_heat_cool_range:"制热模式/制冷模式[ 至 {target_temp_low} - {target_temp_high}]",set_temperature_hvac_mode_auto:"自动[ 至 {temperature}]",set_hvac_mode:"设定模式[ 为 {hvac_mode}]",set_preset_mode:"设定预设模式[ 为 {preset_mode}]",set_fan_mode:"设置风扇模式[ 为 {fan_mode}]",set_swing_mode:"设置摆动模式[ 为 {swing_mode}]"},cover:{close_cover:"关闭",open_cover:"打开",set_cover_position:"设置位置[ 为 {position}]",set_cover_tilt_position:"设置倾斜位置[ 为 {tilt_position}]"},fan:{set_percentage:"设定风速[ 为 {speed}]",set_direction:"设定方向[ 为 {direction}]",oscillate:"设置摇摆[ 为 {oscillate}]"},humidifier:{set_humidity:"设定湿度[ 至 {humidity}]",set_mode:"设定模式[ 为 {mode}]"},input_number:{set_value:"设定数值[ 至 {value}]"},input_select:{select_option:"选择选项[ {option}]"},select:{select_option:"选择选项[ {option}]"},light:{turn_on:"打开[ 并设定亮度为 {brightness}]"},media_player:{select_source:"选择播放源[ {source}]"},notify:{send_message:"发送通知"},script:{execute:"执行"},vacuum:{start_pause:"开始 / 暂停"},water_heater:{set_operation_mode:"设定模式[ 为 {operation_mode}]",set_away_mode:"设定离开模式"}},Zi={components:{date:{day_types_short:{daily:"每天",workdays:"工作日",weekend:"周末"},day_types_long:{daily:"每天",workdays:"工作日",weekend:"周末"},days:"天",tomorrow:"明天",repeated_days:"每 {days}",repeated_days_except:"每天，除了 {excludedDays}",days_range:"从 {startDay} 至 {endDay}",next_week_day:"下{weekday}"},time:{absolute:"{time}",interval:"从 {startTime} 至 {endTime}",at_midnight:"午夜",at_noon:"中午",at_sun_event:"{sunEvent}"}},dialog:{enable_schedule:{title:"完成修改",description:"您修改的计划任务当前已禁用，是否需要启用？"},confirm_delete:{title:"是否删除实体？",description:"您确定要删除此实体吗？"},confirm_migrate:{title:"修改任务",description:"此操作将丢失某些设置。 你想继续吗？"},weekday_picker:{title:"重复周期",choose:"选择..."},entity_picker:{title:"选择实体",choose:"选择...",no_results:"未找到匹配项"},action_picker:{title:"选择动作",show_all:"显示所有受支持的实体"}},panel:{common:{title:"计划任务",new_schedule:"新建任务",default_name:"任务 #{id}"},overview:{no_entries:"无事项",backend_error:"计划任务组件关联失败。使用本卡片前，需先安装计划任务组件（Scheduler component）集成.",excluded_items:"其他{number}项{if number is 1}任务{else}任务",hide_excluded:"隐藏其他任务",additional_tasks:"另有{number}项{if number is 1}任务{else}任务"},editor:{repeated_days:"重复周期",start_time:"开始时间",stop_time:"结束时间",action:"动作",add_action:"添加动作",select_timeslot:"选择时间段",toggle_single_mode:"切换为单次模式",toggle_scheme_mode:"切换为方案模式",validation_errors:{overlapping_time:"计划任务存在重叠的时间段",missing_target_entity:"一个或多个动作缺少目标实体",missing_service_parameter:"一个或多个操作缺少必要设置",missing_action:"计划任务未设置任何动作"}},options:{conditions:{header:"条件",add_condition:"添加条件",new_condition:"新建条件",types:{equal_to:"{entity} 等于 {value}",unequal_to:"{entity} 不等于 {value}",above:"{entity} 大于 {value}",below:"{entity} 小于 {value}"},options:{logic_and:"所有条件必须同时满足（AND）",logic_or:"任意一个条件满足（OR）",track_changes:"当条件变化时重新判断"}},period:{header:"生效时段",start_date:"从",end_date:"到"},repeat_type:"任务完成后的行为",tags:"标签"},card_editor:{tabs:{entities:"实体",other:"其他"},fields:{title:{heading:"卡片标题",options:{standard:"标准",hidden:"隐藏",custom:"自定义"},custom_title:"自定义标题"},discover_existing:{heading:"显示所有计划任务",description:"这将设置‘发现已有任务(discover existing)’参数。已创建的任务会自动添加到卡片中。 "},time_step:{heading:"时间调整步长",description:"创建计划任务时，时间选择器每次点击增加或减少的分钟数",unit_minutes:"分钟"},default_editor:{heading:"新建任务默认模式",options:{single:"单次任务模式",scheme:"时间方案模式"}},sort_by:{heading:"排序方式",description:"计划任务在卡片中的显示顺序",options:{relative_time:"按距离下次执行时间排序",title:"按任务标题排序",state:"优先显示已启用的任务"}},display_format_primary:{heading:"显示的主要信息",description:"设置卡片中显示任务的主要信息",options:{default:"任务名称",entity_action:"任务概要"}},display_format_secondary:{heading:"显示的次要信息",description:"设置卡片中显示任务的次要信息",options:{relative_time:"下次执行的剩余时间",time:"下次执行的设定时间",days:"重复周期（星期）",additional_tasks:"额外任务数量"}},show_header_toggle:{heading:"显示标题开关",description:"在卡片顶部显示切换开关，用于启用/禁用所有实体"},show_toggle_switches:{heading:"显示切换开关",description:"为卡片中的每个单独计划显示切换开关"},tags:{heading:"标签",description:"使用标签可将不同的计划任务分配到多个卡片中"},entities:{button_label:"配置包含的实体（配置后未选择的实体相关任务将会隐藏）",heading:"包含的实体",description:"选择您希望通过计划任务控制的实体。您可以点击一个分组将其展开。请注意，部分实体（例如传感器）只能用作触发条件，而不能作为执行动作。",included_number:"已选择 {number}/{total}"}}}}},Ki={services:Wi,ui:Zi};const Gi={bg:at,ca:dt,cs:ht,de:gt,el:bt,en:$t,es:zt,et:Tt,es_419:zt,fi:Nt,fr:Rt,he:Ft,hu:Kt,it:Qt,lv:ii,nb:ci,nl:ni,nn:ci,no:ci,pl:pi,pt:yi,"pt-BR":ki,ro:Oi,sk:Object.freeze({__proto__:null,default:Di,services:Ei,ui:Ti}),sl:Object.freeze({__proto__:null,default:Ni,services:Mi,ui:Li}),sv:Object.freeze({__proto__:null,default:qi,services:Pi,ui:Ii}),ru:Ai,uk:Object.freeze({__proto__:null,default:Hi,services:Ri,ui:Vi}),ur:Object.freeze({__proto__:null,default:Bi,services:Ui,ui:Fi}),"zh-Hans":Object.freeze({__proto__:null,default:Ki,services:Wi,ui:Zi})};function Ji(e,t,i=[],s=[]){let a;try{a=e.split(".").reduce((e,t)=>e[t],Gi[t.locale.language]),a||(a=e.split(".").reduce((e,t)=>e[t],Gi.en))}catch(t){try{a=e.split(".").reduce((e,t)=>e[t],Gi.en)}catch(e){a=""}}if(i=[i||[]].flat(),s=[s||[]].flat(),i.length&&s.length&&a)for(let e=0;e<i.length;e++){a=a.replace(String(i[e]),String(s[e]));const t=a.match(/\{if ([a-z]+) is ([^\}]+)\}\ ?([^\{]+)\ ?\{else\}\ ?([^\{]+)/i);if(t&&String(i[e]).replace(/[\{\}']+/g,"")==t[1]){a=String(s[e])==t[2]?a.replace(t[0],t[3]):a.replace(t[0],t[4])}}const o=/\[([^\]]+)\]/.exec(a);if(o){a=/\{([^\}]+)\}/.exec(o[1])?a.replace(o[0],""):a.replace(o[0],o[1])}return a||console.log(`missing translation for ${e}`),a}const Yi=(e,t,i)=>{var s;return""===i&&(i=void 0),"string"==typeof i?i:t?e&&(e=>{var t,i;if(!e||"function"!=typeof e.formatEntityName)return!1;const[s,a]=(null!==(i=null===(t=null==e?void 0:e.config)||void 0===t?void 0:t.version)&&void 0!==i?i:"").split(".",2);return Number(s)>2026||2026===Number(s)&&Number(a)>=4})(e)?e.formatEntityName(t,i)||void 0:null===(s=t.attributes)||void 0===s?void 0:s.friendly_name:void 0},Qi=e=>e.split(".")[1]||"",Xi=e=>e.split(".")[0]||"",es=(e,t)=>{const i=Yi(e,null==e?void 0:e.states[t],void 0);return i||Qi(t).replace(/_/g," ")};function ts(e,t){let i=!1;if(!t)return!1;if(e.match(/^[a-z0-9_\.]+$/))i=!e.includes(".")&&t.includes(".")?e==Xi(t):e==t;else try{if(e.startsWith("/")&&e.endsWith("/")||-1!==e.indexOf("*")){e.startsWith("/")||(e=`/^${e=e.replace(/\./g,".").replace(/\*/g,".*")}$/`);i=new RegExp(e.slice(1,-1)).test(t)}}catch(e){}return i}const is=(e,t)=>e.includes(".")?((t.include||Ue).some(t=>ts(t,e))||Object.keys(t.customize||{}).some(t=>ts(t,e)))&&!(t.exclude||[]).some(t=>ts(t,e)):((t.include||Ue).map(Xi).some(t=>ts(t,e))||Object.keys(t.customize||{}).map(Xi).some(t=>ts(t,e)))&&!(t.exclude||[]).some(t=>ts(t,e)),ss=(e,t)=>{var i,s;let a=[],o=!0;if(e.entries.forEach(e=>{e.slots.forEach(e=>{e.actions.forEach(e=>{var t;let i=(null===(t=e.target)||void 0===t?void 0:t.entity_id)?[e.target.entity_id].flat():[e.service];a=[...a,...i]})})}),![...new Set(a)].every(e=>is(e,t)))return!1;const n=[t.tags||[]].flat();n.length&&(o=!1,((e.tags||[]).some(e=>n.includes(e))||n.includes("none")&&!(null===(i=e.tags)||void 0===i?void 0:i.length)||n.includes("enabled")&&e.enabled||n.includes("disabled")&&!e.enabled)&&(o=!0));const r=[t.exclude_tags||[]].flat();return r.length&&o&&((e.tags||[]).some(e=>r.includes(e))||r.includes("none")&&!(null===(s=e.tags)||void 0===s?void 0:s.length)||r.includes("enabled")&&e.enabled||r.includes("disabled")&&!e.enabled)&&(o=!1),o},as=(e,t)=>((e,t)=>e<t?-1:e>t?1:0)(e.toLowerCase(),t.toLowerCase()),os=e=>{const t=e.trim();return t.charAt(0).toUpperCase()+t.slice(1)},ns=(e,t,i=!0)=>{const s=t.localize(e);if(s||!i)return s;return`{${e.split(".").pop()}}`},rs=(e,t)=>{let i=e.mode==be.Sunrise?ns("ui.panel.config.automation.editor.conditions.type.sun.sunrise",t):ns("ui.panel.config.automation.editor.conditions.type.sun.sunset",t);"de"!=t.language&&(i=i.toLowerCase());const s=3600*e.hours+60*e.minutes;if(Math.abs(s)<=60)return Ji("ui.components.time.at_sun_event",t,"{sunEvent}",i);let a=ns(s<0?"ui.panel.config.automation.editor.conditions.type.sun.before":"ui.panel.config.automation.editor.conditions.type.sun.after",t);return a=a.replace(/[^a-z]/gi,"").toLowerCase(),`${Ie(e,{seconds:!1}).split(/\+|\-/).pop()} ${a} ${i}`},ds=e=>"string"==typeof e&&/\{\{|\{%/.test(e),ls={alarm_control_panel:{alarm_disarm:{target:{}},alarm_arm_home:{supported_features:1,target:{}},alarm_arm_away:{supported_features:2,target:{}},alarm_arm_night:{supported_features:4,target:{}},alarm_arm_custom_bypass:{supported_features:16,target:{}},alarm_arm_vacation:{supported_features:32,target:{}}},automation:{turn_on:{translation_key:"services.generic.turn_on",target:{}},turn_off:{translation_key:"services.generic.turn_off",target:{}},trigger:{target:{}}},button:{press:{target:{}}},climate:{turn_off:{translation_key:"services.generic.turn_off",target:{},supported_features:128},turn_on:{translation_key:"services.generic.turn_on",target:{},supported_features:256},set_hvac_mode:{translation_key:"services.climate.set_hvac_mode",target:{},fields:{hvac_mode:{}}},set_temperature:{translation_key:["services.climate.set_temperature","services.climate.set_temperature_hvac_mode_heat","services.climate.set_temperature_hvac_mode_cool","services.climate.set_temperature_hvac_mode_heat_cool"],target:{},fields:{temperature:{supported_features:1},target_temp_high:{supported_features:2},target_temp_low:{supported_features:2},hvac_mode:{optional:!0}}},set_preset_mode:{translation_key:"services.climate.set_preset_mode",supported_features:16,target:{},fields:{preset_mode:{}}},set_fan_mode:{translation_key:"services.climate.set_fan_mode",supported_features:8,target:{},fields:{fan_mode:{}}},set_swing_mode:{translation_key:"services.climate.set_swing_mode",supported_features:32,target:{},fields:{swing_mode:{}}}},cover:{close_cover:{translation_key:"services.cover.close_cover",supported_features:2,target:{}},open_cover:{translation_key:"services.cover.open_cover",supported_features:1,target:{}},set_cover_position:{translation_key:"services.cover.set_cover_position",supported_features:4,target:{},fields:{position:{}}},close_cover_tilt:{supported_features:32,target:{}},open_cover_tilt:{supported_features:16,target:{}},set_cover_tilt_position:{translation_key:"services.cover.set_cover_tilt_position",supported_features:128,target:{},fields:{tilt_position:{}}}},fan:{turn_on:{translation_key:"services.generic.turn_on",target:{}},turn_off:{translation_key:"services.generic.turn_off",target:{}},set_percentage:{translation_key:"services.fan.set_percentage",supported_features:1,target:{},fields:{percentage:{}}},oscillate:{translation_key:"services.fan.oscillate",supported_features:2,target:{},fields:{oscillating:{}}},set_direction:{translation_key:"services.fan.set_direction",supported_features:4,target:{},fields:{direction:{}}},set_preset_mode:{translation_key:"services.climate.set_preset_mode",supported_features:8,target:{},fields:{preset_mode:{}}}},humidifier:{turn_on:{translation_key:"services.generic.turn_on",target:{}},turn_off:{translation_key:"services.generic.turn_off",target:{}},set_humidity:{translation_key:"services.humidifier.set_humidity",target:{},fields:{humidity:{}}},set_mode:{translation_key:"services.humidifier.set_mode",supported_features:1,target:{},fields:{mode:{}}}},input_boolean:{turn_on:{translation_key:"services.generic.turn_on",target:{}},turn_off:{translation_key:"services.generic.turn_off",target:{}}},input_button:{press:{target:{}}},input_number:{set_value:{translation_key:"services.input_number.set_value",target:{},fields:{value:{}}}},input_select:{select_option:{translation_key:"services.input_select.select_option",target:{},fields:{option:{}}}},lawn_mower:{start_mowing:{target:{},supported_features:1},pause:{target:{},supported_features:2},dock:{target:{},supported_features:4}},light:{turn_on:{translation_key:"services.light.turn_on",target:{},fields:{brightness:{optional:!0}}},turn_off:{translation_key:"services.generic.turn_off",target:{}}},lock:{lock:{target:{}},unlock:{target:{}}},media_player:{turn_on:{translation_key:"services.generic.turn_on",target:{}},turn_off:{translation_key:"services.generic.turn_off",target:{}},select_source:{translation_key:"services.media_player.select_source",supported_features:2048,target:{},fields:{source:{}}}},notify:{"{entity_id}":{translation_key:"services.notify.send_message",fields:{title:{optional:!0},message:{}}}},number:{set_value:{translation_key:"services.input_number.set_value",target:{},fields:{value:{}}}},scene:{turn_on:{target:{}}},script:{"{entity_id}":{translation_key:"services.script.execute"}},select:{select_option:{translation_key:"services.input_select.select_option",target:{},fields:{option:{}}}},switch:{turn_on:{translation_key:"services.generic.turn_on",target:{}},turn_off:{translation_key:"services.generic.turn_off",target:{}}},vacuum:{turn_on:{translation_key:"services.generic.turn_on",supported_features:1,target:{}},start:{supported_features:8192,target:{}},play_pause:{target:{}}},valve:{open_valve:{supported_features:1,target:{}},close_valve:{supported_features:2,target:{}},set_valve_position:{translation_key:"services.cover.set_cover_position",supported_features:4,target:{},fields:{position:{}}}},water_heater:{set_temperature:{translation_key:"services.climate.set_temperature",supported_features:1,target:{},fields:{temperature:{}}},set_operation_mode:{translation_key:"services.water_heater.set_operation_mode",supported_features:2,target:{},fields:{operation_mode:{}}},set_away_mode:{translation_key:"services.water_heater.set_away_mode",supported_features:4,target:{},fields:{away_mode:{}}},turn_off:{translation_key:"services.generic.turn_off",target:{},supported_features:8},turn_on:{translation_key:"services.generic.turn_on",target:{},supported_features:8}}},cs=e=>{if("object"!=typeof e)return null;if(!Object.keys(e).length||!Object.keys(e).every(e=>"string"==typeof e))return null;let t={value:"",label:""};return Object.keys(e).includes("name")?t=Object.assign(Object.assign({},t),{label:String(e.name)}):Object.keys(e).includes("label")?t=Object.assign(Object.assign({},t),{label:String(e.label)}):Object.keys(e).includes("value")&&(t=Object.assign(Object.assign({},t),{label:String(e.value)})),Object.keys(e).includes("value")?t=Object.assign(Object.assign({},t),{value:String(e.value)}):Object.keys(e).includes("name")?t=Object.assign(Object.assign({},t),{value:String(e.name)}):Object.keys(e).includes("label")&&(t=Object.assign(Object.assign({},t),{value:String(e.label)})),Object.keys(e).includes("icon")&&Ze(e.icon)&&(t=Object.assign(Object.assign({},t),{icon:String(e.icon)})),t.value.length&&t.label.length?t:null},us=e=>{let t={select:{options:Array.isArray(e.options)?e.options.every(e=>"string"==typeof e)?e.options:e.options.map(cs).filter(Ze):[]}};return e.translation_key&&(t=Object.assign(Object.assign({},t),{select:Object.assign(Object.assign({},t.select),{translation_key:e.translation_key})})),t},hs=(e,t)=>{if(e.hasOwnProperty("service")&&e.service!==t.service)return!1;const i=e.service_data||{},s=t.service_data||{},a=e.hasOwnProperty("variables")?e.variables||{}:e.hasOwnProperty("fields")&&e.fields||{};let o=[...new Set([...Object.keys(i),...Object.keys(s),...Object.keys(a)])];return o=o.filter(e=>"entity_id"!=e),!!o.every(e=>{var t;if(Object.keys(i).includes(e)&&Object.keys(s).includes(e))return he(i[e],s[e]);if(Object.keys(a).includes(e)){let i=a[e],o=s[e];if(Object.keys(i).includes("options")){let e=us({options:i.options});return!Ze(o)||(null===(t=e.select)||void 0===t?void 0:t.options.find(e=>"string"==typeof e?e==o:e.value==o))}return!Object.keys(i).includes("min")||!Object.keys(i).includes("max")||(!(Ze(o)||!Object.keys(i).includes("optional")||!i.optional)||"number"==typeof o)}return!1})},ms=(e,t)=>{let i=[];return Object.keys(e).filter(t=>{var i;return null===(i=e[t].actions)||void 0===i?void 0:i.length}).filter(i=>!t||!t.includes(".")&&ts(Xi(i),t)||ts(i,t)||t.includes(".")&&e[i].actions.find(e=>e.service==t)).forEach(s=>{Object.values(e[s].actions).forEach(e=>{if(e.service.includes(".")||(e=Object.assign(Object.assign({},e),{service:`${Xi(s)}.${e.service}`})),s.includes(".")&&"script"!=Xi(s)&&(e=Object.assign(Object.assign({},e),{target:{entity_id:s}})),"script"!=Xi(s)&&(!s.includes(".")||"script"==Xi(t||""))){if((null==t?void 0:t.includes("."))&&e.service!=t)return;e=Object.assign(Object.assign({},e),{target:Object.assign(Object.assign({},e.target),{domain:s})})}i.push({service:e.service,service_data:e.service_data||{},target:e.target?e.target:void 0,name:e.name||"",icon:e.icon||"",variables:e.variables})})}),i},ps=(e,t,i)=>{var s,a,o,n;const r=Xi(e.service),d=Qi(e.service);let l,c={};if(Object.keys(ls).includes(r)&&(Object.keys(ls[r]).includes(d)?c=Object.assign(Object.assign({},c),ls[r][d]):Object.keys(ls[r]).includes("{entity_id}")&&(c=Object.assign(Object.assign({},c),ls[r]["{entity_id}"]))),"script"==r&&(null===(o=null===(a=null===(s=null==i?void 0:i.services)||void 0===s?void 0:s[r])||void 0===a?void 0:a[d])||void 0===o?void 0:o.fields)){const e={};Object.keys(i.services[r][d].fields).forEach(t=>{e[t]={optional:!0}}),Object.keys(e).length&&(c=Object.assign(Object.assign({},c),{fields:Object.assign(Object.assign({},c.fields),e)}))}if(!t)return c;l=["script","notify"].includes(r)?e.service:null===(n=e.target)||void 0===n?void 0:n.entity_id,l||(l=e.service);const u=ms(t,[l].flat().pop());if(u.length){let t=u.map(t=>{if(!hs(t,e))return null;let i={};return Object.keys(t.variables||{}).forEach(e=>{i=Object.assign(Object.assign({},i),{fields:Object.assign(Object.assign({},i.fields||{}),{[e]:{}})})}),Object.assign(Object.assign({},i),{name:t.name||c.name,icon:t.icon||c.icon,target:t.target||c.target})}).filter(Ze);const i=Object.values(e.service_data||{}).some(ds);if(t.length&&(i||!hs(c,e)))return t[0]}return c},_s=e=>{const t=Math.pow(10,5);return e=Math.round(e*t)/t},gs=(e,t,i)=>{if(!t)return e;if(Object.keys(t).includes("select")&&t.select){const s=t.select;let a=s.options.map(e=>"string"==typeof e?Object({value:e,label:e}):e),o=null==a?void 0:a.find(t=>t.value==e);s.translation_key?e=ns(s.translation_key.replace("${value}",e),i,!1)||o?null==o?void 0:o.label:e:o&&(e=o.label)}if(Object.keys(t).includes("number")&&t.number){const i=t.number;if(ds(e))return e;if(e=Number(e),"number"==typeof(null==i?void 0:i.scale_factor)&&(e/=i.scale_factor),"number"==typeof(null==i?void 0:i.step)&&(e=Math.round(e/i.step)*i.step),e=_s(e),null==i?void 0:i.unit)return`${e}${i.unit}`}return Object.keys(t).includes("boolean")&&t.boolean&&(e=Boolean(e)?"True":"False"),e},vs=e=>{let t={number:{}};return Object.keys(e).includes("min")&&!isNaN(Number(e.min))&&(t=Object.assign(Object.assign({},t),{number:Object.assign(Object.assign({},t.number),{min:Number(e.min)})})),Object.keys(e).includes("max")&&!isNaN(Number(e.max))&&(t=Object.assign(Object.assign({},t),{number:Object.assign(Object.assign({},t.number),{max:Number(e.max)})})),Object.keys(e).includes("step")&&!isNaN(Number(e.step))&&e.step>0&&(t=Object.assign(Object.assign({},t),{number:Object.assign(Object.assign({},t.number),{step:Number(e.step)})})),Object.keys(e).includes("mode")&&["box","slider"].includes(e.mode)&&(t=Object.assign(Object.assign({},t),{number:Object.assign(Object.assign({},t.number),{mode:e.mode})})),Object.keys(e).includes("unit")&&e.unit&&(t=Object.assign(Object.assign({},t),{number:Object.assign(Object.assign({},t.number),{unit:e.unit})})),Object.keys(e).includes("optional")&&(t=Object.assign(Object.assign({},t),{number:Object.assign(Object.assign({},t.number),{optional:Boolean(e.optional)})})),Object.keys(e).includes("scale_factor")&&!isNaN(Number(e.scale_factor))&&(t=Object.assign(Object.assign({},t),{number:Object.assign(Object.assign({},t.number),{scale_factor:Number(e.scale_factor)})})),t},ys={alarm_control_panel:{services:{alarm_arm_away:"mdi:shield-lock",alarm_arm_home:"mdi:shield-home",alarm_arm_night:"mdi:shield-moon",alarm_custom_bypass:"mdi:security",alarm_disarm:"mdi:shield-off",alarm_trigger:"mdi:bell-ring",alarm_arm_vacation:"mdi:shield-airplane"}},automation:{services:{turn_on:"mdi:robot",turn_off:"mdi:robot-off",trigger:"mdi:play"}},button:{services:{press:"mdi:gesture-tap-button"}},climate:{services:{set_temperature:"mdi:thermometer",set_hvac_mode:"mdi:cog-transfer-outline",set_preset_mode:"mdi:cloud-download-outline",set_fan_mode:"mdi:fan",set_humidity:"mdi:water-percent",set_swing_mode:"mdi:arrow-oscillating"},attributes:{hvac_mode:{auto:"mdi:autorenew",cool:"mdi:snowflake",dry:"mdi:water-percent",fan_only:"mdi:fan",heat:"mdi:fire",heat_cool:"mdi:thermometer",off:"mdi:power"},preset_mode:{activity:"mdi:motion-sensor",away:"mdi:account-arrow-right",boost:"mdi:rocket-launch",comfort:"mdi:sofa",eco:"mdi:leaf",home:"mdi:home",sleep:"mdi:bed"},fan_mode:{diffuse:"mdi:weather-windy",focus:"mdi:target",high:"mdi:speedometer",low:"mdi:speedometer-slow",medium:"mdi:speedometer-medium",middle:"mdi:speedometer-medium",off:"mdi:fan-off",on:"mdi:fan"},swing_mode:{both:"mdi:arrow-all",horizontal:"mdi:arrow-left-right",off:"mdi:arrow-oscillating-off",on:"mdi:arrow-oscillating",vertical:"mdi:arrow-up-down"}}},cover:{services:{close_cover:"mdi:arrow-down-box",close_cover_tilt:"mdi:arrow-bottom-left",open_cover:"mdi:arrow-up-box",open_cover_tilt:"mdi:arrow-top-right",set_cover_position:"mdi:arrow-down-box",set_cover_tilt_position:"mdi:arrow-top-right"}},fan:{services:{oscillate:"mdi:arrow-oscillating",set_percentage:"mdi:fan",set_preset_mode:"mdi:fan-auto",turn_off:"mdi:fan-off",turn_on:"mdi:fan"}},humidifier:{services:{set_humidity:"mdi:water-percent",set_mode:"mdi:air-humidifier",turn_off:"mdi:air-humidifier-off",turn_on:"mdi:air-humidifier"},attributes:{mode:{auto:"mdi:refresh-auto",away:"mdi:account-arrow-right",baby:"mdi:baby-carriage",boost:"mdi:rocket-launch",comfort:"mdi:sofa",eco:"mdi:leaf",home:"mdi:home",normal:"mdi:water-percent",sleep:"mdi:power-sleep"}}},input_boolean:{services:{turn_off:"mdi:toggle-switch-off",turn_on:"mdi:toggle-switch"}},input_button:{services:{press:"mdi:gesture-tap-button"}},input_number:{services:{set_value:"mdi:counter"}},input_select:{services:{select_option:"mdi:counter"}},lawn_mower:{services:{dock:"mdi:home-import-outline",start_mowing:"mdi:play",pause:"mdi:pause"}},light:{services:{turn_off:"mdi:lightbulb-off",turn_on:"mdi:lightbulb-on"}},lock:{services:{lock:"mdi:lock",unlock:"mdi:lock-open"}},media_player:{services:{media_play:"mdi:play",media_stop:"mdi:stop",play_media:"mdi:play",select_source:"mdi:import",turn_off:"mdi:power",turn_on:"mdi:power"}},notify:{services:{"{entity_id}":"mdi:message-alert"}},scene:{services:{turn_on:"mdi:play"}},script:{services:{turn_on:"mdi:flash",turn_off:"mdi:flash-off","{entity_id}":"mdi:play"}},select:{services:{select_option:"mdi:counter"}},switch:{services:{turn_off:"mdi:toggle-switch-variant-off",turn_on:"mdi:toggle-switch-variant"}},vacuum:{services:{send_command:"mdi:send",start:"mdi:play",turn_off:"mdi:stop",turn_on:"mdi:play"}},valve:{services:{open_valve:"mdi:valve-open",close_valve:"mdi:valve-closed",set_valve_position:"mdi:valve"}},water_heater:{services:{set_away_mode:"mdi:account-arrow-right",set_operation_mode:"mdi:water-boiler",set_temperature:"mdi:thermometer",turn_off:"mdi:water-boiler-off",turn_on:"mdi:water-boiler"},attributes:{operation_mode:{eco:"mdi:leaf",electric:"mdi:lightning-bolt",gas:"mdi:fire-circle",heat_pump:"mdi:heat-wave",high_demand:"mdi:finance",off:"mdi:power",performance:"mdi:rocket-launch"}}}},fs=(e,t,i,s,a)=>{const o=Xi(e),n=["script","notify"].includes(o)?[e]:[t||[]].flat();let r=n.map(e=>bs(e,i,s)),d=xs(r),l=n.map(t=>ws(e,t,i,a));return xs(l)||d},bs=(e,t,i)=>{var s,a;const o=Object.keys(i.states).includes(e)?i.states[e]:null,n=(null==o?void 0:o.attributes)||{},r=Xi(e);if("script"==r){const o=Qi(e),n=null===(s=i.services[r])||void 0===s?void 0:s[o],d=null===(a=null==n?void 0:n.fields)||void 0===a?void 0:a[t];return d?(e=>{if(!e||!Object.keys(e).length)return null;const t=Object.keys(e)[0],i=e[t];switch(t){case"number":return vs({min:null==i?void 0:i.min,max:null==i?void 0:i.max,step:null==i?void 0:i.step,mode:null==i?void 0:i.mode,unit:null==i?void 0:i.unit_of_measurement});case"select":return us({options:(null==i?void 0:i.options)||[],translation_key:null==i?void 0:i.translation_key});case"boolean":return{boolean:{}};case"text":return{text:{multiline:null==i?void 0:i.multiline,type:null==i?void 0:i.type}};default:return{text:{}}}})(d.selector):null}const d=`${r}.${t}`,l=e=>{var i,s;const a=null===(s=null===(i=ys[r])||void 0===i?void 0:i.attributes)||void 0===s?void 0:s[t],o=!!a&&(e||[]).every(e=>e in a);return(e||[]).map(e=>({value:e,label:e,icon:o?a[e]:void 0}))};switch(d){case"climate.temperature":case"climate.target_temp_low":case"climate.target_temp_high":{const e="climate.temperature"==d?(2&(n.supported_features||0))>0:(1&(n.supported_features||0))>0,t=i.config.unit_system.temperature.includes("F")?1:.5;return vs({min:n.min_temp,max:n.max_temp,step:n.target_temp_step||t,unit:`${i.config.unit_system.temperature}`,optional:e})}case"climate.hvac_mode":return us({options:l(n.hvac_modes),translation_key:"component.climate.entity_component._.state.${value}"});case"climate.preset_mode":return us({options:l(n.preset_modes),translation_key:"state_attributes.climate.preset_mode.${value}"});case"climate.fan_mode":return us({options:l(n.fan_modes)});case"climate.swing_mode":return us({options:l(n.swing_modes)});case"cover.position":case"cover.tilt_position":case"fan.percentage":case"valve.position":return vs({min:0,max:100,step:1,unit:"%"});case"fan.oscillating":case"water_heater.away_mode":return{boolean:{}};case"fan.direction":return us({options:l(["forward","reverse"]),translation_key:"ui.card.fan.${value}"});case"fan.preset_mode":return us({options:l(n.preset_modes)});case"humidifier.humidity":return vs({min:n.min_humidity,max:n.max_humidity,step:1,unit:"%"});case"humidifier.mode":return us({options:l(n.available_modes),translation_key:"component.humidifier.entity_component._.state_attributes.mode.state.${value}"});case"input_number.value":case"number.value":return vs({min:n.min,max:n.max,step:n.step,mode:n.mode,unit:n.unit_of_measurement});case"input_select.option":case"select.option":return us({options:l(n.options)});case"light.brightness":return vs({min:0,max:100,step:1,unit:"%",scale_factor:2.55});case"media_player.source":case"notify.title":case"notify.message":return{text:{}};case"water_heater.temperature":{const e=i.config.unit_system.temperature.includes("F")?1:.5;return vs({min:n.min_temp,max:n.max_temp,step:n.target_temp_step||e,unit:`${i.config.unit_system.temperature}`})}case"water_heater.operation_mode":return us({options:l(n.operation_list)})}return null},ws=(e,t,i,s)=>{const a=ms(s||{},t);if(a.length){let t=a.map(t=>{if(t.service!=e||!Object.keys(t.variables||{}).includes(i))return null;let s=(t.variables||{})[i];return ks(s)}).filter(e=>void 0!==e);return xs(t)}return null},ks=e=>Object.keys(e).includes("options")?us({options:e.options}):Object.keys(e).includes("min")&&Object.keys(e).includes("max")?vs(e):{text:{}},xs=e=>{const t=e=>1==new Set(e).size;if(e.some(e=>null===e)||!e.length)return null;if(e.every(e=>e.hasOwnProperty("select"))){const i=e.map(e=>e.select.options).filter(e=>void 0!==e);let s=[];if(i.every(e=>e.every(e=>"string"==typeof e)))s=i.length?i.reduce((e,t)=>e.filter(e=>t.includes(e))):[];else{let e=i.map(e=>e.map(e=>cs("object"==typeof e?e:{value:e})).filter(Ze));s=e.length?e.reduce((e,t)=>e.filter(e=>t.find(t=>t.value===e.value))):[]}const a=e.map(e=>e.select.translation_key).filter(e=>void 0!==e);return{select:{options:s.length?s:[],translation_key:a.length&&t(a)?a[0]:void 0}}}if(e.every(e=>e.hasOwnProperty("number"))){const i=e.map(e=>e.number.min).filter(e=>void 0!==e),s=e.map(e=>e.number.max).filter(e=>void 0!==e),a=e.map(e=>e.number.step).filter(e=>void 0!==e),o=e.map(e=>e.number.mode).filter(e=>void 0!==e),n=e.map(e=>e.number.unit).filter(e=>void 0!==e),r=e.map(e=>e.number.optional),d=e.map(e=>e.number.scale_factor).filter(e=>void 0!==e);let l={number:{min:i.length?Math.max(...i):void 0,max:s.length?Math.min(...s):void 0,step:a.length?Math.max(...a):void 0,mode:o.length&&t(o)?o[0]:void 0,unit:n.length&&t(n)?n[0]:void 0,optional:r.every(e=>e),scale_factor:d.length&&t(d)?d[0]:void 0}};return l}return e.every(e=>e.hasOwnProperty("boolean"))?{boolean:{}}:e.every(e=>e.hasOwnProperty("text"))?{text:{}}:null},$s=/\[([^\]]+)\]/,js=/\{([^\}]+)\}/,Os=(e,t)=>{const i=Qi(t.service);return-1!=e.indexOf(i)&&(e=e.substring(e.indexOf(i)+i.length+1)),Object.keys(t.service_data).reduce((i,s)=>{if(-1==e.indexOf(s))return i;let a=e.substring(e.indexOf(s)+s.length+1);return a==t.service_data[s]?i+e.length+a.length+1:i},0)},Ss=(e,t,i,s=!1,a=!1)=>{const o=ps(e,i,t);let n,r=o.name||"",d=Object.fromEntries(Object.entries(e.service_data).filter(([e,t])=>Ze(t)).map(([s,a])=>{var o;const n=fs(e.service,null===(o=e.target)||void 0===o?void 0:o.entity_id,s,t,i);return n?[s,gs(a,n,t)]:[s,null]}).filter(([e,t])=>Ze(t)));if(s){if(r&&Object.values(e.service_data).some(ds))return r;if(Object.keys(d).length>1){const e=(e,t)=>{const i=!!o.fields&&o.fields[e]||{},s=!!o.fields&&o.fields[t]||{};return(null==i?void 0:i.optional)&&!s.optional?1:(null==s?void 0:s.optional)&&!i.optional||e<t?-1:e>t?1:0};return d=Object.fromEntries(Object.entries(d).sort(([t],[i])=>e(t,i))),Object.values(d).join(", ")}if(Object.keys(d).length)return Object.values(d)[0]}if((null==o?void 0:o.translation_key)&&!r){let i="";if(Array.isArray(o.translation_key)){let t=o.translation_key;t.sort((t,i)=>{let s=Os(t,e),a=Os(i,e);return s!=a?a-s:t.length-i.length}),i=t[0]}else i=o.translation_key;r=Ji(i,t,Object.keys(d).map(e=>`{${e}}`),Object.values(d))}else{const i=Xi(e.service),s=Qi(e.service);r||(r=ns(`component.${i}.services.${s}.name`,t,!1)),!r&&Object.keys(t.services[i]||{}).includes(s)&&(r=t.services[i][s].name||""),r||(r=s.replace(/_/g," "))}let l,c=0;for(;(n=$s.exec(r))&&c<100;){c++;let t=n[1].match(js);r=t&&Object.keys(e.service_data||{}).includes(t[1])&&Object.keys(d).includes(t[1])?r.replace(n[0],n[1].replace(t[0],d[t[1]])):r.replace(n[0],"")}for(c=0;(l=js.exec(r))&&c<100;)c++,r=Object.keys(d).includes(l[1])?r.replace(l[0],d[l[1]]):r.replace(l[0],"");if(a&&null!==/<.+?>/g.exec(r)){r=(new DOMParser).parseFromString(r,"text/html").body.textContent||""}return r},zs=e=>{var t,i;return(null===(t=e.locale)||void 0===t?void 0:t.time_zone)===De.server&&(null===(i=e.config)||void 0===i?void 0:i.time_zone)?e.config.time_zone:void 0},Cs=(e,t)=>{const i=new Intl.DateTimeFormat("en-US",{timeZone:t,year:"numeric",month:"numeric",day:"numeric",hour:"numeric",minute:"numeric",hourCycle:"h23"}).formatToParts(e),s=e=>Number(i.find(t=>t.type==e).value);return{year:s("year"),month:s("month"),day:s("day"),hours:s("hour"),minutes:s("minute")}},As=()=>{try{(new Date).toLocaleDateString("i")}catch(e){return"RangeError"===e.name}return!1},Es=["sunday","monday","tuesday","wednesday","thursday","friday","saturday"],Ts=(e,t,i)=>{let s;if(e instanceof Date){if(e.getDay(),s=pe.Friday,As())return e.toLocaleDateString(i.locale.language,{weekday:t,timeZone:zs(i)});e.getDay(),s=pe.Friday}else s=e;switch(s){case pe.Daily:return Ji(`ui.components.date.day_types_${t}.daily`,i);case pe.Workday:return Ji(`ui.components.date.day_types_${t}.workdays`,i);case pe.Weekend:return Ji(`ui.components.date.day_types_${t}.weekend`,i);case pe.Monday:case pe.Tuesday:case pe.Wednesday:case pe.Thursday:case pe.Friday:case pe.Saturday:case pe.Sunday:let e=new Date(2017,1,26),a=Es.findIndex(e=>e==s);return As()?(e.setDate(e.getDate()+a),e.toLocaleDateString(i.locale.language,{weekday:t})):Es[a];default:return""}},Ds=e=>{const t=e.locale.first_weekday;if(t&&"language"!=t)return Ms.map(e=>e.toLowerCase()).findIndex(e=>e==t);if("weekInfo"in Intl.Locale.prototype)return new Intl.Locale(e.locale.language).weekInfo.firstDay%7;{const t="AEAFBHDJDZEGIQIRJOKWLYOMQASDSY".match(/../g),i="AGARASAUBDBRBSBTBWBZCACNCODMDOETGTGUHKHNIDILINJMJPKEKHKRLAMHMMMOMTMXMZNINPPAPEPHPKPRPTPYSASGSVTHTTTWUMUSVEVIWSYEZAZW".match(/../g),s=["ar","arq","arz","fa"],a="amasbndzengnguhehiidjajvkmknkolomhmlmrmtmyneomorpapssdsmsnsutatethtnurzhzu".match(/../g),o=e.locale.language.match(/^([a-z]{2,3})(?:-([a-z]{3})(?=$|-))?(?:-([a-z]{4})(?=$|-))?(?:-([a-z]{2}|\d{3})(?=$|-))?/i);return o[1]?i.includes(o[4])?0:t.includes(o[4])?6:1:a.includes(o[1])?0:s.includes(o[1])?6:1}},Ms=[pe.Sunday,pe.Monday,pe.Tuesday,pe.Wednesday,pe.Thursday,pe.Friday,pe.Saturday],Ls=(e,t,i)=>{let s="";const a=Ds(i),o=((e,t)=>e.concat(e).slice(t,t+e.length))(Ms,a);e.sort((e,t)=>{const i=o.findIndex(t=>t==e),s=o.findIndex(e=>e==t);return i-s});const n=e.filter(e=>o.includes(e)).map(e=>o.findIndex(t=>t==e)),r=(e=>{const t=[];for(let i=0;i<e.length-1;i++){let s=i+1;for(;e[s]-e[s-1]==1;)s++;t.push(s-i)}return t})(n),d=Math.max(...r);if(n.length){if(e.length>n.length&&(s+=e.filter(e=>!o.includes(e)).map(e=>Ts(e,t,i)).join(", "),s+=", "),6==n.length){const e=[0,1,2,3,4,5,6].filter(e=>!n.includes(e)),a=Ts(o[e.pop()],t,i);s+=Ji("ui.components.date.repeated_days_except",i,"{excludedDays}",a)}else{const e=n.map(e=>Ts(o[e],t,i));if(n.length>=3&&d>=3){const t=r.reduce((e,t,i)=>t==d?i:e,0);e.splice(t,d,Ji("ui.components.date.days_range",i,["{startDay}","{endDay}"],[e[t],e[t+d-1]]))}const a=e.length>1?`${e.slice(0,-1).join(", ")} ${ns("ui.common.and",i)} ${e.pop()}`:`${e.pop()}`;s+=n.length>=3&&d>=3?a:Ji("ui.components.date.repeated_days",i,"{days}",a)}return s}return e.map(e=>Ts(e,t,i)).join(", ")},Ns=(e,t,i)=>{const s=Object.entries(i||{}).filter(([t,i])=>ts(t,e)&&i.name).map(([e,t])=>t.name),a=t.states[e],o=s.filter(Ze)[0];if(void 0!==o){const e=Yi(t,a,o);if(e)return e}const n=Yi(t,a,void 0);return n||Qi(e).replace(/_/g," ")},Ps=(e,t,i,s)=>{const a=t=>{var o,n;switch(t){case ve.Action:const r=e.entries[0].slots[e.next_entries[0]||0].actions[0];return os(Ss(r,i,s));case ve.Days:return os(Ls(e.entries[0].weekdays,"long",i));case ve.Name:return os(e.name||"");case ve.AdditionalTasks:return e.entries[0].slots.length>1?"+"+Ji("ui.panel.overview.additional_tasks",i,"{number}",String(e.entries[0].slots.length-1)):"";case ve.Entity:const d=e.entries[0].slots[e.next_entries[0]||0].actions[0];let l=[(null===(o=d.target)||void 0===o?void 0:o.entity_id)||[]].flat();!l.length&&["script","notify"].includes(Xi(d.service))&&(l=[d.service]);const c=l.map(e=>Ns(e,i,s)).join(", ");return os(c);case ve.RelativeTime:return"<relative-time></relative-time>";case ve.Tags:return null===(n=e.tags)||void 0===n?void 0:n.map(e=>`<tag>${e}</tag>`).join("");case ve.Time:const u=e.entries[0].slots[e.next_entries[0]||0],h=((e,t,i)=>{const s=Me(i.locale);if(t){const a=Ce(e),o=Ce(t),n=a.mode==be.Fixed?Ie(a,{am_pm:s}):rs(a,i),r=o.mode==be.Fixed?Ie(o,{am_pm:s}):rs(o,i);return os(Ji("ui.components.time.interval",i,["{startTime}","{endTime}"],[n,r]))}{const t=Ce(e),a=t.mode==be.Fixed?Ji("ui.components.time.absolute",i,"{time}",Ie(t,{am_pm:s})):rs(t,i);return os(a)}})(u.start,u.stop,i);if(h&&h.trim())return os(h);const m=e=>{try{const t=e.split(":").map(Number);return`${String(t[0]).padStart(2,"0")}:${String(t[1]).padStart(2,"0")}`}catch(t){return String(e)}};return os(u.stop?`${m(u.start)} - ${m(u.stop)}`:`${m(u.start)}`);case ve.Default:const p=a(ve.Name);return p||`${a(ve.Entity)}: ${a(ve.Action)}`;default:const _=/\{([^\}]+)\}/;let g;for(;g=_.exec(t);)t=t.replace(g[0],String(a(String(g[1]))));return t}};return[...[t].flat()].map(e=>{let t=a(e);return t||""})},Is=(e,t)=>{const i=new Date(e.timestamps[e.next_entries[0]]).valueOf(),s=new Date(t.timestamps[t.next_entries[0]]).valueOf(),a=(new Date).valueOf(),o=i<a&&s<a;return null!==i&&null!==s?i<a&&s>=a?1:i>=a&&s<a?-1:i>s?o?-1:1:i<s?o?1:-1:e.entity_id<t.entity_id?1:-1:null!==s?1:null!==i?-1:e.entity_id<t.entity_id?1:-1},qs=(e,t,i)=>{const s=[t.sort_by].flat();return s.includes("relative-time")&&(e=e.sort(Is)),s.includes("title")&&(e=e.sort((e,s)=>{var a;return((e,t,i,s,a)=>{try{const o=Ps(e,i,s,a).join(),n=Ps(t,i,s,a).join();return as(o,n)}catch(e){return 0}})(e,s,(null===(a=t.display_options)||void 0===a?void 0:a.primary_info)||Ve,i,t.customize)})),s.includes("state")&&(e=e.sort((e,t)=>((e,t,i,s)=>{var a,o;const n=null===(a=i.states[e.entity_id])||void 0===a?void 0:a.state,r=null===(o=i.states[t.entity_id])||void 0===o?void 0:o.state,d=["on","triggered"].includes(n),l=["on","triggered"].includes(r);if(d&&!l)return-1;if(!d&&l)return 1;if(s){if("off"!=n&&"off"==r)return 1;if("off"==n&&"off"!=r)return-1}return 0})(e,t,i,s.includes("relative-time")))),e},Rs=(e,t)=>e.callWS({type:"scheduler/item",schedule_id:t}).then(e=>$e(e)),Vs=(e,t,i,s)=>{s=s||{},i=null==i?{}:i;const a=new Event(t,{bubbles:void 0===s.bubbles||s.bubbles,cancelable:Boolean(s.cancelable),composed:void 0===s.composed||s.composed});return a.detail=i,e.dispatchEvent(a),a},Hs=async e=>{let t={};const i=Object.keys(e.states).filter(e=>"script"==Xi(e));return i.length&&await e.callWS({type:"config/entity_registry/get_entries",entity_ids:i}).then(e=>{t=Object.fromEntries(Object.entries(e).map(([,e])=>(e=>{let t={};const i=`${e.platform}.${e.unique_id}`;return e.name&&(t=Object.assign(Object.assign({},t),{name:e.name})),e.icon&&(t=Object.assign(Object.assign({},t),{icon:e.icon})),[i,t]})(e)).filter(([,e])=>Object.keys(e).length))}),t},Us=e=>e.callWS({type:"scheduler/tags"});var Fs="M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z",Bs="M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z",Ws="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",Zs="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z",Ks="M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z",Gs="M11,13.5V21.5H3V13.5H11M12,2L17.5,11H6.5L12,2M17.5,13C20,13 22,15 22,17.5C22,20 20,22 17.5,22C15,22 13,20 13,17.5C13,15 15,13 17.5,13Z";const Js={alarm_control_panel:"mdi:alarm-light-outline",air_quality:"mdi:air-filter",alert:"mdi:alert",automation:"mdi:robot",binary_sensor:"mdi:radiobox-blank",button:"mdi:gesture-tap-button",camera:"mdi:camera",calendar:"mdi:calendar",cover:"mdi:window-shutter",climate:"mdi:thermostat",configurator:"mdi:cog",conversation:"mdi:microphone-message",counter:"mdi:counter",date:"mdi:calendar",datetime:"mdi:calendar-clock",demo:"mdi:home-assistant",device_tracker:"mdi:account",fan:"mdi:fan",google_assistant:"mdi:google-assistant",group:"mdi:google-circles-communities",homeassistant:"mdi:home-assistant",homekit:"mdi:home-automation",humidifier:"mdi:air-humidifier",image_processing:"mdi:image-filter-frames",image:"mdi:image",input_boolean:"mdi:toggle-switch",input_button:"mdi:button-pointer",input_datetime:"mdi:calendar-clock",input_number:"mdi:ray-vertex",input_select:"mdi:format-list-bulleted",input_text:"mdi:form-textbox",lawn_mower:"mdi:robot-mower",light:"mdi:lightbulb",lock:"mdi:lock-open-outline",media_player:"mdi:cast-connected",mailbox:"mdi:mailbox",notify:"mdi:comment-alert",number:"mdi:ray-vertex",persistent_notification:"mdi-bell",person:"mdi:account",plant:"mdi:flower",proximity:"mdi:apple-safari",remote:"mdi:remote",scene:"mdi:palette",schedule:"mdi:calendar-clock",script:"mdi:script-text",select:"mdi:format-list-bulleted",sensor:"mdi:eye",simple_alarm:"mdi:bell",siren:"mdi:bullhorn",stt:"mdi:microphone-message",sun:"mdi:white-balance-sunny",switch:"mdi:flash",text:"mdi:form-textbox",time:"mdi:clock",timer:"mdi:timer-outline",todo:"mdi:clipboard-list",tts:"mdi:speaker-message",vacuum:"mdi:robot-vacuum",valve:"mdi:valve-closed",wake_word:"mdi:chat-sleep",water_heater:"mdi:water-boiler",weather:"mdi:weather-partly-cloudy",zone:"mdi:map-marker-radius"},Ys=e=>Object.keys(Js).includes(e)?Js[e]:"mdi:help",Qs=(e,t)=>{let i=Object.keys(e.services).filter(e=>((e,t)=>{let i=Object.keys(ls).includes(e);return!i&&t?Object.keys(t).map(Xi).includes(e):i})(e,t.customize));i=i.filter(e=>is(e,t));let s=i.map(t=>({key:t,name:ns(`component.${t}.title`,e,!1)||t.replace(/_/g," "),description:"",icon:Ys(t)}));return s},Xs=1,ea=2,ta=e=>(...t)=>({_$litDirective$:e,values:t});let ia=class{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,i){this._$Ct=e,this._$AM=t,this._$Ci=i}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}};
/**
     * @license
     * Copyright 2018 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */const sa="important",aa=" !"+sa,oa=ta(class extends ia{constructor(e){var t;if(super(e),e.type!==Xs||"style"!==e.name||(null===(t=e.strings)||void 0===t?void 0:t.length)>2)throw Error("The `styleMap` directive must be used in the `style` attribute and must be the only part in the attribute.")}render(e){return Object.keys(e).reduce((t,i)=>{const s=e[i];return null==s?t:t+`${i=i.includes("-")?i:i.replace(/(?:^(webkit|moz|ms|o)|)(?=[A-Z])/g,"-$&").toLowerCase()}:${s};`},"")}update(e,[t]){const{style:i}=e.element;if(void 0===this.ht){this.ht=new Set;for(const e in t)this.ht.add(e);return this.render(t)}this.ht.forEach(e=>{null==t[e]&&(this.ht.delete(e),e.includes("-")?i.removeProperty(e):i[e]="")});for(const e in t){const s=t[e];if(null!=s){this.ht.add(e);const t="string"==typeof s&&s.endsWith(aa);e.includes("-")||t?i.setProperty(e,t?s.slice(0,-11):s,t?sa:""):i[e]=s}}return R}}),na={alarm_control_panel:{disarmed:"mdi:lock-open-variant-outline",armed_away:"mdi:exit-run",armed_home:"mdi:home-outline",armed_night:"mdi:power-sleep",armed_custom_bypass:"mdi:security",armed_vacation:"mdi:shield-airplane",triggered:"mdi:alarm-light-outline"},binary_sensor:{battery:{on:"mdi:battery-outline",off:"mdi:battery"},battery_charging:{on:"mdi:battery-charging",off:"mdi:battery"},cold:{on:"mdi:snowflake",off:"mdi:thermometer"},connectivity:{on:"mdi:server-network",off:"mdi:server-network-off"},door:{on:"mdi:door-open",off:"mdi:door-closed"},garage_door:{on:"mdi:garage-open",off:"mdi:garage"},power:{on:"mdi:power-plug",off:"mdi:power-plug-off"},gas:{on:"mdi:alert-circle",off:"mdi:check-circle"},problem:{on:"mdi:alert-circle",off:"mdi:check-circle"},safety:{on:"mdi:alert-circle",off:"mdi:check-circle"},tamper:{on:"mdi:alert-circle",off:"mdi:check-circle"},smoke:{on:"mdi:smoke",off:"mdi:check-circle"},heat:{on:"mdi:fire",off:"mdi:thermometer"},light:{on:"mdi:brightness-7",off:"mdi:brightness-5"},lock:{on:"mdi:lock-open",off:"mdi:lock"},moisture:{on:"mdi:water",off:"mdi:water-off"},motion:{on:"mdi:run",off:"mdi:walk"},occupancy:{on:"mdi:home",off:"mdi:home-outline"},opening:{on:"mdi:square-outline",off:"mdi:square"},plug:{on:"mdi:power-plug",off:"mdi:power-plug-off"},presence:{on:"mdi:home",off:"mdi:home-outline"},running:{on:"mdi:play",off:"mdi:stop"},sound:{on:"mdi:music-note",off:"mdi:music-note-off"},update:{on:"mdi:package-up",off:"mdi:package"},vibration:{on:"mdi:vibrate",off:"mdi:crop-portrait"},window:{on:"mdi:window-open",off:"mdi:window-closed"},_:{on:"mdi:checkbox-marked-circle",off:"mdi:radiobox-blank"}},calendar:{on:"mdi:flash",off:"mdi:flash-off"},cover:{garage:{closed:"mdi:garage",open:"mdi:garage-open"},door:{closed:"mdi:door-closed",open:"mdi:door-open"},blind:{closed:"mdi:blinds",open:"mdi:blinds-open"},window:{closed:"mdi:window-closed",open:"mdi:window-open"},_:{closed:"mdi:window-shutter",open:"mdi:window-shutter-open"}},climate:{off:"mdi:power-off",heat:"mdi:fire",cool:"mdi:snowflake",heat_cool:"mdi:thermometer",auto:"mdi:autorenew",dry:"mdi:water-percent",fan_only:"mdi:fan"},device_tracker:{home:"mdi:home-outline",not_home:"mdi:exit-run"},fan:{on:"mdi:power",off:"mdi:power-off"},humidifier:{on:"mdi:power",off:"mdi:power-off"},input_boolean:{on:"mdi:flash",off:"mdi:flash-off"},light:{on:"mdi:lightbulb",off:"mdi:lightbulb-off"},lawn_mower:{mowing:"mdi:play",paused:"mdi:pause",docked:"mdi:home-import-outline"},lock:{unlocked:"mdi:lock-open-variant-outline",locked:"mdi:lock-outline"},person:{home:"mdi:home-outline",not_home:"mdi:exit-run"},sun:{below_horizon:"mdi:weather-sunny-off",above_horizon:"mdi:weather-sunny"},switch:{on:"mdi:flash",off:"mdi:flash-off"},timer:{active:"mdi:play",paused:"mdi:pause",idle:"mdi:sleep"},valve:{open:"mdi:valve-open",closed:"mdi:valve-closed"},weather:{"clear-night":"mdi:weather-night",cloudy:"mdi:weather-cloudy",exceptional:"mdi:alert-circle-outline",fog:"mdi:weather-fog",hail:"mdi:weather-hail",lightning:"mdi:weather-lightning","lightning-rainy":"mdi:weather-lightning-rainy",partlycloudy:"mdi:weather-partly-cloudy",pouring:"mdi:weather-pouring",rainy:"mdi:weather-rainy",snowy:"mdi:weather-snowy","snowy-rainy":"mdi:weather-snowy-rainy",sunny:"mdi:weather-sunny",windy:"mdi:weather-windy","windy-variant":"mdi:weather-windy-variant"},water_heater:{off:"mdi:power-off",eco:"mdi:leaf",electric:"mdi:lightning-bolt",gas:"mdi:fire",heat_pump:"mdi:hvac",high_demand:"mdi:water-plus-outline",performance:"mdi:rocket-launch-outline"}},ra=(e,t,i)=>{const s=Xi(e);if(!Object.keys(na).includes(s))return;let a=na[s];if("object"==typeof Object.values(a)[0]){const t=i.states[e],s=null==t?void 0:t.attributes.device_class;a=s&&Object.keys(a).includes(s)?a[s]:a._}return Object.keys(a).includes(t)?a[t]:void 0},da=["alarm_control_panel","binary_sensor","climate","calendar","cover","device_tracker","fan","humidifier","input_boolean","input_number","input_select","lawn_mower","light","lock","number","person","proximity","select","sensor","sun","switch","timer","valve","weather","water_heater"],la=["clear-night","cloudy","exceptional","fog","hail","lightning","lightning-rainy","partlycloudy","pouring","rainy","snowy","snowy-rainy","sunny","windy","windy-variant"],ca=(e,t,i)=>{let s=((e,t)=>{const i=Object.keys(t.states).includes(e)?t.states[e]:void 0,s=Xi(e),a=(null==i?void 0:i.attributes)||{},o=i=>null==i?void 0:i.map(i=>Object({value:i,icon:ra(e,i,t)}));switch(s){case"alarm_control_panel":let e=["disarmed","triggered"];return 2&(a.supported_features||0)&&(e=[...e,"armed_away"]),1&(a.supported_features||0)&&(e=[...e,"armed_home"]),4&(a.supported_features||0)&&(e=[...e,"armed_night"]),16&(a.supported_features||0)&&(e=[...e,"armed_custom_bypass"]),32&(a.supported_features||0)&&(e=[...e,"armed_vacation"]),us({options:o(e),translation_key:"component.alarm_control_panel.entity_component._.state.${value}"});case"binary_sensor":return us({options:o(["on","off"]),translation_key:"component.binary_sensor.entity_component.${deviceClass}.state.${value}"});case"climate":return us({options:o(a.hvac_modes),translation_key:"component.climate.entity_component._.state.${value}"});case"calendar":case"fan":case"humidifier":case"input_boolean":case"light":case"switch":return us({options:o(["on","off"]),translation_key:"component.switch.entity_component._.state.${value}"});case"cover":return us({options:o(["open","closed"]),translation_key:"component.cover.entity_component._.state.${value}"});case"device_tracker":return us({options:o(["home","not_home"]),translation_key:"component.device_tracker.entity_component._.state.${value}"});case"input_number":case"number":return vs({min:a.min,max:a.max,step:a.step,mode:a.mode,unit:a.unit_of_measurement});case"input_select":case"select":return us({options:a.options});case"lawn_mower":return us({options:o(["mowing","paused","docked"]),translation_key:"component.lawn_mower.entity_component._.state.${value}"});case"lock":return us({options:o(["locked","unlocked"]),translation_key:"component.lock.entity_component._.state.${value}"});case"person":const s=Object.keys(t.states).filter(e=>"zone"==Xi(e)).map(Qi);return us({options:[...new Set(["home","not_home",...s])]});case"proximity":return vs({mode:"box",unit:a.unit_of_measurement});case"sensor":return!isNaN(Number(null==i?void 0:i.state))||Ze(a.unit_of_measurement)?vs({mode:"box",unit:a.unit_of_measurement,min:"%"==a.unit_of_measurement?0:void 0,max:"%"==a.unit_of_measurement?100:void 0}):{text:{}};case"sun":return us({options:o(["above_horizon","below_horizon"]),translation_key:"component.sun.entity_component._.state.${value}"});case"timer":return us({options:o(["active","paused","idle"]),translation_key:"component.timer.entity_component._.state.${value}"});case"valve":return us({options:o(["open","closed"]),translation_key:"component.valve.entity_component._.state.${value}"});case"weather":return us({options:o(la),translation_key:"component.weather.entity_component._.state.${value}"});case"water_heater":case"climate":return us({options:o(a.operation_list),translation_key:"component.climate.entity_component._.state.${value}"});default:return{text:{}}}})(e,t);const a=Object.keys(i||{}).filter(t=>ts(t,Xi(e))||ts(t,e)).filter(e=>Object.keys(i[e]).includes("states")).sort((e,t)=>e.length-t.length).map(e=>i[e].states).shift();return a&&(Array.isArray(a)?s=us({options:a}):"object"==typeof a&&"min"in a&&"max"in a&&(s=vs(a))),s},ua=(e,t)=>{let i=Object.keys(e.states).map(e=>Xi(e)).reduce((e,t)=>e.includes(t)?e:[...e,t],[]).filter(e=>((e,t)=>{const i=da.includes(e);return!i&&t?Object.keys(t).map(Xi).includes(e):i})(e,t.customize||{}));i=i.filter(e=>is(e,t));const s=i.map(t=>({key:t,name:ns(`component.${t}.title`,e,!1)||t.replace(/_/g," "),description:"",icon:Ys(t)}));return s},ha=(e,t,i)=>{let s=Object.entries(t||{}).filter(([t,i])=>ts(t,e)&&i.icon).map(([e,t])=>t);if(s.length)return s.map(e=>{return(t=e.icon).match(/^[a-z]+\:[a-zA-Z\-]+$/)?t:`mdi:${t}`;var t}).shift();if(!Object.keys(i.states).includes(e))return"mdi:help";const a=i.states[e];if(a.attributes.icon)return a.attributes.icon;const o=Xi(e);return Ys(o)};let ma=class extends oe{constructor(){super(...arguments),this.twoline=!1,this.hasMeta=!1,this.disabled=!1,this.noninteractive=!1}connectedCallback(){super.connectedCallback(),this.hasAttribute("role")||this.setAttribute("role","listitem"),this.addEventListener("keydown",this._handleKeydown)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("keydown",this._handleKeydown)}updated(e){(e.has("disabled")||e.has("noninteractive"))&&(this.disabled||this.noninteractive?this.removeAttribute("tabindex"):this.setAttribute("tabindex","0"),this.setAttribute("aria-disabled",String(this.disabled)))}_handleKeydown(e){e.target!==this||this.disabled||this.noninteractive||"Enter"!==e.key&&" "!==e.key||(e.preventDefault(),this.click())}render(){return q`
      ${this.graphic?q`<span class="graphic"><slot name="graphic"></slot></span>`:""}
      <span class="text">
        ${this.twoline?q`
                <span class="primary">
                  <slot></slot>
                </span>
                <span class="secondary">
                  <slot name="secondary"></slot>
                </span>
              `:q`<slot></slot>`}
      </span>
      ${this.hasMeta?q`<span class="meta"><slot name="meta"></slot></span>`:""}
    `}};ma.styles=r`
    :host {
      display: flex;
      position: relative;
      align-items: center;
      box-sizing: border-box;
      height: 48px;
      padding: 0px var(--scheduler-list-side-padding, 20px);
      overflow: hidden;
      outline: none;
      cursor: pointer;
      -webkit-tap-highlight-color: transparent;
      font-family: var(--ha-font-family-body, Roboto, sans-serif);
      font-size: var(--ha-font-size-m, 14px);
      font-weight: var(--ha-font-weight-normal, 400);
      line-height: 1.5;
      letter-spacing: 0.009375em;
      color: var(--primary-text-color);
    }
    :host([twoline]) {
      height: 72px;
    }
    :host::before {
      content: '';
      position: absolute;
      inset: 0;
      background: var(--primary-text-color);
      opacity: 0;
      pointer-events: none;
      transition: opacity 15ms linear;
    }
    :host(:hover)::before {
      opacity: 0.04;
    }
    :host(:focus-visible)::before,
    :host(:active)::before {
      opacity: 0.12;
    }
    :host([disabled]),
    :host([noninteractive]) {
      cursor: default;
    }
    :host([disabled]) {
      color: var(--disabled-text-color);
      pointer-events: none;
    }
    :host([disabled])::before,
    :host([noninteractive])::before {
      display: none;
    }
    .graphic {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      width: 24px;
      height: 24px;
      line-height: 24px;
      margin-inline-end: 20px;
      color: var(--secondary-text-color);
    }
    :host([twoline]) .graphic {
      margin-inline-end: 16px;
    }
    .text {
      flex: 1;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    :host([twoline]) .text {
      align-self: flex-start;
    }
    /* Baselines at 32px and 52px from the top, as in Material's two-line list */
    .primary,
    .secondary {
      display: block;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      line-height: normal;
    }
    .primary {
      margin-bottom: -20px;
    }
    .primary::before,
    .primary::after,
    .secondary::before {
      content: '';
      display: inline-block;
      width: 0;
    }
    .primary::before {
      height: 32px;
    }
    .primary::after {
      height: 20px;
      vertical-align: -20px;
    }
    .secondary {
      font-size: 0.875em;
      letter-spacing: 0.0178571429em;
      color: var(--secondary-text-color);
    }
    .secondary::before {
      height: 20px;
    }
    .meta {
      display: inline-flex;
      align-items: center;
      justify-content: flex-end;
      flex-shrink: 0;
      width: var(--scheduler-list-item-meta-size, auto);
      margin-inline-start: auto;
      color: var(--secondary-text-color);
    }
  `,t([le({reflect:!0})],ma.prototype,"graphic",void 0),t([le({type:Boolean,reflect:!0})],ma.prototype,"twoline",void 0),t([le({type:Boolean,reflect:!0})],ma.prototype,"hasMeta",void 0),t([le({type:Boolean,reflect:!0})],ma.prototype,"disabled",void 0),t([le({type:Boolean,reflect:!0})],ma.prototype,"noninteractive",void 0),ma=t([re("scheduler-list-item")],ma);const pa=(e,t,i)=>{if(["script","notify"].includes(e)){let s=Object.keys(i.services[e]);"script"==e&&(s=s.filter(e=>!["turn_on","turn_off","reload","toggle","test"].includes(e)));const a=s.map(s=>({key:`${e}.${s}`,name:Ns(`${e}.${s}`,i,t),description:"",icon:ha(`${e}.${s}`,t,i)}));return a.sort((e,t)=>as(e.name,t.name)),a}{const s=Object.keys(i.states).filter(t=>Xi(t)==e),a=s.map(e=>({key:e,name:es(i,e),description:"",icon:ha(e,t,i)}));return a.sort((e,t)=>as(e.name,t.name)),a}},_a=(e,t)=>t.every(t=>e.name.toLowerCase().includes(t))||t.every(t=>e.key.toLowerCase().includes(t));let ga=class extends oe{constructor(){super(...arguments),this._search="",this._filter="",this.timer=0,this.expandedGroups=[],this.scheduleEntities=[]}async showDialog(e){this._params=e,this.loadOptions(),await this.updateComplete}async closeDialog(){this._params&&this._params.confirm({domains:this._params.domains,entities:this._params.entities}),this._params=void 0,this._clearSearch(),this._height=void 0,this._width=void 0}loadOptions(){if(!this._params)return;const e=(e=>{let t=Qs(e,{include:["*"]}),i=ua(e,{include:["*"]});return i=i.filter(e=>!t.map(e=>e.key).includes(e.key)),t=[...t,...i],t.sort((e,t)=>as(e.name,t.name)),t})(this.hass);this.options=e.map(e=>Object.assign(Object.assign({},e),{entities:pa(e.key,this._params.cardConfig.customize,this.hass)})).filter(e=>e.entities.length)}shouldUpdate(e){return!!(e.has("_params")||e.has("expandedGroups")||e.has("_filter")||e.has("scheduleEntities"))}async firstUpdated(){this.scheduleEntities=Object.entries(await Oe(this.hass)).map(([,e])=>e.entity_id)}async willUpdate(){var e;if(!this._width||!this._height){const t=null===(e=this.shadowRoot.querySelector(".list"))||void 0===e?void 0:e.getBoundingClientRect();this._width=null==t?void 0:t.width,this._height=null==t?void 0:t.height}}render(){return this._params?q`
      <ha-dialog open @closed=${this.closeDialog} @wa-after-show=${this._opened}>
        <div slot="header">
          <ha-dialog-header>
            <ha-icon-button
              slot="navigationIcon"
              data-dialog="close"
              .label=${ns("ui.dialogs.more_info_control.dismiss",this.hass)}
              .path=${Ws}
            ></ha-icon-button>
            <div slot="title">${Ji("ui.dialog.entity_picker.title",this.hass)}</div>
          </ha-dialog-header>

          <ha-input
            dialogInitialFocus
            .placeholder=${ns("ui.common.search",this.hass)}
            aria-label=${ns("ui.common.search",this.hass)}
            @input=${this._handleSearchChange}
            .value=${this._search}
            icon
            .iconTrailing=${this._search}
          >
            <div class="trailing" slot="trailingIcon">
              ${this._search&&q`
                  <ha-icon-button
                    @click=${this._clearSearch}
                    .label=${ns("ui.common.clear",this.hass)}
                    .path=${Ws}
                    class="clear-button"
                  ></ha-icon-button>
                `}
              <slot name="suffix"></slot>
            </div>
          </ha-input>
        </div>

        <div
          class="list"
          role="list"
          style=${oa({minWidth:`${this._width}px`,height:this._height?`${Math.min(468,this._height)}px`:"auto"})}
        >
          ${this._renderOptions()}
        </div>
      </ha-dialog>
    `:q``}_opened(){var e;const t=null===(e=this.shadowRoot.querySelector(".list"))||void 0===e?void 0:e.getBoundingClientRect();this._width=null==t?void 0:t.width,this._height=null==t?void 0:t.height}_handleSearchChange(e){const t=e.currentTarget.value;this._search=t,clearTimeout(this.timer),this.timer=window.setTimeout(()=>{this._filter=this._search},100)}_clearSearch(){this._search="",this._filter=""}_toggleSelectEntity(e){let t=e.target;for(;"SCHEDULER-LIST-ITEM"!=t.tagName;)t=t.parentElement;t.querySelector("ha-checkbox");const i=t.getAttribute("key");this._params.entities.includes(i)?this._params=Object.assign(Object.assign({},this._params),{entities:this._params.entities.filter(e=>e!=i)}):this._params=Object.assign(Object.assign({},this._params),{entities:[...this._params.entities,i]})}_toggleSelectDomain(e,t){var i;let s=e.target;for(;"SCHEDULER-LIST-ITEM"!=s.tagName;)s=s.parentElement;const a=s.getAttribute("key"),o=null===(i=this.options)||void 0===i?void 0:i.find(e=>e.key==a).entities.map(e=>e.key);this._params=t?Object.assign(Object.assign({},this._params),{domains:this._params.domains.filter(e=>e!=a),entities:this._params.entities.filter(e=>!(null==o?void 0:o.includes(e)))}):Object.assign(Object.assign({},this._params),{domains:[...this._params.domains,a]}),e.stopPropagation()}closeGroupByKey(e){this.shadowRoot.querySelector(".list").childNodes.forEach(t=>{if(t.nodeType==Node.ELEMENT_NODE&&"SCHEDULER-LIST-ITEM"==t.tagName&&t.getAttribute("key")==e){const e=t,i=e.nextElementSibling,s=e.querySelector("ha-icon-button");i.style.height="0px",e.removeAttribute("expanded"),s.classList.remove("expanded")}})}async _toggleExpandGroup(e){let t=e.target;for(;"SCHEDULER-LIST-ITEM"!=t.tagName;)t=t.parentElement;const i=t.querySelector("ha-icon-button"),s=t.getAttribute("key");this.expandedGroups.includes(s)||(this.expandedGroups.forEach(e=>this.closeGroupByKey(e)),this.expandedGroups=[s],await this.requestUpdate());const a=t.nextElementSibling,o=a.scrollHeight;t.hasAttribute("expanded")?(t.removeAttribute("expanded"),i.classList.remove("expanded"),a.style.height="0px",setTimeout(()=>{this.expandedGroups=this.expandedGroups.filter(e=>e!=s)},300)):(t.setAttribute("expanded","true"),i.classList.add("expanded"),a.style.height=`${o}px`)}_renderOptions(){if(!this.options)return;let e=[...this.options];const t=this._filter&&this._filter.trim().length;if(t){const t=this._filter.toLowerCase().trim().split(" ");e=e.map(e=>_a(e,t)||(e=Object.assign(Object.assign({},e),{entities:(e.entities||[]).filter(e=>_a(e,t))})).entities.length?e:void 0).filter(e=>void 0!==e)}return e.length?Object.keys(e).map(i=>{var s,a;const o=e[i].key,n=null===(s=this._params)||void 0===s?void 0:s.domains.includes(o);let r=[...e[i].entities];"switch"==o&&(r=r.filter(e=>!this.scheduleEntities.includes(e.key)));const d=n?r.length:r.filter(e=>{var t;return null===(t=this._params)||void 0===t?void 0:t.entities.includes(e.key)}).length,l=(null===(a=this._params)||void 0===a?void 0:a.domains.includes(o))||e[i].entities.every(e=>{var t;return null===(t=this._params)||void 0===t?void 0:t.entities.includes(e.key)});return q`
        <scheduler-list-item graphic="icon" twoline hasMeta @click=${this._toggleExpandGroup} key="${o}">
          <ha-icon slot="graphic" icon="${e[i].icon}"></ha-icon>
          <div slot="meta" class="meta">
            <ha-button
              appearance="plain"
              @click=${e=>this._toggleSelectDomain(e,l)}
              size="small"
            >
              ${ns(l?"ui.components.media-browser.file_management.deselect_all":"ui.components.subpage-data-table.select_all",this.hass)}
            </ha-button>
            <ha-icon-button
              .path="${Fs}"
              @click=${e=>{e.target.blur()}}
              class="chevron"
            ></ha-icon-button>
          </div>
          <span>${e[i].name}</span>
          <span slot="secondary"
            >${Ji("ui.panel.card_editor.fields.entities.included_number",this.hass,["{number}","{total}"],[d,r.length])}</span
          >
        </scheduler-list-item>
        ${this.expandedGroups.includes(o)||t?q`
                <div class="group ${t?"open":""}">
                  <li role="divider"></li>
                  ${r.map(e=>{var t,i;return q`
                      <scheduler-list-item
                        graphic="icon"
                        twoline
                        hasMeta
                        @click=${this._toggleSelectEntity}
                        class="nested"
                        key="${e.key}"
                      >
                        ${Object.keys(this.hass.states).includes(e.key)?q`<ha-state-icon
                                .stateObj=${this.hass.states[e.key]}
                                .hass=${this.hass}
                                slot="graphic"
                              ></ha-state-icon>`:q`<ha-icon slot="graphic" icon="${e.icon}"></ha-icon>`}
                        <ha-checkbox
                          slot="meta"
                          ?checked=${(null===(t=this._params)||void 0===t?void 0:t.entities.includes(e.key))||(null===(i=this._params)||void 0===i?void 0:i.domains.includes(o))}
                        ></ha-checkbox>

                        <span>${e.name}</span>
                        <span slot="secondary">${e.key}</span>
                      </scheduler-list-item>
                    `})}
                  <li role="divider"></li>
                </div>
              `:""}
      `}):q`
        <scheduler-list-item disabled>
          ${ns("ui.components.entity.entity-picker.no_match",this.hass)}
        </scheduler-list-item>
      `}static get styles(){return r`
      ha-dialog {
        --dialog-content-padding: 0;
        --ha-dialog-width-md: 480px;
      }
      ha-input {
        display: block;
        margin: 0 16px;
      }
      .list {
        box-sizing: border-box;
        min-height: 300px;
        padding: 8px 0px;
      }
      scheduler-list-item {
        --scheduler-list-item-meta-size: 180px;
      }
      scheduler-list-item.nested {
        --scheduler-list-item-meta-size: 48px;
        --scheduler-list-side-padding: 32px;
      }
      scheduler-list-item.nested ha-icon {
        display: flex;
        justify-content: flex-end;
      }
      scheduler-list-item ha-checkbox,
      scheduler-list-item ha-icon-button,
      scheduler-list-item ha-button {
        display: flex;
        align-items: center;
        justify-content: center;
      }
      div.group {
        height: 0px;
        overflow: hidden;
        transition: height 300ms cubic-bezier(0.4, 0, 0.2, 1);
        box-sizing: border-box;
      }
      div.group.open {
        height: auto;
      }
      scheduler-list-item .chevron {
        transition: transform 150ms cubic-bezier(0.4, 0, 0.2, 1);
      }
      scheduler-list-item .chevron.expanded {
        transform: rotate(180deg);
      }
      div.group li {
        width: 100%;
        height: 1px;
        display: block;
        background: var(--divider-color);
        margin: 0px 10px;
      }
      div.meta {
        display: flex;
        justify-content: flex-end;
        align-items: center;
      }
    `}};t([le({attribute:!1})],ga.prototype,"hass",void 0),t([ce()],ga.prototype,"_params",void 0),t([ce()],ga.prototype,"_search",void 0),t([ce()],ga.prototype,"_filter",void 0),t([ce()],ga.prototype,"_width",void 0),t([ce()],ga.prototype,"_height",void 0),t([ce()],ga.prototype,"expandedGroups",void 0),t([ce()],ga.prototype,"options",void 0),t([ce()],ga.prototype,"scheduleEntities",void 0),ga=t([re("dialog-select-entities")],ga);var va=Object.freeze({__proto__:null,get DialogSelectEntities(){return ga}});let ya=class extends oe{constructor(){super(...arguments),this.active=!1}render(){return q`
      <div class="chip ${this.active?"active":""}" @click=${this._handleClick}>
        <div class="overlay"></div>
        ${this.renderIcon()}
        <span class="value"><slot></slot></span>
        ${this.renderTrailingIcon()}
      </div>
    `}renderIcon(){if(!this.icon&&!this.toggleable&&!this.useStateIcon)return V;if(this.toggleable)return q`
        <div class="icon">
          <ha-icon icon="mdi:check"></ha-icon>
        </div>
      `;if(this.useStateIcon){const e=this.hass.states[this.value||""];return q`
        <div class="icon filled">
          ${e?q`<ha-state-icon .stateObj=${e} .hass=${this.hass}></ha-state-icon>`:q`<ha-icon icon="mdi:help-circle-outline"></ha-icon> `}
        </div>
      `}return q`
      <div class="icon filled">
        <ha-icon .icon=${this.icon}></ha-icon>
      </div>
    `}renderTrailingIcon(){const e=`icn_${Math.random().toString(36).substring(2,9)}`;return this.removable||this.badge?this.badge?q` <div class="badge">${this.badge}</div> `:q`
      <div class="trailing-icon" @click=${this._iconClick}>
        <ha-icon icon="mdi:close" id="${e}"></ha-icon>
        ${this.disabled?V:q`<ha-tooltip for="${e}">${ns("ui.common.remove",this.hass)}</ha-tooltip>`}
      </div>
    `:V}_handleClick(e){if(!this.disabled){if(this.toggleable){this.active=!this.active;const e=new CustomEvent("click",{detail:{active:this.active,value:this.value}});this.dispatchEvent(e)}else if(this.selectable){const e=new CustomEvent("click",{detail:{value:this.value}});this.dispatchEvent(e)}e.stopPropagation()}}_iconClick(e){if(e.stopPropagation(),this.disabled)return;const t=new CustomEvent("icon-clicked",{detail:{value:this.value}});this.dispatchEvent(t)}static get styles(){return r`
      :host {
        margin: 4px;
      }
      .chip {
        display: inline-flex;
        position: relative;
        height: var(--chip-height, 32px);
        background: none;
        user-select: none;
        z-index: 0;
        align-items: center;
        justify-content: center;
      }
      .chip:before {
        position: absolute;
        pointer-events: none;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        content: '';
        border: 1px solid var(--chip-color, rgb(168, 225, 251));
        border-radius: var(--chip-border-radius, 32px);
        background: rgba(0, 0, 0, 0);
        opacity: var(--background-opacity, 1);
        z-index: -2;
      }
      .chip.active:before {
        background: var(--chip-color, rgb(168, 225, 251));
      }
      .icon {
        position: relative;
        width: 32px;
        height: 32px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        --mdc-icon-size: 20px;
        margin-right: -8px;
        color: rgba(0, 0, 0, 0.54);
      }
      .icon.filled:before {
        position: absolute;
        pointer-events: none;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        content: '';
        background: var(--chip-color, rgb(168, 225, 251));
        border-radius: 32px;
        z-index: -2;
      }
      .value {
        color: var(--primary-text-color);
        font-size: var(--chip-font-size, 0.875rem);
        font-weight: 400;
        display: flex;
        align-items: center;
        padding: 0px 12px;
        opacity: 0.9;
      }
      .trailing-icon {
        position: relative;
        width: 26px;
        height: 26px;
        border-radius: 13px;
        display: flex;
        align-items: center;
        justify-content: center;
        --mdc-icon-size: 16px;
        margin: 0px 3px 0px -8px;
        color: var(--secondary-text-color);
        cursor: pointer;
      }
      .trailing-icon:before {
        position: absolute;
        pointer-events: none;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        content: '';
        background: var(--chip-color, var(--secondary-text-color));
        border-radius: 26px;
        z-index: -2;
        opacity: 0;
        transition: opacity 0.1s ease-in-out;
      }
      .trailing-icon:hover:before {
        opacity: 0.15;
      }
      .trailing-icon:active:before {
        opacity: 0.3;
      }
      :host([disabled]) .trailing-icon:hover:before,
      :host([disabled]) .trailing-icon:active:before {
        opacity: 0;
      }
      :host([disabled]) .trailing-icon {
        cursor: not-allowed;
      }
      :host([selectable]) .chip,
      :host([toggleable]) .chip {
        cursor: pointer;
      }
      .overlay {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: -1;
        background: rgba(0, 0, 0, 0);
        border-radius: var(--chip-border-radius, 32px);
        transition:
          background-color 0.1s ease-in-out,
          border 0.1s ease-in-out;
        border: 1px solid rgba(0, 0, 0, 0);
      }
      :host([selectable]) .chip:hover .overlay,
      :host([toggleable]) .chip:hover .overlay {
        border: 1px solid rgba(0, 0, 0, 0.05);
        background: rgba(0, 0, 0, 0.05);
      }
      :host([selectable]) .chip:active .overlay,
      :host([toggleable]) .chip:active .overlay {
        border: 1px solid rgba(0, 0, 0, 0.1);
        background: rgba(0, 0, 0, 0.1);
      }
      :host([selectable]) .chip:hover .value,
      :host([toggleable]) .chip:hover .value {
        opacity: 1;
      }
      :host([active]):host([selectable]) .chip:hover .overlay,
      :host([active]):host([toggleable]) .chip:hover .overlay {
        background: rgba(0, 0, 0, 0.1);
        border: 1px solid rgba(0, 0, 0, 0);
      }
      :host([active]):host([selectable]) .chip:active .overlay,
      :host([active]):host([toggleable]) .chip:active .overlay {
        background: rgba(0, 0, 0, 0.2);
        border: 1px solid rgba(0, 0, 0, 0);
      }

      :host([toggleable]) .icon {
        width: 0px;
        transition: width 0.1s ease-in-out;
        overflow: hidden;
        display: flex;
        align-items: center;
        margin-left: 12px;
      }
      :host([toggleable]) .active .icon {
        width: 20px;
      }
      .badge {
        position: relative;
        display: flex;
        height: 26px;
        min-width: 26px;
        border-radius: 13px;
        font-size: var(--chip-font-size, 0.875rem);
        align-items: center;
        justify-content: center;
        margin: 0px 3px 0px -8px;
      }
      .badge:before {
        position: absolute;
        pointer-events: none;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        content: '';
        background: var(--chip-color, var(--secondary-text-color));
        border-radius: 26px;
        z-index: -2;
        transition: opacity 0.1s ease-in-out;
        opacity: 0.1;
      }
    `}};t([le({attribute:!1})],ya.prototype,"hass",void 0),t([le({type:String})],ya.prototype,"icon",void 0),t([le({type:Boolean})],ya.prototype,"useStateIcon",void 0),t([le({type:Boolean})],ya.prototype,"selectable",void 0),t([le({type:Boolean})],ya.prototype,"removable",void 0),t([le({type:Boolean})],ya.prototype,"toggleable",void 0),t([le({type:Boolean})],ya.prototype,"active",void 0),t([le({type:String})],ya.prototype,"badge",void 0),t([le({type:String})],ya.prototype,"value",void 0),t([le({type:Boolean})],ya.prototype,"disabled",void 0),ya=t([re("scheduler-chip")],ya);let fa=class extends oe{constructor(){super(...arguments),this.value=[]}render(){return this.items?q` ${Object.values(this.items).map(e=>this.renderChipitem(e))} `:q``}renderChipitem(e){const t=e.useStateIcon&&!Object.keys(this.hass.states).includes(e.value||"");return q`
      <scheduler-chip
        .hass=${this.hass}
        .value=${e.value||e.name}
        .icon=${e.icon}
        ?useStateIcon=${e.useStateIcon}
        ?active=${this.value.includes(e.value||e.name)}
        .badge=${void 0!==e.badge?String(e.badge):void 0}
        ?selectable=${this.selectable}
        ?toggleable=${this.toggleable}
        ?removable=${this.removable}
        @click=${this._handleClick}
        @icon-clicked=${this._handleClick}
        ?disabled=${this.disabled}
        style="${t?"text-decoration: line-through":""}"
      >
        ${e.name}
      </scheduler-chip>
    `}_handleClick(e){if(!this.disabled)if(this.toggleable){const t=e.detail.value,i=e.detail.active;this.value.includes(t)&&!i?this.value=this.value.filter(e=>e!=t):!this.value.includes(t)&&t&&(this.value=[...this.value,t]);const s=new CustomEvent("value-changed",{detail:this.value});this.dispatchEvent(s)}else{const t=new CustomEvent("value-changed",{detail:e.detail.value});this.dispatchEvent(t)}}static get styles(){return r`
      :host {
        display: flex;
        flex-direction: row;
        flex: 1;
        margin: 0px -4px;
        flex-wrap: wrap;
      }
      scheduler-chip {
        display: inline-flex;
        margin-bottom: 4px;
      }
    `}};t([le({attribute:!1})],fa.prototype,"hass",void 0),t([le({attribute:!1})],fa.prototype,"items",void 0),t([le({attribute:!1})],fa.prototype,"value",void 0),t([le({type:Boolean})],fa.prototype,"selectable",void 0),t([le({type:Boolean})],fa.prototype,"toggleable",void 0),t([le({type:Boolean})],fa.prototype,"removable",void 0),t([le({type:Boolean})],fa.prototype,"disabled",void 0),fa=t([re("scheduler-chip-set")],fa);const ba=[{name:"primary",weight:10},{name:"secondary",weight:8}];let wa=class extends oe{constructor(){super(...arguments),this.value=[],this.multiple=!1,this.disabled=!1,this.multipleMode=!1,this.scheduleEntities=[],this._valueRenderer=e=>{Array.isArray(e)&&(e=e.length?[...e].pop():"");const t=e||"",i=this.hass.states[t];if(!i)return q`
        <ha-svg-icon slot="start" .path=${Gs} style="margin: 0 4px"></ha-svg-icon>
        <span slot="headline">${t}</span>
      `;const s=this._parseEntityItem(t);return q`
      ${s.icon?q` <ha-icon slot="start" icon="${s.icon}"></ha-icon> `:q`
              <state-badge
                .hass=${this.hass}
                .stateObj=${i}
                slot="start"
                color="var(--icon-primary-color)"
              ></state-badge>
            `}
      <span slot="headline">${s.primary}</span>
      <span slot="supporting-text">${s.secondary}</span>
    `},this._rowRenderer=e=>{const t=e.id||"",i=this.hass.states[t];return q`
      <ha-combo-box-item type="button" compact>
        ${e.icon?q` <ha-icon slot="start" icon="${e.icon}"></ha-icon> `:i?q`
                  <state-badge
                    .hass=${this.hass}
                    .stateObj=${i}
                    slot="start"
                    color="var(--icon-primary-color)"
                  ></state-badge>
                `:q` <ha-svg-icon slot="start" .path=${Gs}></ha-svg-icon> `}
        <span slot="headline">${e.primary}</span>
        ${e.secondary?q`<span slot="supporting-text">${e.secondary}</span>`:V}
      </ha-combo-box-item>
    `},this._filteredItems=()=>{let e=Object.keys(this.hass.states);this.domain&&(e=e.filter(e=>Xi(e)==this.domain)),this.multiple&&(e=e.filter(e=>{var t;return!(null===(t=this.value)||void 0===t?void 0:t.includes(e))})),this.config&&(e=e.filter(e=>((this.config.include||Ue).some(t=>ts(t,e))||Object.keys(this.config.customize||{}).some(t=>ts(t,e)))&&!(this.config.exclude||[]).some(t=>ts(t,e)))),e=e.filter(e=>!this.scheduleEntities.includes(e)),this.filterFunc&&(e=e.filter(e=>this.filterFunc(this.hass.states[e])));const t=e.map(e=>this._parseEntityItem(e));return t}}async firstUpdated(){this.scheduleEntities=Object.entries(await Oe(this.hass)).map(([,e])=>e.entity_id),this.domain&&this.config&&!is(this.domain,this.config)&&(this.config=Object.assign(Object.assign({},this.config),{include:[...this.config.include||[],this.domain],exclude:[...(this.config.exclude||[]).filter(e=>!e.startsWith(this.domain))]})),this._autoSelectIfSingleEntity()}updated(e){super.updated(e),e.has("domain")&&this._autoSelectIfSingleEntity()}_autoSelectIfSingleEntity(){if(this.value&&this.value.length>0)return;const e=this._filteredItems();1===e.length&&(this.value=[e[0].id],Vs(this,"value-changed",{value:this.value}))}render(){var e,t;return q`
      ${this.renderChips()}
      ${(null===(e=this.value)||void 0===e?void 0:e.length)&&!this.multipleMode&&this.multiple?V:q`
              <ha-generic-picker
                .label=${(null===(t=this.value)||void 0===t?void 0:t.length)?"":ns("ui.components.entity.entity-picker.choose_entity",this.hass)}
                .hass=${this.hass}
                .autofocus=${this.autofocus}
                .notFoundLabel=${ns("ui.components.combo-box.no_match",this.hass)}
                .value=${this.multiple?"":this.value}
                .valueRenderer=${this._valueRenderer}
                .rowRenderer=${this._rowRenderer}
                .disabled=${this.disabled}
                .getItems=${this._filteredItems}
                .searchKeys=${ba}
                .searchLabel=${ns("ui.dialogs.quick-bar.filter_placeholder",this.hass)}
                @value-changed=${this._valueChanged}
                hide-clear-icon
                allow-custom-value
              >
              </ha-generic-picker>
            `}
    `}renderChips(){if(!this.multiple)return V;const e=(this.value||[]).map(e=>{const t=this._parseEntityItem(e);return{name:t.primary,value:e,useStateIcon:!t.icon,icon:t.icon}});return q`
      <div class="wrapper">
        <scheduler-chip-set
          .hass=${this.hass}
          .items=${e}
          removable
          @value-changed=${this._removeClick}
          ?disabled=${this.disabled}
        >
        </scheduler-chip-set>
        <div class="column-right">
          ${e.length?q`
                  <ha-icon-button
                    @click=${e=>{this.multipleMode=!this.multipleMode,e.target.blur()}}
                    .path=${this.multipleMode?"M7.41,15.41L12,10.83L16.59,15.41L18,14L12,8L6,14L7.41,15.41Z":Fs}
                    slot="end"
                  ></ha-icon-button>
                `:V}
        </div>
      </div>
    `}_valueChanged(e){const t=e.detail.value,i=e.currentTarget;t&&(this.value=[...this.value||[],t],this.multiple&&(i.value=""),Vs(this,"value-changed",{value:this.value}),e.stopPropagation())}_removeClick(e){const t=e.detail;this.value=(this.value||[]).filter(e=>e!==t),Vs(this,"value-changed",{value:this.value})}_parseEntityItem(e){var t,i,s;const a=Object.entries((null===(t=this.config)||void 0===t?void 0:t.customize)||{}).filter(([t,i])=>ts(t,e)).map(([e,t])=>t),o=null===(i=a.find(e=>"name"in e))||void 0===i?void 0:i.name,n=null===(s=a.find(e=>"icon"in e))||void 0===s?void 0:s.icon;return{id:e,primary:o||es(this.hass,e),secondary:e,icon:n}}};wa.styles=r`
    :host {
      display: flex;
      flex-direction: column;
      width: 100%;
    }
    :host > * {
      display: block;
      width: 100%;
    }
    div.wrapper {
      display: flex;
    }
    scheduler-chip-set {
      display: flex;
    }
    div.column-right {
      display: flex;
    }
    div.column-right ha-icon-button {
      display: flex;
      align-self: flex-end;
    }
  `,t([le({attribute:!1})],wa.prototype,"hass",void 0),t([le()],wa.prototype,"domain",void 0),t([le()],wa.prototype,"config",void 0),t([le({type:Array})],wa.prototype,"value",void 0),t([le({type:Boolean})],wa.prototype,"multiple",void 0),t([le({type:Boolean})],wa.prototype,"disabled",void 0),t([ce()],wa.prototype,"multipleMode",void 0),t([ce()],wa.prototype,"scheduleEntities",void 0),wa=t([re("scheduler-entity-picker")],wa);let ka=class extends oe{constructor(){super(...arguments),this.expanded=!1,this.disabled=!1,this.idx=-1,this.openClose=new CustomEvent("open-close",{detail:{},bubbles:!0,composed:!0})}render(){return q`
      <div
        class="header ${this.expanded?"expanded":""}"
        @click=${this._toggleContent}
        @focus=${this._focusChanged}
        @blur=${this._focusChanged}
        role="button"
        tabindex="0"
        aria-expanded=${this.expanded}
        aria-controls="sect1"
      >
        ${this.disabled?"":q` <ha-icon icon="mdi:chevron-down" class="chevron ${this.expanded?"expanded":""}"></ha-icon> `}
        <slot name="header" class="title"></slot>
        <div id="contextMenu">
          <slot name="contextMenu"> </slot>
        </div>
      </div>

      <div class="container">
        <slot name="content"></slot>
      </div>
    `}_toggleContent(){this.disabled||this.dispatchEvent(this.openClose)}attributeChangedCallback(e,t,i){let s;if(null!==this.shadowRoot)for(const e of this.shadowRoot.children)if("container"==e.className){s=e;break}if(s)if(this.hasAttribute("expanded")){const e=s.scrollHeight;s.style.height=`${e}px`}else s.style.height="0px";super.attributeChangedCallback(e,t,i)}_focusChanged(e){this.disabled||this.shadowRoot.querySelector(".header").classList.toggle("focused","focus"===e.type)}static get styles(){return r`
      :host {
        display: block;
        border-radius: 12px;
        border: 1px solid var(--divider-color);
        box-sizing: border-box;
        margin: 8px 0px;
        position: relative;
      }
      .header {
        display: flex;
        width: 100%;
        border-radius: 12px;
        padding: 12px;
        box-sizing: border-box;
        cursor: pointer;
      }
      :host([disabled]) .header {
        cursor: default;
      }
      .header .title {
        font-weight: 600;
        padding: 0px 8px;
      }
      .header ::slotted(div) {
        flex: 1;
        margin-right: 32px;
      }
      .header.focused {
        background: var(--input-fill-color);
      }
      .header.expanded {
        border-radius: 12px 12px 0px 0px;
      }
      #contextMenu {
        position: absolute;
        right: 0px;
        top: 0px;
      }

      .chevron {
        transition: transform 150ms cubic-bezier(0.4, 0, 0.2, 1);
        direction: var(--direction);
        margin-left: 0px;
      }
      .chevron.expanded {
        transform: rotate(180deg);
      }
      .container {
        overflow: hidden;
        transition: height 300ms cubic-bezier(0.4, 0, 0.2, 1);
        padding: 0px 12px;
        box-sizing: border-box;
        height: 0px;
      }
      :host([disabled]) .container {
        height: auto;
      }
      .container.expanded {
        height: auto;
      }
      @media all and (max-width: 450px) {
        .container {
          padding: 0px;
        }
      }
    `}};t([le({type:Boolean,reflect:!0})],ka.prototype,"expanded",void 0),t([le({type:Boolean,reflect:!0})],ka.prototype,"disabled",void 0),t([le({attribute:!0})],ka.prototype,"idx",void 0),t([le({type:CustomEvent})],ka.prototype,"openClose",void 0),ka=t([re("scheduler-collapsible-section")],ka);let xa=class extends oe{set openedItem(e){e!==this._openedItem&&void 0!==e&&setTimeout(()=>{this.updateOpenedItem(e)},50)}constructor(){super(),this.disabled=!1,this._openedItem=-1,this._numItems=0,this.addEventListener("open-close",this.toggleActiveSection)}firstUpdated(){const e=this.querySelectorAll("scheduler-collapsible-section");this._numItems=e.length}toggleActiveSection(e){if(this.disabled)return;const t=e.target,i=Number(t.getAttribute("idx"));"true"===t.getAttribute("expanded")?this.updateOpenedItem(-1):this.updateOpenedItem(i)}updateOpenedItem(e){this.querySelectorAll("scheduler-collapsible-section").forEach(function(t){const i=Number(t.getAttribute("idx"));i!==e&&t.getAttribute("expanded")?t.removeAttribute("expanded"):i!==e||t.getAttribute("expanded")||t.setAttribute("expanded","true")}),this._openedItem=e;const t=new CustomEvent("openclose-changed",{detail:{item:e}});this.dispatchEvent(t)}render(){return q` <slot></slot> `}};t([le()],xa.prototype,"disabled",void 0),t([ce()],xa.prototype,"_openedItem",void 0),t([ce()],xa.prototype,"_numItems",void 0),xa=t([re("scheduler-collapsible-group")],xa);const $a="__NONE_OPTION__";let ja=class extends oe{constructor(){super(...arguments),this.disabled=!1}render(){var e;if(this.config.select){const e=this.config.select,t=[this.value||[]].flat().map(String),i=e=>{const i=e.detail;this.value=t.filter(e=>e!=i),Vs(this,"value-changed",{value:this.value})},s=()=>{const e=t.map(e=>Object({name:e,value:e}));return q` <scheduler-chip-set .hass=${this.hass} .items=${e} removable @value-changed=${i}>
        </scheduler-chip-set>`},a=e=>{var t;const i=null===(t=this.config.select)||void 0===t?void 0:t.translation_key;let s="";return i&&(s=ns(i.replace("${value}",e),this.hass,!1)),s||(s=e),s},o=e=>"object"==typeof e?{id:e.value,primary:a(e.label),icon:e.icon}:{id:e,primary:a(e)};let n=[...null==e?void 0:e.options].map(o);const r=[this.value||[]].flat().map(String);n=[...n,...r.filter(e=>!n.find(t=>t.id==e)).map(o)],Array.isArray(this.value)&&(n=n.filter(e=>"object"==typeof e?!t.includes(e.id):!t.includes(e)));const d=()=>n.length?(n.some(e=>e.icon),n.map(e=>q`
            <ha-dropdown-item .value=${e.id}>
              ${e.icon?q`<ha-icon slot="icon" .icon=${e.icon}></ha-icon>`:V}
              <span>${e.primary}</span>
            </ha-dropdown-item>
          `)):q`
            <ha-dropdown-item .value=${$a}>
              ${this.hass.localize("ui.components.combo-box.no_match")}
            </ha-dropdown-item>
          `,l=e=>{const t=e.target,i=t.querySelector("ha-picker-field");this.style.setProperty("--select-menu-width",`${i.offsetWidth}px`),t.classList.add("opened")},c=e=>{e.target.classList.remove("opened")},u=e=>{const t=e.detail.item.value;(t!=$a&&!Array.isArray(this.value)||(e.target.value=void 0,t!=$a))&&this._valueChanged(new CustomEvent("value-changed",{detail:{value:t}}))},h=()=>{this._valueChanged(new CustomEvent("value-changed",{detail:{value:void 0}}))},m=Ze(this.value)&&!Array.isArray(this.value)?n.find(e=>e.id===this.value):void 0,p=m?m.primary||m.id:Ze(this.value)&&!Array.isArray(this.value)?this.value:void 0;return q`
        <div class="select-wrapper">
          ${e.multiple?q` <div class="chips">${s()}</div> `:""}
          <ha-dropdown placement="bottom" @wa-select=${u} @wa-show=${l} @wa-hide=${c}>
            <ha-picker-field
              slot="trigger"
              type="button"
              compact
              @clear=${h}
              .disabled=${this.disabled}
              .hideClearIcon=${this.disabled||!Ze(this.value)||Array.isArray(this.value)&&!this.value.length}
              .value=${p}
              .icon=${null==m?void 0:m.icon}
            >
            </ha-picker-field>
            ${d()}
          </ha-dropdown>
        </div>
      `}if(this.config.number){const t=this.config.number,i="box"==t.mode||!Ze(t.min)||!Ze(t.max);let s=this.value;i||"number"==typeof s||(s=t.min),"number"==typeof t.scale_factor&&(s=Number(s)/t.scale_factor),"number"==typeof(null==t?void 0:t.step)&&(s=Math.round(Number(s)/t.step)*t.step),Ze(s)&&(s=_s(Number(s)));const a=e=>{let i=Number(e.target.value);"number"==typeof t.scale_factor&&(i*=t.scale_factor),"number"==typeof(null==t?void 0:t.step)&&(i=Math.round(i/t.step)*t.step),i=_s(i),this._valueChanged(new CustomEvent("value-changed",{detail:{value:i}})),e.stopPropagation()},o=e=>{e.stopPropagation();const t=e.target.value,i=""===t||isNaN(Number(t))?void 0:Number(t);this._valueChanged(new CustomEvent("value-changed",{detail:{value:i}}))},n=(e,i)=>{let s=t.step&&Number(t.step)%1==0?null!==e.match(/^-?\d+$/):null!==e.match(/^[+-]?\d+([.,]\d+)?$/);return s&&Ze(t.min)&&(s=Number(e)>=t.min),s&&Ze(t.max)&&(s=Number(e)<=t.max),{valid:s,customError:!s}};return q`
        <div class="slider-wrapper">
          ${i?q`
                  <ha-input
                    .inputMode=${t.step&&Number(t.step)%1==0?"numeric":"decimal"}
                    .min=${t.min}
                    .max=${t.max}
                    .value=${s||""}
                    .step=${null!==(e=t.step)&&void 0!==e?e:1}
                    .disabled=${this.disabled}
                    .required=${!0}
                    .suffix=${t.unit}
                    type="number"
                    autoValidate
                    .validityTransform=${n}
                    @input=${o}
                  >
                  </ha-input>
                `:q`
                  <ha-slider
                    .min=${t.min}
                    .max=${t.max}
                    .step=${t.step||1}
                    .value=${s}
                    @change=${a}
                    ?disabled=${this.disabled}
                  ></ha-slider>
                  <span class="value">${s} ${t.unit||""}</span>
                `}
        </div>
      `}if(this.config.text)return this.config.text,q`
        <div class="textfield-wrapper">
          <ha-input
            .value=${this.value||""}
            @input=${this._valueChanged}
            .placeholder=""
            ?disabled=${this.disabled}
          ></ha-input>
        </div>
      `;if(this.config.boolean){const e={select:{options:[{value:"true",label:"True",icon:"mdi:check"},{value:"false",label:"False",icon:"mdi:close"}]}},t=e=>{const t=Ze(e.detail.value)?"true"===e.detail.value:void 0;e.stopPropagation(),this._valueChanged(new CustomEvent("value-changed",{detail:{value:t}}))};return q`
        <scheduler-combo-selector
          .hass=${this.hass}
          .config=${e}
          .value=${"boolean"==typeof this.value?this.value?"true":"false":void 0}
          @value-changed=${t}
          ?disabled=${this.disabled}
        >
        </scheduler-combo-selector>
      `}return q``}_valueChanged(e){if(e.stopPropagation(),Array.isArray(this.value)){const t=e.detail.value;if(!t)return;this.value=[...this.value,t]}else if(e.detail){let t=e.detail.value;void 0===t&&(t=null),this.value=t}else this.value=e.target.value;Vs(this,"value-changed",{value:this.value})}};ja.styles=r`
    :host {
      display: flex;
      width: 100%;
    }
    div.slider-wrapper {
      display: flex;
      flex-direction: row;
      width: 100%;
      align-items: center;
      gap: 4px;
    }
    div.slider-wrapper > * {
      display: flex;
    }
    div.slider-wrapper ha-slider {
      flex: 1;
    }
    div.slider-wrapper span {
      justify-content: center;
      align-self: center;
      min-width: 45px;
      text-align: end;
    }
    div.slider-wrapper ha-input {
      --ha-input-input-width: 100px;
    }
    div.select-wrapper {
      display: flex;
      flex-direction: column;
      width: 100%;
    }
    div.textfield-wrapper {
      display: flex;
      width: 100%;
    }
    div.textfield-wrapper ha-input {
      display: flex;
      width: 100%;
    }
    ha-dropdown::part(menu) {
      min-width: var(--select-menu-width);
    }
  `,t([le({attribute:!1})],ja.prototype,"hass",void 0),t([le({attribute:!1})],ja.prototype,"config",void 0),t([le()],ja.prototype,"value",void 0),t([le({type:Boolean})],ja.prototype,"disabled",void 0),ja=t([re("scheduler-combo-selector")],ja);let Oa=class extends oe{constructor(){super(...arguments),this._config={},this.title="",this.tagOptions=[],this.customTagValue=""}setConfig(e){this._config=Object.assign({},e)}async firstUpdated(){this.title="string"==typeof this._config.title?this._config.title:"";const e=(await Us(this.hass)).map(e=>e.name);e.sort(as),this.tagOptions=e}render(){var e,t,i,s,a,o,n,r;const d={number:{min:0,max:30,step:1,unit_of_measurement:Ji("ui.panel.card_editor.fields.time_step.unit_minutes",this.hass)}},l={select:{options:this.tagOptions,multiple:!0,custom_value:!0}};return q`
      <div class="card-config">
        <ha-button @click=${this._showIncludedEntitiesDialog} outlined>
          ${Ji("ui.panel.card_editor.fields.entities.button_label",this.hass)}
          <ha-svg-icon slot="trailingIcon" .path=${"M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z"}></ha-svg-icon>
        </ha-button>

        <scheduler-settings-row ?showPrefix=${!0}>
          <ha-checkbox slot="prefix" ?checked=${!1!==this._config.title} @change=${this._setEnableTitle}>
          </ha-checkbox>
          <span slot="heading">${Ji("ui.panel.card_editor.fields.title.heading",this.hass)}</span>

          <ha-input
            .value=${this.title}
            @input=${this._setTitle}
            .placeholder=${Ji("ui.panel.common.title",this.hass)}
            ?disabled=${!1===this._config.title}
          ></ha-input>
        </scheduler-settings-row>

        <div class="two-columns" style="margin: 10px 0px 15px 0px">
          <div class="column">
            <ha-formfield label="${Ji("ui.panel.card_editor.fields.discover_existing.heading",this.hass)}">
              <ha-switch
                ?checked=${!1!==this._config.discover_existing}
                @change=${e=>{this._updateConfig({discover_existing:e.target.checked})}}
              ></ha-switch>
            </ha-formfield>
          </div>
          <div class="column">
            <ha-formfield label="${Ji("ui.panel.card_editor.fields.show_header_toggle.heading",this.hass)}">
              <ha-switch
                ?checked=${this._config.show_header_toggle}
                @change=${e=>{this._updateConfig({show_header_toggle:e.target.checked})}}
              ></ha-switch>
            </ha-formfield>
          </div>
          <div class="column">
            <ha-formfield label="${Ji("ui.panel.card_editor.fields.show_toggle_switches.heading",this.hass)}">
              <ha-switch
                ?checked=${!1!==this._config.show_toggle_switches}
                @change=${e=>{this._updateConfig({show_toggle_switches:e.target.checked})}}
              ></ha-switch>
            </ha-formfield>
          </div>
        </div>

        <scheduler-settings-row>
          <span slot="heading">${Ji("ui.panel.card_editor.fields.time_step.heading",this.hass)}</span>

          <scheduler-combo-selector
            .hass=${this.hass}
            .config=${d}
            .value=${this._config.time_step||15}
            @value-changed=${e=>{this._updateConfig({time_step:e.detail.value})}}
          >
          </scheduler-combo-selector>
        </scheduler-settings-row>

        <span>${Ji("ui.panel.card_editor.fields.default_editor.heading",this.hass)}</span>
        <div class="two-columns">
          <div
            class="column radio"
            @click=${()=>{this._updateConfig({default_editor:me.Single})}}
          >
            <ha-icon
              icon="${this._config.default_editor!=me.Scheme?"mdi:radiobox-marked":"mdi:radiobox-blank"}"
              class="${this._config.default_editor!=me.Scheme?"checked":""}"
            ></ha-icon>
            <span>${Ji("ui.panel.card_editor.fields.default_editor.options.single",this.hass)}</span>
          </div>
          <div
            class="column radio"
            @click=${()=>{this._updateConfig({default_editor:me.Scheme})}}
          >
            <ha-icon
              icon="${this._config.default_editor==me.Scheme?"mdi:radiobox-marked":"mdi:radiobox-blank"}"
              class="${this._config.default_editor==me.Scheme?"checked":""}"
            ></ha-icon>
            <span>${Ji("ui.panel.card_editor.fields.default_editor.options.scheme",this.hass)}</span>
          </div>
        </div>

        <span slot="heading">${Ji("ui.panel.card_editor.fields.sort_by.heading",this.hass)}</span>

        <div class="two-columns">
          <div
            class="column radio"
            @click=${()=>{this._setSortBy("relative-time")}}
          >
            <ha-icon
              icon="${[this._config.sort_by||Re].flat().includes("relative-time")?"mdi:radiobox-marked":"mdi:radiobox-blank"}"
              class="${[this._config.sort_by||Re].flat().includes("relative-time")?"checked":""}"
            ></ha-icon>
            <span>${Ji("ui.panel.card_editor.fields.sort_by.options.relative_time",this.hass)}</span>
          </div>
          <div
            class="column radio"
            @click=${()=>{this._setSortBy("title")}}
          >
            <ha-icon
              icon="${[this._config.sort_by||Re].flat().includes("title")?"mdi:radiobox-marked":"mdi:radiobox-blank"}"
              class="${[this._config.sort_by||Re].flat().includes("title")?"checked":""}"
            ></ha-icon>
            <span>${Ji("ui.panel.card_editor.fields.sort_by.options.title",this.hass)}</span>
          </div>
        </div>

        <span>${Ji("ui.panel.card_editor.fields.display_format_primary.heading",this.hass)}</span>

        <div class="two-columns">
          <div
            class="column radio"
            @click=${()=>{this._setDisplayOptionsPrimary("default")}}
          >
            <ha-icon
              icon="${[(null===(e=this._config.display_options)||void 0===e?void 0:e.primary_info)||Ve].flat().includes("default")?"mdi:radiobox-marked":"mdi:radiobox-blank"}"
              class="${[(null===(t=this._config.display_options)||void 0===t?void 0:t.primary_info)||Ve].flat().includes("default")?"checked":""}"
            ></ha-icon>
            <span>${Ji("ui.panel.card_editor.fields.display_format_primary.options.default",this.hass)}</span>
          </div>
          <div
            class="column radio"
            @click=${()=>{this._setDisplayOptionsPrimary("{entity}: {action}")}}
          >
            <ha-icon
              icon="${[(null===(i=this._config.display_options)||void 0===i?void 0:i.primary_info)||Ve].flat().includes("{entity}: {action}")?"mdi:radiobox-marked":"mdi:radiobox-blank"}"
              class="${[(null===(s=this._config.display_options)||void 0===s?void 0:s.primary_info)||Ve].flat().includes("{entity}: {action}")?"checked":""}"
            ></ha-icon>
            <span
              >${Ji("ui.panel.card_editor.fields.display_format_primary.options.entity_action",this.hass)}</span
            >
          </div>
        </div>
        <span>${Ji("ui.panel.card_editor.fields.display_format_secondary.heading",this.hass)}</span>

        <div class="two-columns">
          <div class="column">
            <ha-formfield
              label="${Ji("ui.panel.card_editor.fields.display_format_secondary.options.relative_time",this.hass)}"
            >
              <ha-checkbox
                value="relative-time"
                @change=${this._setDisplayOptionsSecondary}
                ?checked=${[(null===(a=this._config.display_options)||void 0===a?void 0:a.secondary_info)||He].flat().includes("relative-time")}
              >
              </ha-checkbox>
            </ha-formfield>

            <ha-formfield
              label="${Ji("ui.panel.card_editor.fields.display_format_secondary.options.time",this.hass)}"
            >
              <ha-checkbox
                value="time"
                @change=${this._setDisplayOptionsSecondary}
                ?checked=${[(null===(o=this._config.display_options)||void 0===o?void 0:o.secondary_info)||He].flat().includes("time")}
              >
              </ha-checkbox>
            </ha-formfield>
          </div>
          <div class="column">
            <ha-formfield
              label="${Ji("ui.panel.card_editor.fields.display_format_secondary.options.days",this.hass)}"
            >
              <ha-checkbox
                value="days"
                @change=${this._setDisplayOptionsSecondary}
                ?checked=${[(null===(n=this._config.display_options)||void 0===n?void 0:n.secondary_info)||He].flat().includes("days")}
              >
              </ha-checkbox>
            </ha-formfield>

            <ha-formfield
              label="${Ji("ui.panel.card_editor.fields.display_format_secondary.options.additional_tasks",this.hass)}"
            >
              <ha-checkbox
                value="additional-tasks"
                @change=${this._setDisplayOptionsSecondary}
                ?checked=${[(null===(r=this._config.display_options)||void 0===r?void 0:r.secondary_info)||He].flat().includes("additional-tasks")}
              >
              </ha-checkbox>
            </ha-formfield>
          </div>
        </div>

        <scheduler-settings-row>
          <span slot="heading">${Ji("ui.panel.card_editor.fields.tags.heading",this.hass)}</span>
          <div style="display: flex; flex: 1; flex-direction: column">
            <scheduler-combo-selector
              .hass=${this.hass}
              .config=${l}
              .value=${[this._config.tags||[]].flat()}
              @value-changed=${e=>{this._updateConfig({tags:e.detail.value})}}
            >
            </scheduler-combo-selector>

            <ha-dropdown
              @wa-after-hide=${e=>{e.stopPropagation(),e.target.querySelector("ha-button").blur()}}
              @click=${e=>{e.preventDefault(),e.stopImmediatePropagation()}}
              @wa-after-show=${e=>{e.target.querySelector("ha-input").focus()}}
              placement="bottom-start"
            >
              <ha-button appearance="plain" slot="trigger">
                <ha-icon slot="start" icon="mdi:plus"></ha-icon>
                ${ns("ui.panel.config.tag.add_tag",this.hass)}
              </ha-button>

              <div style="display: flex; align-items: center; padding: 0x 2px 0px 8px">
                <ha-input
                  .value=${this.customTagValue}
                  .label=${ns("ui.panel.config.tag.add_tag",this.hass)}
                  @input=${e=>{this.customTagValue=e.currentTarget.value}}
                  .placeholder=""
                ></ha-input>
                <ha-button appearance="plain" @click=${this._customTagConfirmClick}>
                  ${ns("ui.common.ok",this.hass)}
                </ha-button>
              </div>
            </ha-dropdown>
          </div>
        </scheduler-settings-row>
      </div>
    `}_setEnableTitle(e){e.target.checked?this.title.length?this._updateConfig({title:this.title}):this._updateConfig({title:!0}):this._updateConfig({title:!1})}_setTitle(e){const t=e.target.value;this.title=t,t!==Ji("ui.panel.common.title",this.hass)&&t.length?this._updateConfig({title:t}):this._updateConfig({title:!0})}_setSortBy(e){var t;let i=[(null===(t=this._config)||void 0===t?void 0:t.sort_by)||Re].flat();i=i.filter(e=>"state"==e),i.includes(e)||(i=[...i,e]),this._updateConfig({sort_by:i})}_setDisplayOptionsPrimary(e){var t;const i=Object.assign(Object.assign({},null===(t=this._config)||void 0===t?void 0:t.display_options),{primary_info:e});this._updateConfig({display_options:i})}_setDisplayOptionsSecondary(e){var t;const i=e.target.value,s=e.target.checked;let a=Object.assign({},null===(t=this._config)||void 0===t?void 0:t.display_options),o=[a.secondary_info||[]].flat();o=s?Array.from(new Set([...o,i])):o.filter(e=>e!==i),o.sort((e,t)=>{const i={"relative-time":1,time:o.includes("relative-time")?3:2,days:o.includes("relative-time")?2:3,"additional-tasks":4},s=Object.keys(i).includes(e)?i[e]:5,a=Object.keys(i).includes(t)?i[t]:5;return s>a?1:s<a?-1:0}),a=Object.assign(Object.assign({},a),{secondary_info:[...o]}),this._updateConfig({display_options:a})}async _showIncludedEntitiesDialog(e){let t=(this._config.include||[]).filter(e=>!e.includes(".")),i=(this._config.include||[]).filter(e=>e.includes("."));const s=await Hs(this.hass);let a=Object.assign(Object.assign({},this._config),{customize:Object.assign(Object.assign({},s),this._config.customize||{})});await new Promise(s=>{const o={cancel:()=>s(null),confirm:e=>s(e),domains:t,entities:i,cardConfig:a};Vs(e.target,"show-dialog",{dialogTag:"dialog-select-entities",dialogImport:()=>Promise.resolve().then(function(){return va}),dialogParams:o})}).then(e=>{e&&this._updateConfig({include:[...e.domains,...e.entities]})})}_customTagConfirmClick(e){let t=e.target;t=t.parentElement,t=t.parentElement;t.querySelector("ha-button").click();let i=String(this.customTagValue).trim();if(i.length){let e=[this._config.tags||[]].flat();e=[...new Set([...e,i])],this._updateConfig({tags:e})}this.customTagValue=""}_updateConfig(e){this._config&&(this._config=Object.assign(Object.assign({},this._config),e),Vs(this,"config-changed",{config:this._config}))}};Oa.styles=r`
    div.entities-list {
      max-height: 500px;
      overflow: auto;
    }
    div.row {
      display: flex;
      align-items: center;
      flex-direction: row;
      cursor: pointer;
      margin: 10px 0px;
    }
    div.row ha-icon {
      padding: 8px;
      color: var(--state-icon-color);
    }
    div.row ha-switch {
      padding: 13px 5px;
    }
    .info {
      margin-left: 16px;
      flex: 1 0 60px;
    }
    .info,
    .info > * {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    ha-input {
      width: 100%;
    }
    div.two-columns {
      display: flex;
      flex-direction: row;
    }
    div.two-columns .column {
      flex: 50%;
    }
    div.two-columns .column > * {
      display: flex;
      flex-direction: column;
    }
    scheduler-combo-selector {
      min-width: 240px;
    }
    ha-dropdown {
      display: block;
    }
    ha-checkbox {
      padding: 8px 0px;
    }
    div.radio {
      display: flex;
      flex-direction: row;
      align-items: center;
      font-size: 0.875rem;
      padding-bottom: 8px;
      gap: 8px;
    }
    div.radio > * {
      display: flex;
      cursor: pointer;
      user-select: none;
    }
    div.radio ha-icon {
      color: var(--ha-color-neutral-60);
      transition: color 0.1s ease-in-out;
      padding: 4px 0px;
    }
    div.radio ha-icon:hover {
      color: var(--ha-color-neutral-40);
    }
    div.radio ha-icon.checked {
      color: var(--ha-color-fill-primary-loud-resting);
    }
    div.radio ha-icon.checked:hover {
      color: var(--ha-color-fill-primary-loud-hover);
    }
  `,t([le({attribute:!1})],Oa.prototype,"hass",void 0),t([le()],Oa.prototype,"_config",void 0),t([le()],Oa.prototype,"title",void 0),t([le()],Oa.prototype,"tagOptions",void 0),t([ce()],Oa.prototype,"customTagValue",void 0),Oa=t([re("scheduler-card-editor")],Oa);const Sa=r`
  ha-dialog {
    --justify-action-buttons: space-between;
    --dialog-container-padding: var(--safe-area-inset-top, 0) var(--safe-area-inset-right, 0)
      var(--safe-area-inset-bottom, 0) var(--safe-area-inset-left, 0);
    --dialog-surface-padding: 0px;
    --dialog-content-padding: 0px;
  }
  /* make dialog fullscreen on small screens */
  @media all and (max-width: 450px), all and (max-height: 500px) {
    ha-dialog {
      --dialog-container-padding: 0px;
      --dialog-surface-padding: var(--safe-area-inset-top, 0) var(--safe-area-inset-right, 0)
        var(--safe-area-inset-bottom, 0) var(--safe-area-inset-left, 0);
      --vertical-align-dialog: flex-end;
      --ha-dialog-border-radius: var(--ha-border-radius-square);
    }
  }
  @media all and (min-width: 600px) and (min-height: 501px) {
    ha-dialog {
      --dialog-surface-margin-top: 40px;
      --vertical-align-dialog: flex-start;
    }
  }
  .buttons {
    box-sizing: border-box;
    display: flex;
    padding: 16px 24px;
    justify-content: space-between;
    background-color: var(--mdc-theme-surface, #fff);
    border-top: 1px solid var(--divider-color);
  }
  .content {
    padding: 0px 24px 16px 24px;
  }
`;r`
  .error {
    color: red;
  }
  .dl {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .dt {
    display: flex;
    align-content: center;
    flex-wrap: wrap;
  }
  .dd {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, auto) minmax(0, 2fr));
    margin: 0;
  }
  .toggle {
    padding: 0.6em;
    border: grey;
    border-radius: 50%;
  }
  .toggle.on {
    background-color: green;
  }
  .toggle.off {
    background-color: red;
  }
  .button {
    display: block;
    border: outset 0.2em;
    border-radius: 50%;
    border-color: silver;
    background-color: silver;
    width: 1.4em;
    height: 1.4em;
  }
  .value {
    padding-left: 0.5em;
    display: flex;
    align-content: center;
    flex-wrap: wrap;
  }
`;const za=(e,t,i,s)=>{var a;const o=e.service,n=null===(a=e.target)||void 0===a?void 0:a.entity_id,r=ps(e,s,i);if(!r||!r.fields||!Object.keys(r.fields).includes(t))return!1;const d=r.fields[t];if(null===fs(o,n,t,i,s))return!1;if(Object.keys(e.service_data||{}).includes(t))return!0;if(d.supported_features){if(![n||[]].flat().every(e=>{if(!Object.keys(i.states).includes(e))return!1;return((i.states[e].attributes.supported_features||0)&d.supported_features)>0}))return!1}return!("light"==Xi(o)&&![n||[]].flat().every(e=>{if(!Object.keys(i.states).includes(e))return!1;const s=i.states[e].attributes.supported_color_modes||[];return"brightness"!=t||s.filter(e=>"onoff"!=e).length}))};var Ca;!function(e){e.OverlappingTime="overlapping_time",e.MissingTargetEntity="missing_target_entity",e.MissingServiceParameter="missing_service_parameter",e.MissingAction="missing_action"}(Ca||(Ca={}));const Aa=(e,t,i)=>{let s=[];s=[...s,...e.entries.map(e=>((e,t)=>{const i=e.every((i,s)=>{const a=Ae(i.start,t),o=void 0===i.stop?a:Ae(i.stop,t)||86400;return!(a>o)&&e.every((e,i)=>i<=s||Ae(e.start,t)>=o)});return i?null:Ca.OverlappingTime})(e.slots,t)).filter(e=>null!==e)];let a=e.entries.map(e=>e.slots.map(e=>e.actions)).flat().flat();return a.length||(s=[...s,Ca.MissingAction]),s=[...s,...a.map(e=>((e,t,i)=>{var s;const a=ps(e,i,t);return(null==a?void 0:a.target)&&!(null===(s=e.target)||void 0===s?void 0:s.entity_id)?Ca.MissingTargetEntity:(null==a?void 0:a.fields)&&!Object.entries(a.fields).filter(([s])=>za(e,s,t,i)).every(([s,a])=>{var o,n;let r=fs(e.service,null===(o=e.target)||void 0===o?void 0:o.entity_id,s,t,i);const d=!(!r.number||!(null===(n=r.number)||void 0===n?void 0:n.optional))||a.optional;return!(!Object.keys(e.service_data).includes(s)&&!d||!Ze(e.service_data[s])&&!d)})?Ca.MissingServiceParameter:null})(e,t,i)).filter(e=>null!==e)],s.length?s.shift():null},Ea=e=>{const t=e=>e.actions.length?(e.stop||(e=Object.fromEntries(Object.entries(e).filter(([e])=>"stop"!=e))),e):null;e=Object.assign(Object.assign({},e),{entries:e.entries.map(e=>Object.assign(Object.assign({},e),{slots:e.slots.map(t).filter(e=>null!==e)}))});let i={weekdays:e.entries[0].weekdays.map(Ta),timeslots:e.entries[0].slots.map(Da),name:e.name,start_date:e.start_date,end_date:e.end_date,repeat_type:e.repeat_type,tags:e.tags||[]};return e.schedule_id&&(i=Object.assign(Object.assign({},i),{schedule_id:e.schedule_id})),i},Ta=e=>{switch(e){case pe.Monday:return"mon";case pe.Tuesday:return"tue";case pe.Wednesday:return"wed";case pe.Thursday:return"thu";case pe.Friday:return"fri";case pe.Saturday:return"sat";case pe.Sunday:return"sun";case pe.Workday:return"workday";case pe.Weekend:return"weekend";default:return"daily"}},Da=e=>({start:e.start,stop:e.stop,actions:e.actions.map(e=>Ma(e)).flat(),condition_type:e.conditions.items.length?e.conditions.type==_e.And?"and":"or":void 0,conditions:e.conditions.items.length?e.conditions.items:void 0,track_conditions:e.conditions.track_changes}),Ma=e=>{var t,i;const s=e=>Object.keys(e).filter(t=>Ze(e[t])).reduce((t,i)=>(t[i]=e[i],t),{});if(e.target){if(Array.isArray(null===(t=e.target)||void 0===t?void 0:t.entity_id)){let t=null==e?void 0:e.target.entity_id.map(t=>({service:e.service,service_data:s(e.service_data),entity_id:t}));return t}return{service:e.service,service_data:s(e.service_data),entity_id:null===(i=e.target)||void 0===i?void 0:i.entity_id}}return{service:e.service,service_data:s(e.service_data)}},La=(e,t,i)=>{const s={title:ns("state_badge.default.error",i),description:q`
      <b>Something went wrong!</b><br />
      ${e.body.message}<br /><br />
      ${e.error}<br /><br />
      Please <a href="https://github.com/nielsfaber/scheduler-card/issues">report</a> the bug.
    `,primaryButtonLabel:ns("ui.common.ok",i),confirm:()=>{},cancel:()=>{}};Vs(t,"show-dialog",{dialogTag:"scheduler-generic-dialog",dialogImport:()=>Promise.resolve().then(function(){return mo}),dialogParams:s})},Na=e=>{if(!Object.keys(e).includes("select")||!e.select){if(Object.keys(e).includes("number")&&e.number){const t=e.number.min;return void 0!==t?t:0}return Object.keys(e).includes("boolean")&&e.boolean?void 0:(Object.keys(e).includes("text")&&e.text,"")}e.select.options},Pa=(e,t)=>{const i=ps(e,t),s=Xi(e.service),a=Qi(e.service);if(i.icon)return(o=i.icon).match(/^[a-z]+\:[a-zA-Z\-]+$/)?o:`mdi:${o}`;if(Object.keys(ys).includes(s)&&Object.keys(ys[s].services).includes(a)){if(void 0!==ys[s].attributes){let t=ys[s].attributes;const i=Object.keys(t).find(t=>Object.keys(e.service_data).includes(t));if(i&&Object.keys(t[i]).includes(e.service_data[i]))return t[i][e.service_data[i]]}return ys[s].services[a]}return Object.keys(ys).includes(s)&&Object.keys(ys[s].services).includes("{entity_id}")?ys[s].services["{entity_id}"]:"mdi:flash";var o},Ia=(e,t,i)=>{let s=Ae("string"==typeof e?Ce(e):e,i),a=Ae("string"==typeof t?Ce(t):t,i);return a>s?1:a<s?-1:0},qa=e=>Ce(e.start),Ra=e=>{if(Ze(e.stop)){const t=Ce(e.stop);return 0==t.hours&&0==t.minutes&&t.mode==be.Fixed?Object.assign(Object.assign({},t),{hours:24}):t}return Se(qa(e),{minutes:1})},Va=(e,t,i,s)=>{let a=t;if(Ze(i.stop))return[e,a]=Va(e,t+1,{start:i.stop},s),[e,a-1];if(!Ze(i.start))return[e,a];let o=qa(e[t]),n=i.start,r=qa(e[t]);for(let i=t-1;i>=0;i--){if(e[i].actions.length){r=i==t-1?Se(qa(e[i]),{minutes:1}):Ra(e[i]);break}r=qa(e[i])}let d=Se(Ra(e[t]),{minutes:-1});if(!Ze(e[t].stop))for(let i=t+1;i<e.length;i++){if(e[i].actions.length){d=i==t+1?Se(Ra(e[i]),{minutes:-1}):qa(e[i]);break}d=Ra(e[i])}if(Ia(r,n,s)<0&&(n=r),Ia(d,n,s)>0&&Ae(d,s)>0&&(n=d),e=Object.assign(e,{[t]:Object.assign(Object.assign({},e[t]),{start:Ie(n)})}),Ia(o,n,s)<=0)for(let i=t-1;i>=0;i--){let t=Ia(qa(e[i]),n,s),o=Ia(Ra(e[i]),n,s);if(t>0&&o<=0){e=Object.assign(e,{[i]:Object.assign(Object.assign({},e[i]),{stop:Ie(n)})});break}if(o>=0)break;t<=0&&(e=Object.assign(e,{[i]:null}),a-=1)}if(Ia(o,n,s)<0&&!Ze(e[t].stop)&&(e=Ze(e[t+1].stop)&&!e[t+1].actions.length?Object.assign(e,{[t+1]:Object.assign(Object.assign({},e[t+1]),{start:Ie(Ra(e[t]))})}):[...e.slice(0,t+1),Object.assign(Object.assign({},e[t]),{start:Ie(Ra(e[t])),stop:Ie(qa(e[t+1])),actions:[]}),...e.slice(t+1)]),Ia(o,n,s)>=0)for(let t=a+1;t<e.length;t++){let i=Ra(e[a]),o=Ia(qa(e[t]),i,s),n=Ia(Ra(e[t]),i,s);if(o>=0&&n<0)e=Object.assign(e,{[t]:Object.assign(Object.assign({},e[t]),{start:Ie(i)})});else{if(o<0)break;n>=0&&(e=Object.assign(e,{[t]:null}))}}return Ia(o,n,s)>0&&(t>0&&Ze(e[t-1].stop)?e=Object.assign(e,{[t-1]:Object.assign(Object.assign({},e[t-1]),{stop:Ie(n)})}):(e=[...e.slice(0,t),Object.assign(Object.assign({},e[t]),{start:t>0?Ie(Ra(e[t-1])):"00:00:00",stop:Ie(n),actions:[]}),...e.slice(t)],a=t+1)),[e=e.filter(Ze),a]},Ha=(e,t)=>{const i=new Date(t),s=3600*i.getHours()+60*i.getMinutes()+i.getSeconds();let a=3600*e.hours+60*e.minutes-s;const o=a<0?-1:1;a=Math.abs(a);let n=Math.floor(a/3600),r=Math.round((a-3600*n)/60);return o<0&&(n>0&&(n=-n),r=-r),ze({hours:n,minutes:r})},Ua=86400;let Fa=class extends oe{constructor(){super(...arguments),this.selectedSlot=null,this._width=0,this.large=!1}connectedCallback(){super.connectedCallback(),this._resizeObserver=new ResizeObserver(e=>{for(const t of e){const e=t.contentRect.width;e!==this._width&&(this._width=e)}}),this._resizeObserver.observe(this)}disconnectedCallback(){var e;super.disconnectedCallback(),null===(e=this._resizeObserver)||void 0===e||e.disconnect()}render(){return q`
      <div class="bar">${this.renderTimeslots()}</div>
      <div class="time-bar">${this.renderTimebar()}</div>
    `}renderTimebar(){const e=this._width,t=[1,2,3,4,6,8,12],i=Me(this.hass.locale),s=i?130:100;if(!e)return q``;let a=Math.ceil(24/(e/s));for(;!t.includes(a);)a++;const o=[0,...Array.from(Array(24/a-1).keys()).map(e=>(e+1)*a),24];return o.map((e,t)=>{let s=a/24*100;s=Math.floor(100*s)/100;const n={mode:be.Fixed,hours:e,minutes:0};return 0==t?q`
          <span class="left" style=${oa({width:s/2+"%"})}
            >${Ie(n,{seconds:!1,am_pm:i})}</span
          >
        `:t==o.length-1?q`
          <span class="right" style=${oa({width:s/2+"%"})}
            >${Ie(n,{seconds:!1,am_pm:i})}</span
          >
        `:q`
          <span style=${oa({width:`${s}%`})}>${Ie(n,{seconds:!1,am_pm:i})}</span>
        `})}renderTimeslots(){const e=this.schedule.slots,t=this.computeSlotWidths();return e.map((i,s)=>{const a=i.actions.length?Ss(i.actions[0],this.hass,this.config.customize,!0,!0):"",o=5*a.length+10,n=s>0?15:0,r=s<e.length-1?15:0,d=t[s]-n-r,l=e[s+1];return q`
        <div
          class="slot ${this.selectedSlot==s?"selected":""} ${i.actions.length?"":"empty"} ${void 0===i.stop?"short":""}"
          style="${oa({width:`${t[s]}px`})}"
          @click=${this._toggleSelectTimeslot}
          idx="${s}"
        >
          ${i.stop,""}
          ${i.actions.length?a&&(d>o/3||d>50)&&d>30?q`<span style="margin-left: ${n}px; margin-right: ${r}px">${a}</span>`:d>16?q`<ha-icon icon="${Pa(i.actions[0],this.config.customize)}"></ha-icon>`:"":""}
        </div>
        ${s<e.length-1&&i.stop?q`
                <div
                  idx="${s}"
                  class="handle ${this.selectedSlot==s+1||this.selectedSlot==s?"":"hidden"} ${l&&!l.stop?"center":""}"
                >
                  <span>
                    <ha-icon-button
                      .path=${"M18.17,12L15,8.83L16.41,7.41L21,12L16.41,16.58L15,15.17L18.17,12M5.83,12L9,15.17L7.59,16.59L3,12L7.59,7.42L9,8.83L5.83,12Z"}
                      @mousedown=${this._handleDragStart}
                      @touchstart=${this._handleDragStart}
                    >
                    </ha-icon-button>
                  </span>
                </div>
              `:""}
      `})}computeSlotWidths(){const e=this._width,t=this.schedule.slots,i=e-3*(t.length-1),s=t.map((e,i)=>{const s=Ae(e.start,this.hass);let a;if(void 0!==e.stop)a=Ae(e.stop,this.hass),!a&&s&&(a=Ua);else{const e=t[i+1];a=e&&Ae(e.start,this.hass)||Ua}return(a-s)/Ua}),a=5/i,o=s.filter(e=>e<a).length,n=i-5*o,r=s.map(e=>e<a?5:e*n);return r}_toggleSelectTimeslot(e){let t=e.target;"div"!=t.tagName.toLowerCase()&&(t=t.parentElement);const i=Number(t.getAttribute("idx"));this.selectedSlot=this.selectedSlot!==i?i:null;const s=new CustomEvent("update",{detail:{selectedSlot:this.selectedSlot}});this.dispatchEvent(s),e.stopPropagation()}_handleDragStart(e){e.preventDefault(),e.stopPropagation();let t=e.target;for(;"DIV"!==t.tagName;)t=t.parentElement;const i=t.parentElement.getBoundingClientRect(),s=Number(t.getAttribute("idx")),a=this.config.time_step||15,o=60*a;let n=s>0?Ae(this.schedule.slots[s-1].stop||this.schedule.slots[s-1].start,this.hass)+o:o,r=(Ae(this.schedule.slots[s+1].stop||this.schedule.slots[s+1].start,this.hass)||Ua)-o;void 0===this.schedule.slots[s+1].stop&&(r=(Ae(this.schedule.slots[s+2].stop||this.schedule.slots[s+2].start,this.hass)||Ua)-o);const d=Ce(this.schedule.slots[s+1].start).mode;if([be.Sunrise,be.Sunset].includes(d)){const e=Ce(this.schedule.slots[s+1].start),t=Ae(Object.assign(Object.assign({},e),{hours:4,minutes:0}),this.hass),i=Ae(Object.assign(Object.assign({},e),{hours:-4,minutes:0}),this.hass);i>n&&(n=i),t<r&&(r=t)}let l=e=>{let t;e.preventDefault(),t="undefined"!=typeof TouchEvent&&e instanceof TouchEvent?e.changedTouches[0].pageX:e.pageX,t-=i.left,t>i.width&&(t=i.width),t<0&&(t=0);let o=Math.round(t/i.width*Ua);o<n?o=n:o>r&&(o=r);const l=Math.floor(o/3600),c=Math.round((o-3600*l)/60);let u={mode:be.Fixed,hours:l,minutes:c};if([be.Sunrise,be.Sunset].includes(d)){const e=d==be.Sunrise?this.hass.states["sun.sun"].attributes.next_rising:this.hass.states["sun.sun"].attributes.next_setting,t=Ha(u,e);u={mode:d,hours:t.hours,minutes:t.minutes}}u=ze(u,a);const h=Ie(u);let m=[...this.schedule.slots];if(m=Object.assign(m,{[s]:Object.assign(Object.assign({},m[s]),{stop:h}),[s+1]:Object.assign(Object.assign({},m[s+1]),{start:Ie(u)})}),void 0===m[s+1].stop){const e=Ie(Se(u,{minutes:1}));m=Object.assign(m,{[s+2]:Object.assign(Object.assign({},m[s+2]),{start:e})})}this.schedule=Object.assign(Object.assign({},this.schedule),{slots:m});const p=new CustomEvent("update",{detail:{slots:m}});this.dispatchEvent(p)};const c=e=>{e.preventDefault()},u=()=>{window.removeEventListener("mousemove",l),window.removeEventListener("touchmove",l),window.removeEventListener("mouseup",u),window.removeEventListener("touchend",u),window.removeEventListener("blur",u),window.removeEventListener("dragstart",c),l=()=>{}};window.addEventListener("mouseup",u),window.addEventListener("touchend",u),window.addEventListener("blur",u),window.addEventListener("dragstart",c),window.addEventListener("mousemove",l),window.addEventListener("touchmove",l)}static get styles(){return r`
      :host {
        display: block;
        max-width: 100%;
        overflow: hidden;
      }
      .bar {
        width: 100%;
        height: 60px;
        display: flex;
      }
      .time-bar {
        width: 100%;
        height: 18px;
        display: flex;
      }
      .time-bar span {
        display: flex;
        justify-content: center;
        white-space: nowrap;
      }
      .time-bar span.left {
        justify-content: left;
      }
      .time-bar span.right {
        justify-content: right;
      }

      .slot {
        display: flex;
        height: 100%;
        box-sizing: border-box;
        cursor: pointer;
        background: rgba(var(--rgb-primary-color), 0.7);
        color: var(--text-primary-color);
        font-weight: 500;
        align-items: center;
        justify-content: center;
        word-break: break-all;
        white-space: normal;
        margin-right: 3px;
      }
      .slot:hover {
        background: rgba(var(--rgb-primary-color), 0.85);
      }
      .slot.selected {
        border: 3px solid rgba(var(--rgb-primary-color), 0.85);
      }
      .slot.selected:hover {
        border: 3px solid rgba(var(--rgb-primary-color), 1);
      }
      .slot:first-child {
        border-radius: 10px 0px 0px 10px;
      }
      .slot:last-child {
        border-radius: 0px 10px 10px 0px;
        margin-right: 0px;
      }
      .slot.empty {
        background: rgba(var(--rgb-secondary-text-color), 0.5);
      }
      .slot.empty:hover {
        background: rgba(var(--rgb-secondary-text-color), 0.65);
      }
      .slot.empty.selected {
        border: 3px solid rgba(var(--rgb-secondary-text-color), 0.65);
      }
      .slot.empty.selected:hover {
        border: 3px solid rgba(var(--rgb-secondary-text-color), 1);
      }
      .slot .marker {
        width: 24px;
        height: 24px;
        background: rgba(var(--rgb-primary-color), 0.85);
        margin-top: -80px;
        position: absolute;
        transform: rotate(45deg);
        border-radius: 12px 12px 0px 12px;
      }
      .slot .marker:hover {
        background: rgba(var(--rgb-primary-color), 1);
      }
      .slot.empty .marker {
        background: rgba(var(--rgb-secondary-text-color), 0.85);
      }
      .slot.empty .marker:hover {
        background: rgba(var(--rgb-secondary-text-color), 1);
      }
      .handle {
        display: flex;
        width: 36px;
        height: 100%;
        align-content: center;
        align-items: center;
        justify-content: center;
        margin-left: -18px;
        margin-right: -18px;
        visibility: visible;
      }
      .handle.hidden {
        visibility: hidden;
      }
      .handle span {
        background: var(--card-background-color);
        border-radius: 50%;
        width: 24px;
        height: 24px;
        display: flex;
        z-index: 5;
      }
      .handle ha-icon-button {
        --mdc-icon-button-size: 36px;
        margin-top: -12px;
        margin-left: -12px;
      }
      .handle.center span {
        margin-right: -2px;
      }
    `}};t([le({attribute:!1})],Fa.prototype,"config",void 0),t([ce()],Fa.prototype,"schedule",void 0),t([ce()],Fa.prototype,"selectedSlot",void 0),t([ce()],Fa.prototype,"_width",void 0),t([le({type:Boolean})],Fa.prototype,"large",void 0),Fa=t([re("scheduler-timeslot-editor")],Fa);const Ba=e=>{const t=60*e.hours+e.minutes;return t>240?e=Object.assign(Object.assign({},e),{hours:4,minutes:0}):t<-240&&(e=Object.assign(Object.assign({},e),{hours:-4,minutes:0})),e};let Wa=class extends oe{constructor(){super(...arguments),this.hours=0,this.minutes=0,this.mode=be.Fixed,this.autoValidate=!0,this.required=!0,this.disabled=!1,this.label="",this.useAmPm=!1,this.large=!1,this.stepSize=10}set time(e){const t=Ce(e);this.mode=t.mode,this.hours=t.hours,this.minutes=t.minutes}render(){return q`
      <div class="time-input-wrap">
        <div class="input">
          ${this.label?q`<span class="label">${this.label}</span>`:V}
          ${this.large?V:this._renderTimeMode()}
          <div class="hours">
            ${this.large?q`
                    <ha-button
                      appearance="plain"
                      @click=${()=>this._addTimeOffset({hours:1})}
                      ?disabled=${this.mode!=be.Fixed&&4==this.hours}
                    >
                      <ha-icon icon="mdi:chevron-up"></ha-icon>
                    </ha-button>
                  `:V}
            <ha-input
              id="hour"
              inputmode="numeric"
              .value=${this.formatHours()}
              label=""
              name="hours"
              @change=${this._hoursChanged}
              @focusin=${this._onFocus}
              .required=${this.required}
              .autoValidate=${this.autoValidate}
              maxlength="2"
              max=${this.mode==be.Fixed?this.useAmPm?12:23:4}
              min=${this.mode==be.Fixed||this.large?0:-4}
              .disabled=${this.disabled}
              .validityTransform=${(e,t)=>{const i=null!==e.match(/^[1|2]?[0-9]$/);return{valid:i,customError:!i}}}
            >
            </ha-input>
            ${this.large?q`
                    <ha-button
                      appearance="plain"
                      @click=${()=>this._addTimeOffset({hours:-1})}
                      ?disabled=${this.mode!=be.Fixed&&-4==this.hours}
                    >
                      <ha-icon icon="mdi:chevron-down"></ha-icon>
                    </ha-button>
                  `:V}
          </div>
          <div class="time-separator">:</div>
          <div class="minutes">
            ${this.large?q`
                    <ha-button
                      appearance="plain"
                      @click=${()=>this._addTimeOffset({minutes:this.stepSize})}
                      ?disabled=${this.mode!=be.Fixed&&4==this.hours}
                    >
                      <ha-icon icon="mdi:chevron-up"></ha-icon>
                    </ha-button>
                  `:V}
            <ha-input
              id="min"
              inputmode="numeric"
              .value=${this.formatMinutes()}
              label=""
              @change=${this._minutesChanged}
              @focusin=${this._onFocus}
              name="minutes"
              .required=${this.required}
              .autoValidate=${this.autoValidate}
              maxlength="2"
              max="59"
              min="0"
              .disabled=${this.disabled}
              .validityTransform=${(e,t)=>{const i=null!==e.match(/^[0-5]?[0-9]$/);return{valid:i,customError:!i}}}
            >
            </ha-input>
            ${this.large?q`
                    <ha-button
                      appearance="plain"
                      @click=${()=>this._addTimeOffset({minutes:-this.stepSize})}
                      ?disabled=${this.mode!=be.Fixed&&-4==this.hours}
                    >
                      <ha-icon icon="mdi:chevron-down"></ha-icon>
                    </ha-button>
                  `:V}
          </div>
          ${this._renderSuffix()} ${this.large?this._renderTimeMode():V}
        </div>
      </div>
    `}_renderTimeMode(){if(!this.hass.states["sun.sun"])return V;if(this.large){const e=()=>{let e=this._convertTimeMode();e.mode!=be.Fixed&&(e=Ba(e)),this.mode=e.mode,this.hours=e.hours,this.minutes=e.minutes,this._valueChanged()};return q`
        <div class="mode">
          ${this.hass.states["sun.sun"]?q`
                  <ha-button
                    appearance="${this.mode==be.Fixed?"plain":"accent"}"
                    variant="${this.mode==be.Fixed?"neutral":"brand"}"
                    @click=${e}
                  >
                    <ha-icon icon="mdi:theme-light-dark"></ha-icon>
                  </ha-button>
                `:V}
        </div>
      `}{const e=[be.Fixed,be.Sunrise,be.Sunset],t={[be.Fixed]:ns("ui.components.selectors.selector.types.time",this.hass),[be.Sunrise]:ns("ui.panel.config.automation.editor.triggers.type.sun.sunrise",this.hass),[be.Sunset]:ns("ui.panel.config.automation.editor.triggers.type.sun.sunset",this.hass)},i={[be.Fixed]:"mdi:clock-outline",[be.Sunrise]:"mdi:weather-sunset-up",[be.Sunset]:"mdi:weather-sunset-down"},s={[be.Fixed]:"M12,20A8,8 0 0,0 20,12A8,8 0 0,0 12,4A8,8 0 0,0 4,12A8,8 0 0,0 12,20M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22C6.47,22 2,17.5 2,12A10,10 0 0,1 12,2M12.5,7V12.25L17,14.92L16.25,16.15L11,13V7H12.5Z",[be.Sunrise]:"M3,12H7A5,5 0 0,1 12,7A5,5 0 0,1 17,12H21A1,1 0 0,1 22,13A1,1 0 0,1 21,14H3A1,1 0 0,1 2,13A1,1 0 0,1 3,12M15,12A3,3 0 0,0 12,9A3,3 0 0,0 9,12H15M12,2L14.39,5.42C13.65,5.15 12.84,5 12,5C11.16,5 10.35,5.15 9.61,5.42L12,2M3.34,7L7.5,6.65C6.9,7.16 6.36,7.78 5.94,8.5C5.5,9.24 5.25,10 5.11,10.79L3.34,7M20.65,7L18.88,10.79C18.74,10 18.47,9.23 18.05,8.5C17.63,7.78 17.1,7.15 16.5,6.64L20.65,7M12.71,16.3L15.82,19.41C16.21,19.8 16.21,20.43 15.82,20.82C15.43,21.21 14.8,21.21 14.41,20.82L12,18.41L9.59,20.82C9.2,21.21 8.57,21.21 8.18,20.82C7.79,20.43 7.79,19.8 8.18,19.41L11.29,16.3C11.5,16.1 11.74,16 12,16C12.26,16 12.5,16.1 12.71,16.3Z",[be.Sunset]:"M3,12H7A5,5 0 0,1 12,7A5,5 0 0,1 17,12H21A1,1 0 0,1 22,13A1,1 0 0,1 21,14H3A1,1 0 0,1 2,13A1,1 0 0,1 3,12M15,12A3,3 0 0,0 12,9A3,3 0 0,0 9,12H15M12,2L14.39,5.42C13.65,5.15 12.84,5 12,5C11.16,5 10.35,5.15 9.61,5.42L12,2M3.34,7L7.5,6.65C6.9,7.16 6.36,7.78 5.94,8.5C5.5,9.24 5.25,10 5.11,10.79L3.34,7M20.65,7L18.88,10.79C18.74,10 18.47,9.23 18.05,8.5C17.63,7.78 17.1,7.15 16.5,6.64L20.65,7M12.71,20.71L15.82,17.6C16.21,17.21 16.21,16.57 15.82,16.18C15.43,15.79 14.8,15.79 14.41,16.18L12,18.59L9.59,16.18C9.2,15.79 8.57,15.79 8.18,16.18C7.79,16.57 7.79,17.21 8.18,17.6L11.29,20.71C11.5,20.9 11.74,21 12,21C12.26,21 12.5,20.9 12.71,20.71Z"},a=e=>{if(e==be.Fixed)return!1;const t=this._convertTimeMode(e);return Math.abs(60*t.hours+t.minutes)>240};return q`
        <ha-dropdown
          @wa-select=${e=>{const t=e.detail.item.value;if(this.mode==t)return;const i=this._convertTimeMode(t);this.hours=i.hours,this.minutes=i.minutes,this.mode=t,this._valueChanged()}}
          @wa-after-hide=${e=>{e.target.firstElementChild.blur()}}
          ?disabled=${this.disabled}
        >
          <ha-icon-button slot="trigger" .path=${s[this.mode]} ?disabled=${this.disabled}> </ha-icon-button>
          ${e.map(e=>q`
              <ha-dropdown-item
                ?noninteractive=${this.mode==e}
                ?disabled=${a(e)&&this.mode!=e}
                value="${e}"
              >
                <ha-icon icon="${i[e]}"></ha-icon>
                ${t[e]}
              </ha-dropdown-item>
            `)}
        </ha-dropdown>
      `}}_renderSuffix(){if(this.large){const e=()=>{const e=Ne(this.hours).am_pm,t=Ne(this.hours).hours;this.hours=Pe(t,"AM"==e?Le.PM:Le.AM),this._valueChanged()},t=()=>{0!=this.hours?this.hours=-this.hours:this.minutes=-this.minutes,this._valueChanged()},i=()=>{this.mode=this.mode==be.Sunrise?be.Sunset:be.Sunrise,this._valueChanged()};return q`
        <div class="suffix">
          ${this.useAmPm&&this.mode==be.Fixed?q`
                  <ha-button appearance="plain" @click=${e}>
                    <span class="large"> ${Ne(this.hours).am_pm==Le.AM?"AM":"PM"} </span>
                  </ha-button>
                `:V}
          ${this.mode!=be.Fixed?q`
                  <ha-button appearance="plain" size="large" @click=${t}>
                    <span class="large">
                      ${this.hours<0||this.minutes<0?this.hass.localize("ui.panel.config.automation.editor.conditions.type.sun.before").trim().toLowerCase():this.hass.localize("ui.panel.config.automation.editor.conditions.type.sun.after").trim().toLowerCase()}
                    </span>
                  </ha-button>
                  <ha-button appearance="plain" @click=${i}>
                    <ha-icon
                      icon="${this.mode==be.Sunrise?"mdi:weather-sunny":"mdi:weather-night"}"
                    ></ha-icon>
                  </ha-button>
                `:V}
        </div>
      `}return this.useAmPm&&this.mode==be.Fixed?q`
        <ha-select
          .required=${this.required}
          .value=${Ne(this.hours).am_pm==Le.AM?"AM":"PM"}
          .disabled=${this.disabled}
          name="amPm"
          naturalMenuWidth
          fixedMenuPosition
          @selected=${this._amPmChanged}
          @closed=${e=>{e.stopPropagation()}}
        >
          <ha-dropdown-item value="AM">AM</ha-dropdown-item>
          <ha-dropdown-item value="PM">PM</ha-dropdown-item>
        </ha-select>
      `:V}_convertTimeMode(e){const t=this.hass.states["sun.sun"].attributes.next_rising,i=this.hass.states["sun.sun"].attributes.next_setting;if(e&&e!=be.Fixed||this.mode==be.Fixed){const s=Ha({hours:this.hours,minutes:this.minutes},t),a=Ha({hours:this.hours,minutes:this.minutes},i),o=60*s.hours+s.minutes,n=60*a.hours+a.minutes,r=e||(Math.abs(o)<=Math.abs(n)?be.Sunrise:be.Sunset),d=r==be.Sunrise?s:a;return{mode:r,hours:d.hours,minutes:d.minutes}}{let e=this.mode==be.Sunrise?Ce(t):Ce(i);return e=Se(e,{hours:this.hours,minutes:this.minutes}),{mode:be.Fixed,hours:e.hours,minutes:e.minutes}}}_hoursChanged(e){let t=Number(e.target.value);if(this.useAmPm){const e=Ne(this.hours).am_pm;t=Pe(t,e)}this.hours=t,this._valueChanged()}_minutesChanged(e){const t=Number(e.target.value);this.minutes=t,this._valueChanged()}_amPmChanged(e){const t=e.detail.value;if(Ne(this.hours).am_pm==t)return;const i=Ne(this.hours).hours;this.hours=Pe(i,"AM"==t?Le.AM:Le.PM),this._valueChanged()}_addTimeOffset(e){let t={mode:this.mode,hours:this.hours,minutes:this.minutes};t=Se(t,e),e.minutes&&(t=ze(t,this.stepSize)),this.mode!=be.Fixed&&(t=Ba(t)),this.hours=t.hours,this.minutes=t.minutes,this._valueChanged()}_valueChanged(){const e={mode:this.mode,hours:this.hours,minutes:this.minutes};Vs(this,"value-changed",{value:e})}_onFocus(e){e.currentTarget.select()}formatHours(){const e=this.hours<0||this.minutes<0,t=this.useAmPm&&this.mode==be.Fixed?Ne(this.hours).hours:this.hours;return e&&!this.large?"-"+Math.abs(t).toFixed():this.mode==be.Fixed||this.large?this.large?Math.abs(t):t.toFixed():"+"+Math.abs(t).toFixed()}formatMinutes(){return Math.abs(this.minutes).toString().padStart(2,"0")}};Wa.styles=r`
    :host {
      display: flex;
      flex-direction: row;
      flex-wrap: wrap;
      column-gap: 4px;
      align-items: center;
    }
    .time-input-wrap {
      display: flex;
      border-radius: var(--mdc-shape-small, 4px) var(--mdc-shape-small, 4px) 0 0;
      overflow: hidden;
      position: relative;
      direction: ltr;
    }
    :host([large]) .time-input-wrap {
      width: 100%;
    }
    div.input {
      display: flex;
    }
    :host([large]) div.input {
      width: 100%;
    }
    div.hours,
    div.minutes {
      display: flex;
      flex-direction: column;
      width: min-content;
    }
    div.hours ha-icon,
    div.minutes ha-icon {
      --mdc-icon-size: 42px;
    }
    .time-separator {
      background-color: var(--ha-color-form-background);
      color: var(--ha-color-text-secondary);
      border-bottom: 1px solid var(--ha-color-border-neutral-loud);
      box-sizing: border-box;
      height: 56px;
      width: 9px;
      display: flex;
      align-items: center;
      align-self: center;
      justify-content: center;
      font-size: 16px;
      font-weight: 600;
    }
    :host([disabled]) .time-separator {
      background-color: var(--ha-color-form-background-disabled);
      opacity: 0.5;
    }
    :host([large]) .time-separator {
      background: none;
      border: none;
      font-size: 36px;
    }
    ha-input {
      width: 40px;
      --mdc-shape-small: 0;
      --text-field-appearance: none;
      --text-field-padding-top: 0;
      --text-field-padding-bottom: 0;
      --text-field-padding-start: 4px;
      --text-field-padding-end: 4px;
      --text-field-suffix-padding-left: 2px;
      --text-field-suffix-padding-right: 0;
      --ha-input-text-align: center;
      --ha-input-padding-top: 0px;
      --ha-input-padding-bottom: 0px;
    }
    ha-input::part(wa-input) {
      text-align: center;
    }
    ha-input::part(wa-hint) {
      height: 0;
      min-height: 0;
    }
    ha-input::part(wa-base) {
      padding: var(--ha-space-1);
    }
    ha-input#hour::part(wa-base) {
      border-top-right-radius: 0px;
    }
    ha-input#min::part(wa-base) {
      border-top-left-radius: 0px;
    }
    :host([large]) ha-input#hour::part(wa-base),
    :host([large]) ha-input#min::part(wa-base) {
      border-top-right-radius: var(--ha-border-radius-sm);
      border-top-left-radius: var(--ha-border-radius-sm);
    }
    :host([large]) ha-input {
      width: 75px;
      --wa-form-control-value-font-size: 42px;
    }
    div.suffix {
      display: flex;
      flex-direction: row;
      flex-grow: 1;
      align-items: center;
      flex-wrap: wrap;
      align-content: center;
    }
    div.mode {
      display: flex;
      align-items: center;
    }
    :host([large]) div.suffix ha-icon,
    :host([large]) div.mode ha-icon {
      --mdc-icon-size: 32px;
    }
    ha-select {
      --mdc-shape-small: 0;
      width: 90px;
    }
    .label {
      display: flex;
      justify-content: center;
      align-self: center;
      white-space: nowrap;
    }
    ha-dropdown-menu {
      display: flex;
      align-items: flex-end;
      margin-right: 4px;
      padding-bottom: 4px;
    }
    ha-dropdown-menu ha-icon-button {
      color: var(--secondary-text-color);
    }
    ha-dropdown-item[disabled] ha-icon {
      color: var(--disabled-text-color);
    }
    ha-dropdown-item[noninteractive] {
      background-color: rgba(var(--rgb-primary-color), 0.12);
      color: var(--sidebar-selected-text-color);
    }
    ha-dropdown-item[noninteractive] ha-icon {
      color: var(--sidebar-selected-text-color);
    }
    ha-button {
      --ha-button-border-radius: 8px;
      --button-color-fill-loud-hover: var(--ha-color-primary-50);
    }
    ha-button span.large {
      font-size: 16px;
      text-transform: uppercase;
    }
    @media all and (max-width: 450px), all and (max-height: 500px) {
      ha-button {
        --wa-form-control-padding-inline: 10px;
      }
    }
  `,t([le({attribute:!1})],Wa.prototype,"hass",void 0),t([ce()],Wa.prototype,"hours",void 0),t([ce()],Wa.prototype,"minutes",void 0),t([ce()],Wa.prototype,"mode",void 0),t([le({type:Boolean})],Wa.prototype,"autoValidate",void 0),t([le({type:Boolean})],Wa.prototype,"required",void 0),t([le({type:Boolean})],Wa.prototype,"disabled",void 0),t([le({type:String})],Wa.prototype,"label",void 0),t([le({type:Boolean})],Wa.prototype,"useAmPm",void 0),t([le({type:Boolean})],Wa.prototype,"large",void 0),t([le({attribute:!1})],Wa.prototype,"stepSize",void 0),Wa=t([re("scheduler-time-picker")],Wa);const Za="Custom";let Ka=class extends oe{constructor(){super(...arguments),this.weekdayTypeCustomSelected=!1,this.selectedWeekdays=[]}async showDialog(e){this._params=e,await this.updateComplete,this.selectedWeekdays=this._params.weekdays.filter(e=>![pe.Daily,pe.Weekend,pe.Workday].includes(e)),this.weekdayTypeCustomSelected=this.selectedWeekdays.length>0&&this._params.weekdays.length==this.selectedWeekdays.length}async closeDialog(){this._params&&this._params.cancel(),this._params=void 0}render(){return this._params?q`
      <ha-dialog open @closed=${this.closeDialog} width="small">
        <ha-dialog-header slot="header">
          ${this.weekdayTypeCustomSelected?q`
                  <ha-icon-button
                    slot="navigationIcon"
                    .label=${ns("ui.dialogs.more_info_control.dismiss",this.hass)}
                    .path=${Bs}
                    @click=${this.backClick}
                  ></ha-icon-button>
                `:q`
                  <ha-icon-button
                    slot="navigationIcon"
                    data-dialog="close"
                    .label=${ns("ui.dialogs.more_info_control.dismiss",this.hass)}
                    .path=${Ws}
                  ></ha-icon-button>
                `};
          <div slot="title">${Ji("ui.dialog.weekday_picker.title",this.hass)}</div>
        </ha-dialog-header>
        <div class="wrapper">
          <div class="list" role="list">${this._renderWeekdayOptions()}</div>
        </div>

        <ha-dialog-footer slot="footer">
          <ha-button appearance="plain" slot="secondaryAction" @click=${this.cancelClick} data-dialog="close">
            ${ns("ui.common.cancel",this.hass)}
          </ha-button>
          <ha-button
            appearance="accent"
            slot="primaryAction"
            @click=${this.confirmClick}
            data-dialog="close"
            ?disabled=${!this._params.weekdays.length}
          >
            ${ns("ui.common.ok",this.hass)}
          </ha-button>
        </ha-dialog-footer>
      </ha-dialog>
    `:q``}_renderWeekdayOptions(){let e=[];if(this.weekdayTypeCustomSelected){e=[pe.Sunday,pe.Monday,pe.Tuesday,pe.Wednesday,pe.Thursday,pe.Friday,pe.Saturday];const t=(e,t)=>e.concat(e).slice(t,t+e.length);e=t(e,Ds(this.hass))}else e=[pe.Daily,pe.Workday,pe.Weekend,Za];const t=e=>{var t,i;return e==Za?null===(t=this._params)||void 0===t?void 0:t.weekdays.some(e=>![pe.Daily,pe.Weekend,pe.Workday].includes(e)):null===(i=this._params)||void 0===i?void 0:i.weekdays.includes(e)};return e.map(e=>q`
        <scheduler-list-item
          graphic="icon"
          @click=${this._toggleSelectOption}
          option="${e}"
          ?hasMeta=${e==Za}
        >
          ${t(e)?q`<ha-icon slot="graphic" icon="mdi:check"></ha-icon>`:""}
          ${e==Za?q`
                  ${os(Ji("ui.dialog.weekday_picker.choose",this.hass))}
                  ${this.selectedWeekdays.length?q`<span class="badge">${this.selectedWeekdays.length}</span>`:""}
                `:os(Ts(e,"long",this.hass))}
          ${e==Za?q`<ha-icon slot="meta" icon="mdi:chevron-right"></ha-icon>`:""}
        </scheduler-list-item>
      `)}_toggleSelectOption(e){const t=e.target.getAttribute("option");let i=[...this._params.weekdays];t==Za?(i=this.selectedWeekdays,this.weekdayTypeCustomSelected=!0):[pe.Daily,pe.Weekend,pe.Workday].includes(t)?(i.includes(t)?i.length>1&&(i=i.filter(e=>e!=t)):i=[t],this.weekdayTypeCustomSelected=!1):i=i.includes(t)?i.filter(e=>e!=t):[...i,t],this._params=Object.assign(this._params,{weekdays:i}),e.target.blur(),this.requestUpdate()}confirmClick(){const e=Array.from(new Set(this._params.weekdays));this._params.confirm(e)}cancelClick(){this._params.cancel()}backClick(){this.weekdayTypeCustomSelected=!1,this.selectedWeekdays=this._params.weekdays.filter(e=>![pe.Daily,pe.Weekend,pe.Workday].includes(e))}static get styles(){return r`
      div.wrapper {
        color: var(--primary-text-color);
        padding: 0px 12px;
      }
      .list {
        padding: 0px;
      }
      scheduler-list-item[disabled] {
        color: var(--disabled-text-color);
      }
      scheduler-list-item.nested {
        --scheduler-list-side-padding: 36px;
      }
      .badge {
        height: 24px;
        border-radius: 12px;
        background: rgba(var(--rgb-primary-color), 0.3);
        line-height: 1.25rem;
        font-size: 0.875rem;
        font-weight: 400;
        padding: 0px 12px;
        display: inline-flex;
        align-items: center;
        box-sizing: border-box;
        margin: 0px 16px;
      }
    `}};t([le({attribute:!1})],Ka.prototype,"hass",void 0),t([ce()],Ka.prototype,"_params",void 0),t([ce()],Ka.prototype,"weekdayTypeCustomSelected",void 0),t([ce()],Ka.prototype,"selectedWeekdays",void 0),Ka=t([re("dialog-select-weekdays")],Ka);var Ga=Object.freeze({__proto__:null,get DialogSelectWeekdays(){return Ka}});const Ja=(e,t)=>((e,t)=>e<t?-1:e>t?1:0)(e.toLowerCase(),t.toLowerCase()),Ya=(e,t,i)=>{const s=Object.keys(e.services).includes(t)?Object.keys(e.services[t]).filter(e=>{if(!Object.keys(ls).includes(t))return!1;let s=Object.keys(ls[t]).includes(e);if(!s&&Object.keys(ls[t]).includes("{entity_id}")){if("script"==t&&["turn_on","turn_off","reload","toggle","test"].includes(e))return!1;s=is(`${t}.${e}`,i)}return s}):[],a=t=>ns(`component.${t}.title`,e,!1)||t.replace(/_/g," "),o=s=>{let o=os(Ss({service:`${t}.${s}`,service_data:{}},e,i.customize));return"script"==t?Object.keys(i.customize||{}).includes(`${t}.${s}`)&&Ze(i.customize[`${t}.${s}`].name)?Ns(`${t}.${s}`,e,i.customize):`${os(Ns(`${t}.${s}`,e,i.customize))}: ${o}`:`${a(t)}: ${o}`},n=i=>{let s=ns(`component.${t}.services.${i}.description`,e,!1);return s||(s=e.services[t][i].description),s||"script"!=t||(s=ns(`component.${t}.services.turn_on.description`,e,!1)),s};let r=s.map(s=>{return{key:s,name:o(s),description:n(s),icon:(a=s,"script"==t&&Object.keys(i.customize||{}).includes(`${t}.${a}`)&&Ze(i.customize[`${t}.${a}`].icon)?i.customize[`${t}.${a}`].icon:Object.keys(ys).includes(t)&&Object.keys(ys[t].services).includes(a)?ys[t].services[a]:Ys(t)),action:{service:s.includes(".")?s:`${t}.${s}`,service_data:{},target:e.services[t][s].target?{}:void 0}};var a}),d=(l=i.customize||{},c=t,Object.keys(l).filter(e=>{var t;return null===(t=l[e].exclude_actions)||void 0===t?void 0:t.length}).filter(e=>!c||!c.includes(".")&&ts(Xi(e),c)||ts(e,c)).map(e=>l[e].exclude_actions).flat().filter(Ze));var l,c;return d.length&&(r=r.filter(t=>!d.some(s=>Ja(Qi(t.action.service),s)>0||Ja(Ss(t.action,e,i.customize),s)>0))),ms(i.customize||{},t).forEach(e=>{let i=e.service;for(;r.find(e=>e.key==i);)i+="_2";e.variables&&Object.entries(e.variables).forEach(([t,i])=>{let s=ks(i),a=Na(s);!Ze(e.service_data[t])&&Ze(a)?e=Object.assign(Object.assign({},e),{service_data:Object.assign(Object.assign({},e.service_data),{[t]:a})}):Ze(e.service_data[t])||(e=Object.assign(Object.assign({},e),{service_data:Object.assign(Object.assign({},e.service_data),{[t]:null})}))}),r.push({key:i,name:`${a(t)}: ${Qa(e.name||o(Qi(e.service)))}`,description:Qa(e.name||""),icon:e.icon||Ys(t),action:{service:e.service.includes(".")?e.service:`${t}.${e.service}`,service_data:e.service_data||{},target:e.target?e.target:void 0,name:e.name,icon:e.icon}})}),r},Qa=e=>{if(null!==/<.+?>/g.exec(e)){e=(new DOMParser).parseFromString(e,"text/html").body.textContent||""}let t;for(;t=/\[([^\]]+)\]/.exec(e);)e=e.replace(t[0],"");for(;t=/\{([^\}]+)\}/.exec(e);)e=e.replace(t[0],"");return e};let Xa=class extends oe{constructor(){super(...arguments),this._search="",this._filter="",this.timer=0,this.lockDomain=!1,this.showAll=!1}async showDialog(e){this._params=e,this.lockDomain=void 0!==e.domainFilter,this.showAll=!1,await this.updateComplete}async closeDialog(){this._params&&this._params.cancel(),this._params=void 0,this._clearSearch(),this._height=void 0,this._width=void 0}async willUpdate(){this.hass.loadBackendTranslation("title"),this.hass.loadBackendTranslation("services")}render(){return this._params?q`
      <ha-dialog open @closed=${this.closeDialog} @wa-after-show=${this._opened}>
        <div slot="header">
          <ha-dialog-header>
            ${void 0===this._params.domainFilter||this.lockDomain?q`
                    <ha-icon-button
                      slot="navigationIcon"
                      data-dialog="close"
                      .label=${ns("ui.dialogs.more_info_control.dismiss",this.hass)}
                      .path=${Ws}
                    ></ha-icon-button>
                  `:q`
                    <ha-icon-button
                      slot="navigationIcon"
                      .label=${ns("ui.common.back",this.hass)}
                      .path=${Bs}
                      @click=${this._clearDomain}
                    ></ha-icon-button>
                  `}
            <div slot="title">${Ji("ui.dialog.action_picker.title",this.hass)}</div>
            ${!this.lockDomain&&Ze(this._params.cardConfig.include)?q` <ha-dropdown
                    placement="bottom-end"
                    slot="actionItems"
                    @wa-after-hide=${e=>{e.target.firstElementChild.blur()}}
                  >
                    <ha-icon-button
                      slot="trigger"
                      .label=${this.hass.localize("ui.common.menu")}
                      .path=${Zs}
                    >
                    </ha-icon-button>
                    <ha-dropdown-item @click=${this._toggleShowAll}>
                      <ha-icon icon="mdi:check" style="${this.showAll?"":"visibility: hidden"}"></ha-icon>
                      ${Ji("ui.dialog.action_picker.show_all",this.hass)}
                    </ha-dropdown-item>
                  </ha-dropdown>`:""}
          </ha-dialog-header>

          <ha-input
            dialogInitialFocus
            .placeholder=${ns("ui.common.search",this.hass)}
            aria-label=${ns("ui.common.search",this.hass)}
            @input=${this._handleSearchChange}
            .value=${this._search}
            icon
            .iconTrailing=${this._search}
          >
            <div class="trailing" slot="trailingIcon">
              ${this._search&&q`
                  <ha-icon-button
                    @click=${this._clearSearch}
                    .label=${ns("ui.common.clear",this.hass)}
                    .path=${Ws}
                    class="clear-button"
                  ></ha-icon-button>
                `}
              <slot name="suffix"></slot>
            </div>
          </ha-input>
        </div>

        <div
          class="list"
          role="list"
          style=${oa({minWidth:`${this._width}px`,height:this._height?`${Math.min(468,this._height)}px`:"auto"})}
        >
          ${this._renderOptions()}
        </div>
      </ha-dialog>
    `:q``}_opened(){var e;const t=null===(e=this.shadowRoot.querySelector(".list"))||void 0===e?void 0:e.getBoundingClientRect();this._width=null==t?void 0:t.width,this._height=null==t?void 0:t.height}_handleSearchChange(e){const t=e.currentTarget.value;this._search=t,clearTimeout(this.timer),this.timer=window.setTimeout(()=>{this._filter=this._search},100)}_renderOptions(){var e,t;if(null===(e=this._params)||void 0===e?void 0:e.domainFilter)return this._renderDomainActions();let i=Object.assign({},null===(t=this._params)||void 0===t?void 0:t.cardConfig);this.showAll&&(i=Object.assign(Object.assign({},i),{include:void 0,exclude:void 0}));const s=Qs(this.hass,i);return 1===s.length?(this._params=Object.assign(Object.assign({},this._params),{domainFilter:[s[0].key]}),this._renderDomainActions()):this._renderDomainList(s)}_renderDomainList(e){e.sort((e,t)=>as(e.name,t.name)),this._filter&&(e=e.filter(e=>{const t=this._filter.toLowerCase().trim().split(" ");return t.every(t=>e.name.toLowerCase().includes(t))||t.every(t=>e.key.toLowerCase().includes(t))}));const t=[];for(let i=e.length;i<7;i++)t.push(0);return Object.keys(e).length?q`
      ${Object.keys(e).map(t=>q` <scheduler-list-item graphic="icon" hasMeta @click=${()=>this._handleDomainClick(e[t].key)}>
            <ha-icon slot="graphic" icon="${e[t].icon}"></ha-icon>
            <ha-icon slot="meta" icon="mdi:chevron-right"></ha-icon>
            <span>${e[t].name}</span>
          </scheduler-list-item>`)}
      ${t.map(e=>q` <scheduler-list-item graphic="icon" hasMeta noninteractive> </scheduler-list-item> `)}
    `:q`
        <scheduler-list-item disabled>
          ${ns("ui.components.combo-box.no_match",this.hass)}
        </scheduler-list-item>
      `}_renderDomainActions(){var e,t;let i=Object.assign({},null===(e=this._params)||void 0===e?void 0:e.cardConfig);this.showAll&&(i=Object.assign(Object.assign({},i),{include:void 0,exclude:void 0}));let s=this._params.domainFilter.map(e=>Ya(this.hass,e,i)).flat();return(null===(t=this._params.entityFilter)||void 0===t?void 0:t.length)&&(s=s.filter(e=>{var t;return null===(t=this._params.entityFilter)||void 0===t?void 0:t.every(t=>{const i=ps(e.action,this._params.cardConfig.customize,this.hass),s=this.hass.states[t];return!(i.supported_features&&!((s.attributes.supported_features||0)&i.supported_features))&&((!Object.keys(e.action.service_data).includes("entity_id")||e.action.service_data.entity_id==t)&&(!Object.keys(e.action.target||{}).includes("entity_id")||(e.action.target||{}).entity_id==t))})})),this._filter&&(s=s.filter(e=>{const t=this._filter.toLowerCase().trim().split(" ");return t.every(t=>e.name.toLowerCase().includes(t))||t.every(t=>e.key.toLowerCase().includes(t))})),Object.keys(s).length?Object.keys(s).map(e=>q`
        <scheduler-list-item graphic="icon" @click=${()=>this._handleActionClick(s[e])} twoline>
          <ha-icon slot="graphic" icon="${s[e].icon}"></ha-icon>
          <span>${s[e].name}</span>
          <span slot="secondary">${s[e].description}</span>
        </scheduler-list-item>
      `):q`
        <scheduler-list-item disabled>
          ${ns("ui.components.combo-box.no_match",this.hass)}
        </scheduler-list-item>
      `}_handleDomainClick(e){this._params=Object.assign(Object.assign({},this._params),{domainFilter:[e]}),this._clearSearch()}_clearDomain(){this._params=Object.assign(Object.assign({},this._params),{domainFilter:void 0}),this._clearSearch()}_handleActionClick(e){this._params.confirm(e.action),this._params=void 0,this._clearSearch()}_clearSearch(){this._search="",this._filter=""}_toggleShowAll(){this.showAll?this.showAll=!1:(this.showAll=!0,this.lockDomain||this._clearDomain())}static get styles(){return r`
      ha-dialog {
        --dialog-content-padding: 0;
        --ha-dialog-width-md: 480px;
      }
      ha-input {
        display: block;
        margin: 0 16px;
      }
      .list {
        box-sizing: border-box;
        min-height: 300px;
        padding: 8px 0px;
      }
      scheduler-list-item:not([twoline]) {
        height: 56px;
      }
    `}};t([le({attribute:!1})],Xa.prototype,"hass",void 0),t([ce()],Xa.prototype,"_params",void 0),t([ce()],Xa.prototype,"_search",void 0),t([ce()],Xa.prototype,"_filter",void 0),t([ce()],Xa.prototype,"_width",void 0),t([ce()],Xa.prototype,"_height",void 0),t([ce()],Xa.prototype,"lockDomain",void 0),t([ce()],Xa.prototype,"showAll",void 0),Xa=t([re("dialog-select-action")],Xa);var eo=Object.freeze({__proto__:null,get DialogSelectAction(){return Xa}});let to=class extends oe{constructor(){super(...arguments),this.showPrefix=!1}render(){return q`
      ${this.showPrefix?q`
              <div class="prefix-wrap">
                <div class="prefix"><slot name="prefix"></slot></div>
                <div class="body">
                  <div class="heading"><slot name="heading"></slot></div>
                  <div class="secondary"><slot name="description"></slot></div>
                </div>
              </div>
            `:q`
              <div class="body">
                <div class="heading"><slot name="heading"></slot></div>
                <div class="secondary"><slot name="description"></slot></div>
              </div>
            `}
      <div class="content"><slot></slot></div>
    `}static get styles(){return r`

    :host {
      display: flex;
      padding: 0px;
      align-content: normal;
      align-self: auto;
      align-items: center;
    }
    .body {
      padding-top: 0px;
      padding-bottom: 0px;
      padding-left: 0;
      padding-inline-start: 0;
      padding-right: 16x;
      padding-inline-end: 16px;
      overflow: hidden;
      align-content: center;
    }
    .body > * {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .content {
      display: flex;
      justify-content: flex-end;
      flex: 1;
      padding: 8px 0;
    }
    // .content ::slotted(*) {
    //   width: var(--settings-row-content-width);
    // }
    .prefix-wrap {
      display: flex;
      flex-direction: row;
    }
    .prefix {
      display: flex;
      width: 48px;
    }
    .heading, .heading ::slotted(*) {
      display: flex;
      align-items: center;
      width: 150px;
    }
    @media all and (max-width: 450px) {
      :host {
        align-items: normal;
        flex-direction: column;
        border-top: 1px solid var(--divider-color);
        padding: 8px 16px;
      }
      .prefix-wrap {
        display: flex;
        align-items: center;
      }
      .content ::slotted(*) {
        width: 100%;
      }
    `}};t([le({type:Boolean})],to.prototype,"showPrefix",void 0),to=t([re("scheduler-settings-row")],to);let io=class extends oe{constructor(){super(...arguments),this.selectedSlot=null,this.large=!1,this.selectedEntry=0}shouldUpdate(e){return e.get("schedule")&&this.dispatchEvent(new CustomEvent("change",{detail:{schedule:this.schedule}})),!0}render(){return q`
      ${this.schedule.entries.map((e,t)=>q`
          <div class="editor-header">
            <div class="weekdays">
              <span>
                ${Ji("ui.panel.editor.repeated_days",this.hass)}:
                ${Ls(e.weekdays,"short",this.hass)}
              </span>
              <ha-icon-button
                .path=${Ks}
                @click=${e=>this._showWeekdayDialog(e,t)}
              ></ha-icon-button>
            </div>
            <div class="weekdays-actions">
              <ha-button appearance="plain" size="small" @click=${this.toggleViewMode}>
                ${this.viewMode==me.Scheme?Ji("ui.panel.editor.toggle_single_mode",this.hass):Ji("ui.panel.editor.toggle_scheme_mode",this.hass)}
                <ha-icon slot="end" icon="mdi:swap-horizontal"></ha-icon>
              </ha-button>
            </div>
          </div>

          ${this.viewMode==me.Scheme?q`
                  <div class="editor-header">
                    <div class="weekdays">${this.hass.localize("ui.dialogs.helper_settings.input_datetime.time")}:</div>
                    ${this.renderActionButtons()}
                  </div>
                  <scheduler-timeslot-editor
                    .hass=${this.hass}
                    .config=${this.config}
                    .schedule=${e}
                    .selectedSlot=${this.selectedSlot}
                    @update=${e=>this._handleUpdate(e,t)}
                    .large=${this.large}
                  >
                  </scheduler-timeslot-editor>
                `:q`
                  ${this.hass.localize("ui.dialogs.helper_settings.input_datetime.time")}:
                  <scheduler-time-picker
                    .hass=${this.hass}
                    .time=${this.schedule.entries[this.selectedEntry].slots[this.selectedSlot].start}
                    @value-changed=${this._startTimeChanged}
                    ?useAmPm=${Me(this.hass.locale)}
                    .stepSize=${this.config.time_step||15}
                    large
                  >
                  </scheduler-time-picker>
                `}
        `)}
      ${this.renderSlot()}
    `}toggleViewMode(){const e=this.viewMode==me.Scheme?me.Single:me.Scheme;this.dispatchEvent(new CustomEvent("setViewMode",{detail:e}))}renderActionButtons(){if(null===this.selectedSlot||null===this.selectedEntry)return q``;const e=this.schedule.entries[this.selectedEntry].slots[this.selectedSlot].start,t=this.schedule.entries[this.selectedEntry].slots[this.selectedSlot].stop||e,i=Ae(e,this.hass),s=(Ae(t,this.hass)||86400)-i;return q`
      <div class="actions">
        <ha-icon-button
          .path=${Bs}
          @click=${e=>{this._updateSelectedSlot(this.selectedSlot-1),e.target.blur()}}
          ?disabled=${null===this.selectedSlot||this.selectedSlot<1}
        >
        </ha-icon-button>
        <ha-icon-button
          .path=${"M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z"}
          @click=${e=>{this._updateSelectedSlot(this.selectedSlot+1),e.target.blur()}}
          ?disabled=${null===this.selectedSlot||this.selectedSlot>this.schedule.entries[this.selectedEntry].slots.length-2}
        >
        </ha-icon-button>
        <ha-icon-button .path=${"M19,6H22V8H19V11H17V8H14V6H17V3H19V6M17,17V14H19V19H3V6H11V8H5V17H17Z"} @click=${this._addTimeslot} ?disabled=${s<1800}>
        </ha-icon-button>
        <ha-icon-button
          .path=${"M9,3V4H4V6H5V19A2,2 0 0,0 7,21H17A2,2 0 0,0 19,19V6H20V4H15V3H9M7,6H17V19H7V6M9,8V17H11V8H9M13,8V17H15V8H13Z"}
          @click=${this._removeTimeslot}
          ?disabled=${this.schedule.entries[this.selectedEntry].slots.length<=2}
        >
        </ha-icon-button>
      </div>
    `}renderSlot(){if(null===this.selectedEntry||null===this.selectedSlot)return q` <div class="slot-placeholder">${Ji("ui.panel.editor.select_timeslot",this.hass)}</div> `;const e=this.schedule.entries[this.selectedEntry].slots[this.selectedSlot],t=this.selectedSlot===this.schedule.entries[this.selectedEntry].slots.length-1;let i=e.stop;return!i&&this.selectedSlot<this.schedule.entries[this.selectedEntry].slots.length-1&&(i=this.schedule.entries[this.selectedEntry].slots[this.selectedSlot+1].start),i||(i=e.start),q`
      ${this.viewMode==me.Scheme?q` <div class="two-column">
              <div class="column">
                <scheduler-time-picker
                  .hass=${this.hass}
                  label="${Ji("ui.panel.editor.start_time",this.hass)}:"
                  ?disabled=${0==this.selectedSlot}
                  .time=${e.start}
                  @value-changed=${this._startTimeChanged}
                  ?useAmPm=${Me(this.hass.locale)}
                >
                </scheduler-time-picker>
              </div>
              <div class="column">
                <scheduler-time-picker
                  .hass=${this.hass}
                  label="${Ji("ui.panel.editor.stop_time",this.hass)}:"
                  ?disabled=${t}
                  .time=${i}
                  @value-changed=${this._stopTimeChanged}
                  ?useAmPm=${Me(this.hass.locale)}
                >
                </scheduler-time-picker>
              </div>
            </div>`:""}
      ${Ji("ui.panel.editor.action",this.hass)}: ${this._renderActionConfig()}
    `}_renderActionConfig(){var e,t,i,s;const a=Object.assign({},this.schedule.entries[this.selectedEntry].slots[this.selectedSlot]),o=a.actions.length?a.actions[0]:void 0;if(!o)return q`
        <div>
          <ha-button appearance="plain" @click=${this._showActionDialog}>
            <ha-icon slot="start" icon="mdi:plus"></ha-icon>
            ${Ji("ui.panel.editor.add_action",this.hass)}
          </ha-button>
        </div>
      `;const n=ps(o,this.config.customize,this.hass),r=(null===(e=n.target)||void 0===e?void 0:e.domain)||Xi(o.service),d=Ze(null===(t=null==n?void 0:n.target)||void 0===t?void 0:t.entity_id)||this.schedule.entries[this.selectedEntry].slots.some(e=>{var t,i;return e.actions.length&&Ze(null===(i=null===(t=ps(e.actions[0],this.config.customize,this.hass))||void 0===t?void 0:t.target)||void 0===i?void 0:i.entity_id)});if(void 0===n)return q``;const l=Object.keys(n.fields||{}).filter(e=>za(o,e,this.hass,this.config.customize));let c="",u=[(null===(i=o.target)||void 0===i?void 0:i.entity_id)||[]].flat();return!u.length&&["notify","script"].includes(r)&&(u=[o.service]),u.length&&(c+=u.map(e=>Ns(e,this.hass,this.config.customize)).join(", "),c+=": "),c+=Ss(o,this.hass,this.config.customize,!1,!0),q`
      <scheduler-collapsible-section ?expanded=${!0} ?disabled=${!0}>
        <div slot="header" class="header">
          <ha-icon slot="icon" icon="${Pa(o,this.config.customize)}"></ha-icon>
          <span>${os(c)}</span>
        </div>

        <ha-dropdown
          slot="contextMenu"
          @wa-select=${this._actionItemOptionsClick}
          @wa-after-hide=${e=>{e.target.firstElementChild.blur()}}
          placement="bottom-end"
        >
          <ha-icon-button slot="trigger" .path=${Zs}> </ha-icon-button>
          <ha-dropdown-item value="change_type">
            <ha-icon icon="mdi:pencil"></ha-icon>
            ${ns("ui.panel.lovelace.editor.card.conditional.change_type",this.hass)}
          </ha-dropdown-item>
          <ha-dropdown-item variant="danger" value="delete">
            <ha-icon icon="mdi:delete"></ha-icon>
            ${ns("ui.common.delete",this.hass)}
          </ha-dropdown-item>
        </ha-dropdown>

        <div slot="content">
          ${n.target?q`
                  <scheduler-settings-row>
                    <span slot="heading">${ns("ui.components.entity.entity-picker.entity",this.hass)}</span>
                    <scheduler-entity-picker
                      .hass=${this.hass}
                      .config=${this.config}
                      .domain=${r}
                      .filterFunc=${e=>!n.supported_features||((e.attributes.supported_features||0)&n.supported_features)>0}
                      @value-changed=${this._selectEntity}
                      .value=${[(null===(s=o.target)||void 0===s?void 0:s.entity_id)||[]].flat()}
                      ?multiple=${!0}
                      ?disabled=${d}
                    >
                    </scheduler-entity-picker>
                  </scheduler-settings-row>
                `:""}
          ${l.map(e=>{var t;const i=fs(o.service,null===(t=o.target)||void 0===t?void 0:t.entity_id,e,this.hass,this.config.customize);if(null===i)return"";const s=n.fields[e].optional||(i.number||{}).optional,a=!s||Object.keys(o.service_data).includes(e);return q`
              <scheduler-settings-row ?showPrefix=${s}>
                ${s?q`
                        <ha-checkbox
                          slot="prefix"
                          ?checked=${a}
                          @change=${t=>this._toggleOptionalField(t,e,i)}
                        >
                        </ha-checkbox>
                      `:""}
                <span slot="heading"> ${((e,t,i,s)=>{var a;const o=Xi(e.service),n=Qi(e.service);let r=ns(`component.${o}.services.${n}.fields.${t}.name`,i,!1);!r&&i.services[o]&&i.services[o][n]&&i.services[o][n].fields&&i.services[o][n].fields[t]&&(r=String(i.services[o][n].fields[t].name||""));const d=["script","notify"].includes(o)?[e.service]:[(null===(a=e.target)||void 0===a?void 0:a.entity_id)||[]].flat(),l=d.length?d[0]:e.service;let c=ms(s||{},l);if(c.length){let i=c.map(i=>i.service==e.service&&Object.keys(i.variables||{}).includes(t)?(i.variables||{})[t].name:null).filter(Ze);if(i.length)return i[0]}return r||(r=t.replace(/_/g," ")),r})(o,e,this.hass,this.config.customize)} </span>
                <scheduler-combo-selector
                  .hass=${this.hass}
                  .config=${i}
                  ?disabled=${!a}
                  .value=${Object.keys(o.service_data).includes(e)?o.service_data[e]:void 0}
                  @value-changed=${t=>this._selectField(e,t)}
                >
                </scheduler-combo-selector>
              </scheduler-settings-row>
            `})}
        </div>
      </scheduler-collapsible-section>
    `}_selectField(e,t){const i=t.detail.value,s=Object.assign({},this.schedule.entries[this.selectedEntry].slots[this.selectedSlot]),a=void 0!==i?Object.assign(Object.assign({},s.actions[0]),{service_data:Object.assign(Object.assign({},s.actions[0].service_data),{[e]:i})}):Object.assign(Object.assign({},s.actions[0]),{service_data:Object.fromEntries(Object.entries(s.actions[0].service_data).filter(([t])=>t!=e))});this._updateSlot({actions:[a]})}_toggleOptionalField(e,t,i){const s=e.target.checked,a=s?Na(i):void 0;s?this._selectField(t,new CustomEvent("value-changed",{detail:{value:Ze(a)?a:null}})):this._selectField(t,new CustomEvent("value-changed",{detail:{value:void 0}}))}_selectEntity(e){const t=e.detail.value;t&&this.schedule.entries[this.selectedEntry].slots.forEach((e,i)=>{if(!e.actions.length)return;const s=Object.assign(Object.assign({},e.actions[0]),{target:{entity_id:t}});this._updateSlot({actions:[s]},i)})}_handleUpdate(e,t){this.selectedEntry=t,e.detail.hasOwnProperty("selectedSlot")?(this._updateSelectedSlot(e.detail.selectedSlot),this.selectedSlot=e.detail.selectedSlot):e.detail.hasOwnProperty("slots")&&this._updateEntry({slots:e.detail.slots})}_updateSelectedSlot(e){this.dispatchEvent(new CustomEvent("change",{detail:{selectedSlot:e}}))}_updateEntry(e){let t=Object.assign({},this.schedule.entries[this.selectedEntry]);t=Object.assign(Object.assign({},t),e),this.schedule=Object.assign(Object.assign({},this.schedule),{entries:Object.assign(this.schedule.entries,{[this.selectedEntry]:t})})}_updateSlot(e,t=this.selectedSlot){let i=Object.assign({},this.schedule.entries[this.selectedEntry].slots[t]);i=Object.assign(Object.assign({},i),e),this._updateEntry({slots:Object.assign(this.schedule.entries[this.selectedEntry].slots,{[t]:i})})}async _showWeekdayDialog(e,t){this.selectedEntry=t,await new Promise(i=>{const s={weekdays:[...this.schedule.entries[t].weekdays],cancel:()=>i(null),confirm:e=>i(e)};Vs(e.target,"show-dialog",{dialogTag:"dialog-select-weekdays",dialogImport:()=>Promise.resolve().then(function(){return Ga}),dialogParams:s})}).then(e=>{e&&this._updateEntry({weekdays:e})})}async _showActionDialog(e){let t=[],i=[];this.schedule.entries.forEach(e=>{e.slots.forEach(e=>{e.actions.forEach(e=>{var s,a;i=[...i,...[(null===(s=e.target)||void 0===s?void 0:s.entity_id)||[]].flat()],t=[...t,...[Xi(e.service),...[(null===(a=e.target)||void 0===a?void 0:a.entity_id)||[]].flat()].map(Xi)]})})}),t=[...new Set(t)],i=[...new Set(i)],await new Promise(s=>{const a={cancel:()=>s(null),confirm:e=>s(e),domainFilter:t.length?t:void 0,entityFilter:i.length?i:void 0,cardConfig:this.config};Vs(e.target,"show-dialog",{dialogTag:"dialog-select-action",dialogImport:()=>Promise.resolve().then(function(){return eo}),dialogParams:a})}).then(e=>{if(!e)return;Object.assign({},this.schedule.entries[this.selectedEntry].slots[this.selectedSlot]);const t=this.schedule.entries[this.selectedEntry].slots.find(e=>{var t;return e.actions.length?null===(t=e.actions[0].target)||void 0===t?void 0:t.entity_id:void 0});let i=Object.assign({},e);t&&i.target&&(i=Object.assign(Object.assign({},i),{target:t.actions[0].target})),this._updateSlot({actions:[i]})})}_actionItemOptionsClick(e){switch(e.detail.item.value){case"change_type":this._showActionDialog(e);break;case"delete":this._updateSlot({actions:[]})}}_stopTimeChanged(e){const t=e.detail.value,[i,s]=Va([...this.schedule.entries[this.selectedEntry].slots],Number(this.selectedSlot),{stop:t},this.hass);this._updateEntry({slots:i}),s!=this.selectedSlot&&this._updateSelectedSlot(s)}_startTimeChanged(e){const t=e.detail.value,[i,s]=Va([...this.schedule.entries[this.selectedEntry].slots],Number(this.selectedSlot),{start:t},this.hass);this._updateEntry({slots:i}),s!=this.selectedSlot&&this._updateSelectedSlot(s)}_addTimeslot(e){null!==this.selectedEntry&&null!==this.selectedSlot&&(this.schedule=((e,t,i,s)=>{let a=[...e.entries[t].slots],o=Ce(a[i].start),n=void 0===a[i].stop?o:Ce(a[i].stop);if(n.mode!==be.Fixed||n.hours||n.minutes||(n=Object.assign(Object.assign({},n),{hours:24})),[be.Sunrise,be.Sunset].includes(o.mode)){const e=o.mode==be.Sunrise?s.states["sun.sun"].attributes.next_rising:s.states["sun.sun"].attributes.next_setting;let t=Ce(e);o=Se(t,{hours:o.hours,minutes:o.minutes})}const r=Ae(o,s),d=(Ae(n,s)-r)/2,l=Math.floor(d/3600),c=Math.round((d-3600*l)/60);let u=Se(o,{hours:l,minutes:c});return u=ze(u,15),a=[...a.slice(0,i),Object.assign(Object.assign({},a[i]),{stop:Ie(u)}),Object.assign(Object.assign({},a[i]),{start:Ie(u),stop:Ie(n),actions:[]}),...a.slice(i+1)],Object.assign(Object.assign({},e),{entries:Object.assign(e.entries,{[t]:Object.assign(Object.assign({},e.entries[t]),{slots:a})})})})(this.schedule,this.selectedEntry,this.selectedSlot,this.hass),e.target.blur())}_removeTimeslot(e){null!==this.selectedEntry&&null!==this.selectedSlot&&(this.schedule=((e,t,i)=>{let s=[...e.entries[t].slots];const a=i==s.length-1?i-1:i;return s=[...s.slice(0,a),Object.assign(Object.assign({},s[a+1]),{start:s[a].start,stop:s[a+1].stop}),...s.slice(a+2)],Object.assign(Object.assign({},e),{entries:Object.assign(e.entries,{[t]:Object.assign(Object.assign({},e.entries[t]),{slots:s})})})})(this.schedule,this.selectedEntry,this.selectedSlot),this.selectedSlot>=this.schedule.entries[this.selectedEntry].slots.length&&(this.selectedSlot=this.schedule.entries[this.selectedEntry].slots.length-1),e.target.blur())}static get styles(){return r`
      :host {
        position: relative;
      }
      .two-column {
        display: flex;
        flex-direction: row;
        margin: 16px 0px;
        flex-wrap: wrap;
        gap: 10px;
      }
      .two-column .column {
        display: flex;
        flex-direction: column;
        flex: 0 0 215px;
      }
      div.editor-header {
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
      }
      .weekdays {
        display: flex;
        flex: 1;
        align-items: center;
        white-space: nowrap;
      }
      .weekdays-actions {
        display: flex;
        align-items: center;
      }
      div.actions {
        display: flex;
        align-items: end;
        margin: -4px 0px 0px 0px;
      }
      @media all and (max-width: 150px) {
        div.editor-header {
          flex-direction: column;
          margin-top: 0px;
        }
        div.actions {
          align-self: flex-end;
        }
      }
      div.slot-placeholder {
        padding: 20px 0px 0px 0px;
      }
      scheduler-collapsible-section .header ha-icon {
        margin-right: 6px;
      }
      scheduler-collapsible-section .header span {
        flex: 1;
      }
      scheduler-list-item.warning,
      scheduler-list-item.warning ha-icon {
        color: var(--error-color);
      }
    `}};t([le({attribute:!1})],io.prototype,"hass",void 0),t([le({attribute:!1})],io.prototype,"config",void 0),t([le({attribute:!1})],io.prototype,"viewMode",void 0),t([le({attribute:!1})],io.prototype,"selectedSlot",void 0),t([le({type:Boolean})],io.prototype,"large",void 0),t([ce()],io.prototype,"schedule",void 0),t([ce()],io.prototype,"selectedEntry",void 0),io=t([re("scheduler-main-panel")],io);const so=["January","February","March","April","May","June","July","August","September","October","November","December"];function ao(e){return e.toISOString().split("T")[0]}function oo(e){let t=new Date;const i=(e||"").match(/^([0-9]{4})-([0-9]{2})-([0-9]{2})/);null!==i&&t.setFullYear(Number(i[1]),Number(i[2])-1,Number(i[3]));const s=(e||"").match(/([0-9]{2}):([0-9]{2})(:([0-9]{2}))?$/);return null!==s&&t.setHours(Number(s[1]),Number(s[2]),s.length>4?Number(s[4]):t.getSeconds()),t}const no=(e,t)=>"select"in t&&null!==t.select?((e,t)=>{var i;return((null===(i=t.select)||void 0===i?void 0:i.options)||[]).some(t=>"object"==typeof t?t.value==e:t==e)})(String(e),t):"number"in t&&null!==t.number?((e,t)=>{var i,s;return!(isNaN(e)||void 0!==(null===(i=t.number)||void 0===i?void 0:i.min)&&e<t.number.min||void 0!==(null===(s=t.number)||void 0===s?void 0:s.max)&&e>t.number.max)})(Number(e),t):!("text"in t)||null===t.text||String(e).length>0,ro=e=>null==e||Array.isArray(e)?e:[e];let lo=class extends oe{constructor(){super(...arguments),this._search="",this._filter="",this.timer=0,this.showAll=!1}async showDialog(e){this._params=e,this.showAll=!1,await this.updateComplete}async closeDialog(){this._params&&this._params.cancel(),this._params=void 0,this._clearSearch(),this._height=void 0,this._width=void 0}async willUpdate(){this.hass.loadBackendTranslation("title")}render(){return this._params?q`
      <ha-dialog open @closed=${this.closeDialog} @wa-after-show=${this._opened}>
        <div slot="header">
          <ha-dialog-header>
            <ha-icon-button
              slot="navigationIcon"
              data-dialog="close"
              .label=${ns("ui.dialogs.more_info_control.dismiss",this.hass)}
              .path=${Ws}
            ></ha-icon-button>
            <div slot="title">${Ji("ui.panel.options.conditions.add_condition",this.hass)}</div>
            ${Ze(this._params.domain)?"":q` <ha-dropdown
                    placement="bottom-end"
                    slot="actionItems"
                    @wa-after-hide=${e=>{e.target.firstElementChild.blur()}}
                  >
                    <ha-icon-button
                      slot="trigger"
                      .label=${this.hass.localize("ui.common.menu")}
                      .path=${Zs}
                    >
                    </ha-icon-button>
                    <ha-dropdown-item @click=${this._toggleShowAll}>
                      <ha-icon icon="mdi:check" style="${this.showAll?"":"visibility: hidden"}"></ha-icon>
                      ${Ji("ui.dialog.action_picker.show_all",this.hass)}
                    </ha-dropdown-item>
                  </ha-dropdown>`}
          </ha-dialog-header>

          <ha-input
            dialogInitialFocus
            .placeholder=${ns("ui.common.search",this.hass)}
            aria-label=${ns("ui.common.search",this.hass)}
            @input=${this._handleSearchChange}
            .value=${this._search}
            icon
            .iconTrailing=${this._search}
          >
            <div class="trailing" slot="trailingIcon">
              ${this._search&&q`
                  <ha-icon-button
                    @click=${this._clearSearch}
                    .label=${ns("ui.common.clear",this.hass)}
                    .path=${Ws}
                    class="clear-button"
                  ></ha-icon-button>
                `}
              <slot name="suffix"></slot>
            </div>
          </ha-input>
        </div>

        <div
          class="list"
          role="list"
          style=${oa({minWidth:`${this._width}px`,height:this._height?`${Math.min(468,this._height)}px`:"auto"})}
        >
          ${this._renderOptions()}
        </div>
      </ha-dialog>
    `:q``}_opened(){var e;const t=null===(e=this.shadowRoot.querySelector(".list"))||void 0===e?void 0:e.getBoundingClientRect();this._width=null==t?void 0:t.width,this._height=null==t?void 0:t.height}_handleSearchChange(e){const t=e.currentTarget.value;this._search=t,clearTimeout(this.timer),this.timer=window.setTimeout(()=>{this._filter=this._search},100)}_clearSearch(){this._search="",this._filter=""}_renderOptions(){var e;let t=Object.assign({},null===(e=this._params)||void 0===e?void 0:e.cardConfig);this.showAll&&(t=Object.assign(Object.assign({},t),{include:void 0,exclude:void 0}));let i=ua(this.hass,t);return i.sort((e,t)=>as(e.name,t.name)),this._filter&&(i=i.filter(e=>{const t=this._filter.toLowerCase().trim().split(" ");return t.every(t=>e.name.toLowerCase().includes(t))||t.every(t=>e.key.toLowerCase().includes(t))})),Object.keys(i).map(e=>q`
        <scheduler-list-item graphic="icon" @click=${()=>this._handleDomainClick(i[e].key)}>
          <ha-icon slot="graphic" icon="${i[e].icon}"></ha-icon>
          <span>${i[e].name}</span>
        </scheduler-list-item>
      `)}_handleDomainClick(e){this._params=Object.assign(Object.assign({},this._params),{domain:e}),this._params.confirm(e),this._params=void 0,this._clearSearch()}_toggleShowAll(){this.showAll?this.showAll=!1:this.showAll=!0}static get styles(){return r`
      ha-dialog {
        --dialog-content-padding: 0;
        --ha-dialog-width-md: 480px;
      }
      ha-input {
        display: block;
        margin: 0 16px;
      }
      .list {
        box-sizing: border-box;
        min-height: 300px;
        padding: 8px 0px;
      }
      scheduler-list-item:not([twoline]) {
        height: 56px;
      }
    `}};t([le({attribute:!1})],lo.prototype,"hass",void 0),t([ce()],lo.prototype,"_params",void 0),t([ce()],lo.prototype,"_search",void 0),t([ce()],lo.prototype,"_filter",void 0),t([ce()],lo.prototype,"_width",void 0),t([ce()],lo.prototype,"_height",void 0),t([ce()],lo.prototype,"showAll",void 0),lo=t([re("dialog-select-condition")],lo);var co=Object.freeze({__proto__:null,get DialogSelectCondition(){return lo}});let uo=class extends oe{constructor(){super(...arguments),this.conditionIdx=-1,this.conditionValid=!0,this.startDate="",this.endDate="",this.tags=[],this.customTagValue=""}async firstUpdated(){var e,t;(await window.loadCardHelpers()).importMoreInfoControl("input_datetime"),this.startDate=(null===(e=this.schedule)||void 0===e?void 0:e.start_date)||ao(new Date),this.endDate=(null===(t=this.schedule)||void 0===t?void 0:t.end_date)||ao(new Date);const i=(await Us(this.hass)).map(e=>e.name),s=[this.config.tags||[]].flat();this.tags=[...new Set([...i,...s.filter(e=>!i.includes(e)&&!["none","disabled","enabled"].includes(e))])]}shouldUpdate(e){return e.get("schedule")&&this.dispatchEvent(new CustomEvent("change",{detail:{schedule:this.schedule}})),!0}render(){const e={select:{options:this.tags,multiple:!0,custom_value:!0}};return q`
      <div class="header first">
        <span>${Ji("ui.panel.options.conditions.header",this.hass)}:</span>
        ${this.schedule.entries[0].slots[0].conditions.items.length?q`
                <ha-dropdown
                  @wa-select=${this._conditionConfigOptionsClick}
                  @wa-after-hide=${e=>{e.target.firstElementChild.blur()}}
                  placement="bottom-end"
                >
                  <ha-icon-button slot="trigger" .path=${"M12,15.5A3.5,3.5 0 0,1 8.5,12A3.5,3.5 0 0,1 12,8.5A3.5,3.5 0 0,1 15.5,12A3.5,3.5 0 0,1 12,15.5M19.43,12.97C19.47,12.65 19.5,12.33 19.5,12C19.5,11.67 19.47,11.34 19.43,11L21.54,9.37C21.73,9.22 21.78,8.95 21.66,8.73L19.66,5.27C19.54,5.05 19.27,4.96 19.05,5.05L16.56,6.05C16.04,5.66 15.5,5.32 14.87,5.07L14.5,2.42C14.46,2.18 14.25,2 14,2H10C9.75,2 9.54,2.18 9.5,2.42L9.13,5.07C8.5,5.32 7.96,5.66 7.44,6.05L4.95,5.05C4.73,4.96 4.46,5.05 4.34,5.27L2.34,8.73C2.21,8.95 2.27,9.22 2.46,9.37L4.57,11C4.53,11.34 4.5,11.67 4.5,12C4.5,12.33 4.53,12.65 4.57,12.97L2.46,14.63C2.27,14.78 2.21,15.05 2.34,15.27L4.34,18.73C4.46,18.95 4.73,19.03 4.95,18.95L7.44,17.94C7.96,18.34 8.5,18.68 9.13,18.93L9.5,21.58C9.54,21.82 9.75,22 10,22H14C14.25,22 14.46,21.82 14.5,21.58L14.87,18.93C15.5,18.67 16.04,18.34 16.56,17.94L19.05,18.95C19.27,19.03 19.54,18.95 19.66,18.73L21.66,15.27C21.78,15.05 21.73,14.78 21.54,14.63L19.43,12.97Z"}> </ha-icon-button>
                  <ha-dropdown-item
                    ?disabled=${this.schedule.entries[0].slots[0].conditions.items.length<2}
                    value="or"
                  >
                    <ha-icon
                      icon="mdi:check"
                      style="${this.schedule.entries[0].slots[0].conditions.type==_e.Or?"":"visibility: hidden"}"
                    ></ha-icon>
                    ${Ji("ui.panel.options.conditions.options.logic_or",this.hass)}
                  </ha-dropdown-item>
                  <ha-dropdown-item
                    ?disabled=${this.schedule.entries[0].slots[0].conditions.items.length<2}
                    value="and"
                  >
                    <ha-icon
                      icon="mdi:check"
                      style="${this.schedule.entries[0].slots[0].conditions.type==_e.And?"":"visibility: hidden"}"
                    ></ha-icon>
                    ${Ji("ui.panel.options.conditions.options.logic_and",this.hass)}
                  </ha-dropdown-item>
                  <ha-dropdown-item value="track_changes">
                    <ha-icon
                      icon="mdi:check"
                      style="${this.schedule.entries[0].slots[0].conditions.track_changes?"":"visibility: hidden"}"
                    ></ha-icon>
                    ${Ji("ui.panel.options.conditions.options.track_changes",this.hass)}
                  </ha-dropdown-item>
                </ha-dropdown>
              `:""}
      </div>
      <scheduler-collapsible-group
        ?disabled=${!this.conditionValid}
        @openclose-changed=${this._updateActiveCondition}
        .openedItem=${this.conditionIdx}
      >
        ${this.renderConditions()}
      </scheduler-collapsible-group>

      <div>
        <ha-button appearance="plain" @click=${this._conditionAddClick}>
          <ha-icon slot="start" icon="mdi:plus"></ha-icon>
          ${Ji("ui.panel.options.conditions.add_condition",this.hass)}
        </ha-button>
      </div>

      <span class="header">${Ji("ui.panel.options.period.header",this.hass)}:</span>
      <div class="period">
        <div>
          <ha-checkbox ?checked=${"string"==typeof this.schedule.start_date} @change=${this.toggleEnableDateRange}>
          </ha-checkbox>
        </div>
        <div>
          <span>${Ji("ui.panel.options.period.start_date",this.hass)}</span>
        </div>
        <div class="input">
          <ha-date-input
            .locale=${this.hass.locale}
            value=${this.startDate}
            .label=${ns("ui.components.date-range-picker.start_date",this.hass)}
            @value-changed=${this._setStartDate}
            ?disabled=${!this.schedule.start_date}
          >
          </ha-date-input>
        </div>
        <div>
          <span>${Ji("ui.panel.options.period.end_date",this.hass)}</span>
        </div>
        <div class="input">
          <ha-date-input
            .locale=${this.hass.locale}
            value=${this.endDate}
            .label=${ns("ui.components.date-range-picker.end_date",this.hass)}
            @value-changed=${this._setEndDate}
            ?disabled=${!this.schedule.end_date}
          >
          </ha-date-input>
        </div>
      </div>

      <span class="header">${ns("ui.common.name",this.hass)}:</span>
      <div class="period">
        <ha-input
          value=${this.schedule.name||""}
          placeholder=${this.schedule.name?"":ns("ui.common.name",this.hass)}
          @input=${this.updateName}
        ></ha-input>
      </div>

      <span class="header">${Ji("ui.panel.options.tags",this.hass)}:</span>
      <div>
        <scheduler-combo-selector
          .hass=${this.hass}
          .config=${e}
          .value=${this.schedule.tags||[]}
          @value-changed=${this.tagsUpdated}
        >
        </scheduler-combo-selector>

        <ha-dropdown
          @wa-after-hide=${e=>{e.stopPropagation(),e.target.querySelector("ha-button").blur()}}
          @click=${e=>{e.preventDefault(),e.stopImmediatePropagation()}}
          @wa-after-show=${e=>{e.target.querySelector("ha-input").focus()}}
          placement="bottom-start"
        >
          <ha-button appearance="plain" slot="trigger">
            <ha-icon slot="start" icon="mdi:plus"></ha-icon>
            ${ns("ui.panel.config.tag.add_tag",this.hass)}
          </ha-button>

          <div style="display: flex; align-items: center; padding: 0px 2px 0px 8px">
            <ha-input
              .value=${this.customTagValue}
              .label=${ns("ui.panel.config.tag.add_tag",this.hass)}
              @input=${e=>{this.customTagValue=e.currentTarget.value}}
              @keydown=${e=>{"Enter"===e.key&&this._customTagConfirmClick(e)}}
              .placeholder=""
            ></ha-input>
            <ha-button appearance="plain" @click=${this._customTagConfirmClick}>
              ${ns("ui.common.ok",this.hass)}
            </ha-button>
          </div>
        </ha-dropdown>
      </div>

      <span class="header">${Ji("ui.panel.options.repeat_type",this.hass)}:</span>
      <ha-button
        appearance="${this.schedule.repeat_type==fe.Repeat?"filled":"plain"}"
        variant="${this.schedule.repeat_type==fe.Repeat?"brand":"neutral"}"
        @click=${this.setRepeatType}
        value="${fe.Repeat}"
      >
        <ha-icon slot="start" icon="mdi:refresh"></ha-icon>
        ${ns("ui.components.calendar.event.repeat.label",this.hass)}
      </ha-button>
      <ha-button
        appearance="${this.schedule.repeat_type==fe.Pause?"filled":"plain"}"
        variant="${this.schedule.repeat_type==fe.Pause?"brand":"neutral"}"
        @click=${this.setRepeatType}
        value="${fe.Pause}"
      >
        <ha-icon slot="start" icon="mdi:stop"></ha-icon>
        ${ns("ui.dialogs.more_info_control.vacuum.stop",this.hass)}
      </ha-button>
      <ha-button
        appearance="${this.schedule.repeat_type==fe.Single?"filled":"plain"}"
        variant="${this.schedule.repeat_type==fe.Single?"brand":"neutral"}"
        @click=${this.setRepeatType}
        value="${fe.Single}"
      >
        <ha-icon slot="start" icon="mdi:trash-can-outline"></ha-icon>
        ${ns("ui.common.delete",this.hass)}
      </ha-button>
    `}renderConditions(){let e=this.schedule.entries[0].slots[0].conditions.items;return this.conditionIdx==e.length&&(e=[...e,{}]),e.map((e,t)=>{var i;const s=this.conditionIdx==t?this.selectedEntity||e.entity_id||"":e.entity_id||"",a=this.conditionIdx==t&&this.selectedDomain||Xi(s),o=ca(s||a,this.hass,this.config.customize),n=o&&o.hasOwnProperty("number")?[ge.Above,ge.Below]:[ge.Equal,ge.Unequal],r={[ge.Equal]:"mdi:equal",[ge.Unequal]:"mdi:not-equal-variant",[ge.Above]:"mdi:greater-than",[ge.Below]:"mdi:less-than"},d={[ge.Equal]:"ui.panel.options.conditions.types.equal_to",[ge.Unequal]:"ui.panel.options.conditions.types.unequal_to",[ge.Above]:"ui.panel.options.conditions.types.above",[ge.Below]:"ui.panel.options.conditions.types.below"};return this.conditionIdx!==t||this.selectedMatchType||(this.selectedMatchType=n[0]),q`
        <scheduler-collapsible-section idx="${t}">
          <div slot="header">
            ${e.entity_id&&void 0!==e.value?q`
                    <ha-icon
                      slot="icon"
                      icon="${ha(e.entity_id,this.config.customize,this.hass)}"
                    ></ha-icon>
                    ${os(Ji(d[e.match_type],this.hass,["{entity}","{value}"],[Ns(e.entity_id,this.hass,this.config.customize)||"",null!==(i=gs(e.value,o,this.hass))&&void 0!==i?i:""]))}
                  `:Ji("ui.panel.options.conditions.add_condition",this.hass)}
          </div>
          <ha-dropdown
            slot="contextMenu"
            @wa-select=${e=>this._conditionItemOptionsClick(e,t)}
            ?disabled=${!this.conditionValid&&this.conditionIdx!==t&&-1!=this.conditionIdx}
            placement="bottom-end"
          >
            <ha-icon-button
              slot="trigger"
              .path=${Zs}
              ?disabled=${!this.conditionValid&&this.conditionIdx!==t&&-1!=this.conditionIdx}
            >
            </ha-icon-button>
            <ha-dropdown-item value="change_type">
              <ha-icon icon="mdi:pencil"></ha-icon>
              ${ns("ui.panel.lovelace.editor.card.conditional.change_type",this.hass)}
            </ha-dropdown-item>
            <ha-dropdown-item variant="danger" value="delete">
              <ha-icon icon="mdi:delete"></ha-icon>
              ${ns("ui.common.delete",this.hass)}
            </ha-dropdown-item>
          </ha-dropdown>

          <div slot="content">
            <scheduler-settings-row>
              <span slot="heading"> ${ns("ui.components.selectors.selector.types.entity",this.hass)} </span>
              <scheduler-entity-picker
                .hass=${this.hass}
                .config=${this.config}
                .domain=${a}
                @value-changed=${this._selectEntity}
                .value=${this.conditionIdx==t?ro(this.selectedEntity):ro(e.entity_id)}
                ?multiple=${!1}
              >
              </scheduler-entity-picker>
            </scheduler-settings-row>

            <scheduler-settings-row>
              <span slot="heading">
                ${os(Ji(d[this.conditionIdx==t?this.selectedMatchType:e.match_type],this.hass,["{entity}","{value}"],["",""]))}
                <ha-dropdown
                  @wa-select=${this._selectMatchType}
                  @wa-after-hide=${e=>{e.target.firstElementChild.blur()}}
                >
                  <ha-icon-button slot="trigger" .path=${Ks}> </ha-icon-button>
                  ${n.map(i=>q`
                      <ha-dropdown-item
                        ?noninteractive=${this.conditionIdx==t?this.selectedMatchType==i:e.match_type==i}
                        value="${i}"
                      >
                        <ha-icon icon="${r[i]}"></ha-icon>
                        ${os(Ji(d[i],this.hass,["{entity}","{value}"],["",""]))}
                      </ha-dropdown-item>
                    `)}
                </ha-dropdown>
              </span>
              <scheduler-combo-selector
                .hass=${this.hass}
                .config=${o}
                .value=${this.conditionIdx==t?this.conditionValue:e.value}
                @value-changed=${this._conditionValueChanged}
              >
              </scheduler-combo-selector>
            </scheduler-settings-row>
          </div>
        </scheduler-collapsible-section>
      `})}_updateActiveCondition(e){const t=e.detail.item;if(t<0)return void(this.conditionIdx=-1);if(t===this.conditionIdx)return;this.conditionIdx=t;const i=this.schedule.entries[0].slots[0].conditions.items[t];this.selectedEntity=i?i.entity_id:void 0,this.selectedMatchType=i?i.match_type:void 0,this.conditionValue=i?i.value:void 0}_conditionItemOptionsClick(e,t){switch(e.detail.item.value){case"change_type":this._showConditionDialog(e).then(e=>{e&&(this.conditionIdx=t,this.selectedDomain=e,this.selectedEntity=void 0,this.selectedMatchType=void 0,this.conditionValue=void 0,this.conditionValid=!1)});break;case"delete":const i=this.schedule.entries[0].slots[0].conditions.items.filter((e,i)=>i!==t),s=e=>Object.assign(e,{conditions:Object.assign(Object.assign({},e.conditions),{items:i})}),a=e=>Object.assign(e,{slots:e.slots.map(s)});this.schedule=Object.assign(Object.assign({},this.schedule),{entries:this.schedule.entries.map(a)}),t===this.conditionIdx?this.conditionIdx=-1:void 0!==this.conditionIdx&&t<this.conditionIdx&&(this.conditionIdx=this.conditionIdx-1),this.conditionValid=!0}}_selectMatchType(e){const t=e.detail.item.value;this.selectedMatchType=t,this._validateCondition()}_conditionValueChanged(e){this.conditionValue=e.detail.value,this._validateCondition()}async _showConditionDialog(e){return new Promise(t=>{const i={cancel:()=>t(null),confirm:e=>t(e),domain:void 0,cardConfig:this.config};Vs(e.target,"show-dialog",{dialogTag:"dialog-select-condition",dialogImport:()=>Promise.resolve().then(function(){return co}),dialogParams:i})})}_selectEntity(e){const t=e.detail.value;if(this.selectedEntity=t?t.pop():void 0,this.selectedEntity){const e=ca(this.selectedEntity,this.hass,this.config.customize),t=e&&e.hasOwnProperty("number")?[ge.Above,ge.Below]:[ge.Equal,ge.Unequal];this.selectedMatchType&&t.includes(this.selectedMatchType)||(this.selectedMatchType=t[0])}this._validateCondition()}_validateCondition(){if(this.conditionValid=!1,!this.selectedEntity||!Ze(this.conditionValue)||!this.selectedMatchType||void 0===this.conditionIdx)return;const e=ca(this.selectedEntity,this.hass,this.config.customize);if(!no(this.conditionValue,e))return;this.conditionValid=!0;const t={entity_id:this.selectedEntity,match_type:this.selectedMatchType,value:this.conditionValue,attribute:"state"},i=Object.assign(this.schedule.entries[0].slots[0].conditions.items,{[this.conditionIdx]:t}),s=e=>Object.assign(e,{conditions:Object.assign(Object.assign({},e.conditions),{items:i})});this.schedule=Object.assign(Object.assign({},this.schedule),{entries:this.schedule.entries.map(e=>Object.assign(e,{slots:e.slots.map(s)}))})}_conditionAddClick(e){this._showConditionDialog(e).then(e=>{e&&(this.conditionIdx=this.schedule.entries[0].slots[0].conditions.items.length,this.selectedDomain=e,this.selectedEntity=void 0,this.selectedMatchType=void 0,this.conditionValue=void 0,this.conditionValid=!1)})}_conditionConfigOptionsClick(e){let t=Object.assign({},this.schedule.entries[0].slots[0].conditions);switch(e.detail.item.value){case"or":if(t.type==_e.Or)return;t=Object.assign(Object.assign({},t),{type:_e.Or});break;case"and":if(t.type==_e.And)return;t=Object.assign(Object.assign({},t),{type:_e.And});break;case"track_changes":const e=!this.schedule.entries[0].slots[0].conditions.track_changes;t=Object.assign(Object.assign({},t),{track_changes:e})}const i=e=>Object.assign(e,{conditions:t});this.schedule=Object.assign(Object.assign({},this.schedule),{entries:this.schedule.entries.map(e=>Object.assign(e,{slots:e.slots.map(i)}))})}_setStartDate(e){const t=String(e.detail.value);if(!t)return;oo(t)>oo(this.endDate)&&(this.schedule=Object.assign(Object.assign({},this.schedule),{end_date:t}),this.endDate=t),this.schedule=Object.assign(Object.assign({},this.schedule),{start_date:t}),this.startDate=t}_setEndDate(e){const t=String(e.detail.value);if(!t)return;oo(this.startDate)>oo(t)&&(this.schedule=Object.assign(Object.assign({},this.schedule),{start_date:t}),this.startDate=t),this.schedule=Object.assign(Object.assign({},this.schedule),{end_date:t}),this.endDate=t}toggleEnableDateRange(e){const t=e.target.checked;this.schedule=Object.assign(Object.assign({},this.schedule),{start_date:t?this.startDate:void 0,end_date:t?this.endDate:void 0,repeat_type:t?this.schedule.repeat_type==fe.Repeat?fe.Pause:this.schedule.repeat_type:this.schedule.repeat_type==fe.Pause?fe.Repeat:this.schedule.repeat_type})}updateName(e){const t=e.target.value;this.schedule=Object.assign(Object.assign({},this.schedule),{name:t.trim()})}tagsUpdated(e){let t=e.detail.value;t=t.map(e=>e.trim()),t=t.filter(e=>!["none","disabled","enabled"].includes(e)),this.schedule=Object.assign(Object.assign({},this.schedule),{tags:t})}_customTagConfirmClick(e){let t=e.target;t=t.parentElement,t=t.parentElement;t.querySelector("ha-button").click(),e.preventDefault();const i=String(this.customTagValue).trim();if(i.length){let e=this.schedule.tags||[];e=[...new Set([...e,i])],e=e.filter(e=>!["none","disabled","enabled"].includes(e)),this.schedule=Object.assign(Object.assign({},this.schedule),{tags:e})}this.customTagValue=""}setRepeatType(e){const t=e.target.getAttribute("value");this.schedule=Object.assign(Object.assign({},this.schedule),{repeat_type:t})}static get styles(){return r`
      ha-icon-button {
        align-self: center;
      }
      ha-dropdown-item[disabled] ha-icon {
        color: var(--disabled-text-color);
      }
      ha-dropdown-item[noninteractive] {
        background-color: rgba(var(--rgb-primary-color), 0.12);
        color: var(--sidebar-selected-text-color);
      }
      ha-dropdown-item[noninteractive] ha-icon {
        color: var(--sidebar-selected-text-color);
      }
      div.period {
        display: flex;
        width: 100%;
        flex-direction: row;
        align-items: center;
        gap: 5px;
      }
      div.period > div {
        display: flex;
      }
      div.period > div.input {
        position: relative;
        overflow: hidden;
        flex: 1;
      }
      ha-date-input,
      ha-input {
        width: 100%;
      }
      .header {
        display: flex;
        margin-top: 5px;
        width: 100%;
        align-items: center;
      }
      .header.first {
        margin-top: 0px;
        padding-bottom: 4px;
        align-items: flex-end;
        justify-content: space-between;
      }
      .header > * {
        display: flex;
      }
      .header ha-dropdown {
        margin-bottom: -10px;
      }
    `}};t([le({attribute:!1})],uo.prototype,"hass",void 0),t([le({attribute:!1})],uo.prototype,"config",void 0),t([ce()],uo.prototype,"schedule",void 0),t([ce()],uo.prototype,"conditionIdx",void 0),t([ce()],uo.prototype,"selectedDomain",void 0),t([ce()],uo.prototype,"selectedEntity",void 0),t([ce()],uo.prototype,"selectedMatchType",void 0),t([ce()],uo.prototype,"conditionValue",void 0),t([ce()],uo.prototype,"conditionValid",void 0),t([ce()],uo.prototype,"startDate",void 0),t([ce()],uo.prototype,"endDate",void 0),t([le()],uo.prototype,"tags",void 0),t([ce()],uo.prototype,"customTagValue",void 0),uo=t([re("scheduler-options-panel")],uo);let ho=class extends oe{async showDialog(e){this._params=e,await this.updateComplete}async closeDialog(){this._params&&this._params.cancel(),this._params=void 0}render(){return this._params?q`
      <ha-dialog open @closed=${this.closeDialog} width="small">
        <ha-dialog-header slot="header">
          <ha-icon-button
            slot="navigationIcon"
            data-dialog="close"
            .label=${ns("ui.dialogs.more_info_control.dismiss",this.hass)}
            .path=${Ws}
          ></ha-icon-button>
          <div slot="title">${this._params.title}</div>
        </ha-dialog-header>
        <div class="wrapper">${this._params.description}</div>

        <ha-dialog-footer slot="footer">
          ${this._params.secondaryButtonLabel?q`
                  <ha-button appearance="plain" slot="secondaryAction" @click=${this.cancelClick} data-dialog="close">
                    ${this._params.secondaryButtonLabel}
                  </ha-button>
                `:""}
          <ha-button appearance="accent" slot="primaryAction" @click=${this.confirmClick} data-dialog="close">
            ${this._params.primaryButtonLabel}
          </ha-button>
        </ha-dialog-footer>
      </ha-dialog>
    `:q``}confirmClick(){this._params.confirm()}cancelClick(){this._params.cancel()}};t([le({attribute:!1})],ho.prototype,"hass",void 0),t([ce()],ho.prototype,"_params",void 0),ho=t([re("scheduler-generic-dialog")],ho);var mo=Object.freeze({__proto__:null,get GenericDialog(){return ho}});let po=class extends oe{constructor(){super(...arguments),this.large=!1,this.selectedEntry=0,this.selectedSlot=null,this._panel="main",this._viewMode=me.Single}set viewMode(e){if(this._viewMode=e,e==me.Single){const e=this.schedule.entries[this.selectedEntry].slots.findIndex(e=>e.actions.length);this.selectedSlot=e>=0?e:1}}shouldUpdate(e){return 1!=e.size||!e.has("hass")||!Ze(this.hass)}async showDialog(e){var t;this._params=e,this.schedule=e.schedule,this._panel="main",this.large=!1;const i=this.schedule.entries[this.selectedEntry].slots.filter(e=>e.actions.length&&Ze(e.stop)).length>0||this.schedule.entries[this.selectedEntry].slots.filter(e=>e.actions.length).length>1||this.schedule.entries[this.selectedEntry].slots.length>3,s=this.schedule.entries[this.selectedEntry].slots.findIndex(e=>e.actions.length);this.selectedSlot=s>=0?s:null,this.viewMode=i?me.Scheme:(null===(t=this._params)||void 0===t?void 0:t.cardConfig.default_editor)||me.Single,await this.updateComplete}async closeDialog(){this._params=void 0}willUpdate(){this.hass.loadBackendTranslation("config")}render(){var e;return this._params?q`
      <ha-dialog open @closed=${this.closeDialog} width="${this.large?"full":"medium"}" prevent-scrim-close>
        <ha-dialog-header slot="header">
          ${"main"==this._panel?q`
                  <ha-icon-button
                    slot="navigationIcon"
                    data-dialog="close"
                    .label=${ns("ui.dialogs.more_info_control.dismiss",this.hass)}
                    .path=${Ws}
                  ></ha-icon-button>
                  <ha-icon-button
                    slot="actionItems"
                    .label=""
                    .path=${"M12,8A4,4 0 0,1 16,12A4,4 0 0,1 12,16A4,4 0 0,1 8,12A4,4 0 0,1 12,8M12,10A2,2 0 0,0 10,12A2,2 0 0,0 12,14A2,2 0 0,0 14,12A2,2 0 0,0 12,10M10,22C9.75,22 9.54,21.82 9.5,21.58L9.13,18.93C8.5,18.68 7.96,18.34 7.44,17.94L4.95,18.95C4.73,19.03 4.46,18.95 4.34,18.73L2.34,15.27C2.21,15.05 2.27,14.78 2.46,14.63L4.57,12.97L4.5,12L4.57,11L2.46,9.37C2.27,9.22 2.21,8.95 2.34,8.73L4.34,5.27C4.46,5.05 4.73,4.96 4.95,5.05L7.44,6.05C7.96,5.66 8.5,5.32 9.13,5.07L9.5,2.42C9.54,2.18 9.75,2 10,2H14C14.25,2 14.46,2.18 14.5,2.42L14.87,5.07C15.5,5.32 16.04,5.66 16.56,6.05L19.05,5.05C19.27,4.96 19.54,5.05 19.66,5.27L21.66,8.73C21.79,8.95 21.73,9.22 21.54,9.37L19.43,11L19.5,12L19.43,13L21.54,14.63C21.73,14.78 21.79,15.05 21.66,15.27L19.66,18.73C19.54,18.95 19.27,19.04 19.05,18.95L16.56,17.95C16.04,18.34 15.5,18.68 14.87,18.93L14.5,21.58C14.46,21.82 14.25,22 14,22H10M11.25,4L10.88,6.61C9.68,6.86 8.62,7.5 7.85,8.39L5.44,7.35L4.69,8.65L6.8,10.2C6.4,11.37 6.4,12.64 6.8,13.8L4.68,15.36L5.43,16.66L7.86,15.62C8.63,16.5 9.68,17.14 10.87,17.38L11.24,20H12.76L13.13,17.39C14.32,17.14 15.37,16.5 16.14,15.62L18.57,16.66L19.32,15.36L17.2,13.81C17.6,12.64 17.6,11.37 17.2,10.2L19.31,8.65L18.56,7.35L16.15,8.39C15.38,7.5 14.32,6.86 13.12,6.62L12.75,4H11.25Z"}
                    @click=${()=>{this._panel="options"}}
                  ></ha-icon-button>
                `:q`
                  <ha-icon-button
                    slot="navigationIcon"
                    .label=${ns("ui.dialogs.more_info_control.dismiss",this.hass)}
                    .path=${"M20,11V13H8L13.5,18.5L12.08,19.92L4.16,12L12.08,4.08L13.5,5.5L8,11H20Z"}
                    @click=${()=>{this._panel="main"}}
                  ></ha-icon-button>
                `}
          <div slot="title" @click=${()=>this.large=!this.large}>
            ${this._params.editItem?this.schedule.name?null===(e=this.schedule)||void 0===e?void 0:e.name:Ji("ui.panel.common.default_name",this.hass,"{id}",this._params.editItem):Ji("ui.panel.common.new_schedule",this.hass)}
          </div>
        </ha-dialog-header>

        <div class="content">
          ${"main"==this._panel?q`
                  <scheduler-main-panel
                    .hass=${this.hass}
                    .config=${this._params.cardConfig}
                    .schedule=${this.schedule}
                    .large=${this.large}
                    @change=${this._updateSchedule}
                    @setViewMode=${this._setViewMode}
                    .viewMode=${this._viewMode}
                    .selectedSlot=${this.selectedSlot}
                  >
                  </scheduler-main-panel>
                `:q`
                  <scheduler-options-panel
                    .hass=${this.hass}
                    .config=${this._params.cardConfig}
                    .schedule=${this.schedule}
                    @change=${this._updateSchedule}
                  >
                  </scheduler-options-panel>
                `}
        </div>

        <div class="buttons" slot="footer">
          <ha-button
            appearance="plain"
            @click=${this._handleDeleteClick}
            variant="danger"
            ?disabled=${!this.schedule.entity_id}
          >
            ${ns("ui.common.delete",this.hass)}
          </ha-button>
          <ha-button appearance="plain" @click=${this._handleSaveClick}>
            ${ns("ui.common.save",this.hass)}
          </ha-button>
        </div>
      </ha-dialog>
    `:q``}_updateSchedule(e){const t=Object.keys(e.detail);if(t.includes("schedule")){const t=e.detail.schedule;this.schedule=t}t.includes("selectedSlot")&&(this.selectedSlot=e.detail.selectedSlot)}async _handleSaveClick(e){const t=Aa(this.schedule,this.hass,this._params.cardConfig.customize);if(t)await new Promise(i=>{const s={cancel:()=>i(!1),confirm:()=>i(!0),title:ns("state_badge.default.error",this.hass),description:Ji(`ui.panel.editor.validation_errors.${t}`,this.hass),primaryButtonLabel:ns("ui.common.ok",this.hass)};Vs(e.target,"show-dialog",{dialogTag:"scheduler-generic-dialog",dialogImport:()=>Promise.resolve().then(function(){return mo}),dialogParams:s})});else if(this.schedule.schedule_id){const t=qe(await Rs(this.hass,this.schedule.schedule_id),this.hass);if(he(this.schedule,t))return void this.closeDialog();if(!t.enabled){await new Promise(t=>{const i={title:Ji("ui.dialog.enable_schedule.title",this.hass),description:Ji("ui.dialog.enable_schedule.description",this.hass),primaryButtonLabel:ns("ui.common.yes",this.hass),secondaryButtonLabel:ns("ui.common.no",this.hass),cancel:()=>{t(!1)},confirm:()=>{t(!0)}};Vs(e.target,"show-dialog",{dialogTag:"scheduler-generic-dialog",dialogImport:()=>Promise.resolve().then(function(){return mo}),dialogParams:i})})&&this.hass.callService("switch","turn_on",{entity_id:t.entity_id})}((e,t)=>{const i=Ea(t);return e.callApi("POST","scheduler/edit",i)})(this.hass,this.schedule).catch(e=>La(e,this,this.hass)).then(()=>{this.closeDialog()})}else((e,t)=>{const i=Ea(t);return e.callApi("POST","scheduler/add",i)})(this.hass,this.schedule).catch(e=>La(e,this,this.hass)).then(()=>{this.closeDialog()})}async _handleDeleteClick(e){await new Promise(t=>{const i={cancel:()=>t(!1),confirm:()=>t(!0),title:Ji("ui.dialog.confirm_delete.title",this.hass),description:Ji("ui.dialog.confirm_delete.description",this.hass),primaryButtonLabel:ns("ui.common.ok",this.hass),secondaryButtonLabel:ns("ui.common.cancel",this.hass)};Vs(e.target,"show-dialog",{dialogTag:"scheduler-generic-dialog",dialogImport:()=>Promise.resolve().then(function(){return mo}),dialogParams:i})}).then(e=>{var t,i;e&&(t=this.hass,i=this._params.editItem,t.callApi("POST","scheduler/remove",{schedule_id:i})).catch(e=>La(e,this,this.hass)).then(()=>{this.closeDialog()})})}_setViewMode(e){const t=e.detail,i=this.schedule.entries[this.selectedEntry].slots.filter(e=>e.actions.length).length>1;if(t==me.Scheme){this.viewMode=t;if(he([...this.schedule.entries],[...We.entries]))this.schedule=Object.assign(Object.assign({},this.schedule),{entries:[...Be.entries]});else{const e=this.schedule.entries.some(e=>e.slots.some(e=>void 0===e.stop));e&&(this.schedule=Object.assign(Object.assign({},this.schedule),{entries:this.schedule.entries.map(e=>Object.assign(Object.assign({},e),{slots:e.slots.map((e,t,i)=>{if(void 0!==e.stop)return e;const s=i[t+1];return Object.assign(Object.assign({},e),{stop:s?s.start:"00:00:00"})})}))}))}return}if(t==me.Single&&!i){if(he([...this.schedule.entries],[...Be.entries]))this.schedule=Object.assign(Object.assign({},this.schedule),{entries:[...We.entries]});else{const e=Object.assign(Object.assign({},this.schedule),{entries:this.schedule.entries.map(e=>{let t=e.slots.findIndex(e=>e.actions.length);return t<0&&(t=Math.floor(e.slots.length/2)),Object.assign(Object.assign({},e),{slots:e.slots.map((e,i)=>i==t?Object.assign(Object.assign({},e),{stop:void 0}):null).filter(Ze)})})});this.schedule=qe(e,this.hass)}return void(this.viewMode=t)}new Promise(t=>{const i={title:Ji("ui.dialog.confirm_migrate.title",this.hass),description:Ji("ui.dialog.confirm_migrate.description",this.hass),primaryButtonLabel:this.hass.localize("ui.common.yes"),secondaryButtonLabel:this.hass.localize("ui.common.no"),cancel:()=>{t(!1)},confirm:()=>{t(!0)}};Vs(e.target,"show-dialog",{dialogTag:"scheduler-generic-dialog",dialogImport:()=>Promise.resolve().then(function(){return mo}),dialogParams:i})}).then(e=>{e&&(this.schedule=(e=>{const t=e=>{let t=e.findIndex(e=>e.actions.length);t<0&&(t=Math.floor(e.length/2));let i=Object.assign(Object.assign({},e[t]),{stop:void 0});const s=i.conditions,a=i.start;return[{start:"00:00:00",stop:a,actions:[],conditions:s},i,{start:Ie(Se(Ce(a),{minutes:1})),stop:"00:00:00",actions:[],conditions:s}]};return e=Object.assign(Object.assign({},e),{entries:e.entries.map(e=>Object(Object.assign(Object.assign({},e),{slots:t(e.slots)})))}),e})(this.schedule),this.viewMode=t)})}};po.styles=Sa,t([le({attribute:!1})],po.prototype,"hass",void 0),t([ce()],po.prototype,"_params",void 0),t([le({type:Boolean,reflect:!0})],po.prototype,"large",void 0),t([ce()],po.prototype,"schedule",void 0),t([ce()],po.prototype,"selectedEntry",void 0),t([ce()],po.prototype,"selectedSlot",void 0),t([ce()],po.prototype,"_panel",void 0),t([ce()],po.prototype,"_viewMode",void 0),po=t([re("dialog-scheduler-editor")],po);var _o=Object.freeze({__proto__:null,get DialogSchedulerEditor(){return po}});
/**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */class go extends ia{constructor(e){if(super(e),this.et=V,e.type!==ea)throw Error(this.constructor.directiveName+"() can only be used in child bindings")}render(e){if(e===V||null==e)return this.ft=void 0,this.et=e;if(e===R)return e;if("string"!=typeof e)throw Error(this.constructor.directiveName+"() called with a non-string value");if(e===this.et)return this.ft;this.et=e;const t=[e];return t.raw=t,this.ft={_$litType$:this.constructor.resultType,strings:t,values:[]}}}go.directiveName="unsafeHTML",go.resultType=1;const vo=ta(go);var yo=window&&window.__assign||function(){return yo=Object.assign||function(e){for(var t,i=1,s=arguments.length;i<s;i++)for(var a in t=arguments[i])Object.prototype.hasOwnProperty.call(t,a)&&(e[a]=t[a]);return e},yo.apply(this,arguments)};var fo={second:45,minute:45,hour:22,day:5};const bo=(e,t,i,s)=>{const a=Cs(e,i);if(s===Te.am_pm||!s&&t.time_format===Te.am_pm){const e=Ne(a.hours).am_pm;return`${Ne(a.hours).hours}:${String(a.minutes).padStart(2,"0")} ${e}`}return s===Te.twenty_four||!s&&t.time_format===Te.twenty_four?`${String(a.hours).padStart(2,"0")}:${String(a.minutes).padStart(2,"0")}`:(()=>{try{(new Date).toLocaleTimeString("i")}catch(e){return"RangeError"===e.name}return!1})()?e.toLocaleTimeString(t.language,{hour:"numeric",minute:"2-digit",hour12:Me(t),timeZone:i}):Me(t)?bo(e,t,i,Te.am_pm):bo(e,t,i,Te.twenty_four)};let wo=class extends oe{constructor(){super(...arguments),this.updateInterval=60,this.timer=0}startRefreshTimer(e){clearInterval(this.timer),this.timer=window.setInterval(()=>{this.requestUpdate()},1e3*e),this.updateInterval=e}set hass(e){this._hass=e,this.startRefreshTimer(this.updateInterval)}relativeTime(e){if(!this._hass)return"";const t=new Date,i=zs(this._hass);let s=(t.getTime()-e.getTime())/1e3;const a=s>=0?"past":"future";s=Math.abs(s);const o=Math.round(s);if("future"==a&&o>0){if(s/3600>=6){const s=Cs(t,i),a=Cs(e,i),o=Math.round((Date.UTC(a.year,a.month-1,a.day)-Date.UTC(s.year,s.month-1,s.day))/864e5);let n="";o>14?n=function(e,t,i){const s=()=>{try{(new Date).toLocaleDateString("i")}catch(e){return"RangeError"===e.name}return!1},a=(e,t)=>{switch(t){case"year":return e.getFullYear();case"month":return so[e.getMonth()];case"day":return e.getDate()}};return Cs(e,i).year==Cs(new Date,i).year?s()?new Intl.DateTimeFormat(t.language,{month:"long",day:"numeric",timeZone:i}).format(e):`${a(e,"month")} ${a(e,"day")}`:s()?new Intl.DateTimeFormat(t.language,{year:"numeric",month:"long",day:"numeric",timeZone:i}).format(e):`${a(e,"month")} ${a(e,"day")}, ${a(e,"year")}`}(e,this._hass.locale,i):o>7?n=Ji("ui.components.date.next_week_day",this._hass,"{weekday}",Ts(e,"long",this._hass)):1==o?n=Ji("ui.components.date.tomorrow",this._hass):o>0&&(n=Ts(e,"long",this._hass));let r=Ji("ui.components.time.absolute",this._hass,"{time}",bo(e,this._hass.locale,i));return 12==a.hours&&0==a.minutes?r=Ji("ui.components.time.at_noon",this._hass):0==a.hours&&0==a.minutes&&(r=Ji("ui.components.time.at_midnight",this._hass)),String(n+" "+r).trim()}if(Math.round(s/60)>60&&Math.round(s/60)<120){const e=Math.round(s/60-60),t=ns("ui.common.and",this._hass);return`${new Intl.RelativeTimeFormat(this._hass.language,{numeric:"auto"}).format(1,"hour")} ${t} ${Intl.NumberFormat(this._hass.locale.language,{style:"unit",unit:"minute",unitDisplay:"long"}).format(e)}`}if(Math.round(s)>60&&Math.round(s)<120){const e=Math.round(s-60),t=ns("ui.common.and",this._hass);return`${new Intl.RelativeTimeFormat(this._hass.language,{numeric:"auto"}).format(1,"minute")} ${t} ${Intl.NumberFormat(this._hass.locale.language,{style:"unit",unit:"second",unitDisplay:"long"}).format(e)}`}}const n=function(e,t,i){void 0===t&&(t=Date.now()),void 0===i&&(i={});var s=yo(yo({},fo),i||{}),a=(+e-+t)/1e3;if(Math.abs(a)<s.second)return{value:Math.round(a),unit:"second"};var o=a/60;if(Math.abs(o)<s.minute)return{value:Math.round(o),unit:"minute"};var n=a/3600;if(Math.abs(n)<s.hour)return{value:Math.round(n),unit:"hour"};var r=a/86400;if(Math.abs(r)<s.day)return{value:Math.round(r),unit:"day"};var d=new Date(e),l=new Date(t),c=d.getFullYear()-l.getFullYear();if(Math.round(Math.abs(c))>0)return{value:Math.round(c),unit:"year"};var u=12*c+d.getMonth()-l.getMonth();if(Math.round(Math.abs(u))>0)return{value:Math.round(u),unit:"month"};var h=a/604800;return{value:Math.round(h),unit:"week"}}(e);return new Intl.RelativeTimeFormat(this._hass.language,{numeric:"auto"}).format(n.value,n.unit)}render(){if(!this._hass||!this.datetime)return q``;const e=new Date,t=Math.round((this.datetime.valueOf()-e.valueOf())/1e3);let i=60;return Math.abs(t)<=150&&(i=Math.max(Math.ceil(Math.abs(t))/10,2)),this.updateInterval!=i&&this.startRefreshTimer(i),q` ${os(this.relativeTime(this.datetime))} `}};t([le()],wo.prototype,"_hass",void 0),t([le()],wo.prototype,"datetime",void 0),wo=t([re("scheduler-relative-time")],wo);let ko=class extends oe{render(){var e,t,i,s,a;try{const o=this.hass.states[this.schedule.entity_id];if(!o)return q``;const n=["off","completed"].includes(o.state),r=this.schedule.entries[0].slots[this.schedule.next_entries[0]||0].actions[0];let d=Pa(r,this.config.customize);if("entity"==(null===(e=this.config.display_options)||void 0===e?void 0:e.icon)){let e=[(null===(t=r.target)||void 0===t?void 0:t.entity_id)||[]].flat().shift();["script","notify"].includes(Xi(r.service))&&(e=r.service),e&&(d=ha(e,this.config.customize,this.hass))}const l=![(null===(i=r.target)||void 0===i?void 0:i.entity_id)||[]].flat().every(e=>Object.keys(this.hass.states).includes(e));return l&&(d="mdi:help"),q`
        <ha-icon icon="${d}" @click=${this._handleIconClick} class="${n?"disabled":""}"></ha-icon>

        <div
          class="info ${n?"disabled":""} ${l?"defective":""}"
          @click=${this._handleItemClick}
        >
          ${this.renderDisplayItem((null===(s=this.config.display_options)||void 0===s?void 0:s.primary_info)||Ve)}
          <div class="secondary">
            ${this.renderDisplayItem((null===(a=this.config.display_options)||void 0===a?void 0:a.secondary_info)||He)}
          </div>
        </div>
        <div class="state">
          ${!1!==this.config.show_toggle_switches?q`<ha-switch
                  ?checked=${["on","triggered"].includes(o.state||"")}
                  ?disabled=${"completed"==o.state}
                  @change=${this._toggleEnableDisable}
                ></ha-switch>`:""}
        </div>
      `}catch(e){return q`
        <hui-warning .hass=${this.hass} @click=${this._handleItemClick}>
          <span style="white-space: normal"> Failed to display schedule ${this.schedule.entity_id}. Reason: ${e} </span>
        </hui-warning>
      `}}renderDisplayItem(e){const t=e=>{const t=e.split("<relative-time></relative-time>");if(t.length>1){const e=this.schedule.timestamps[this.schedule.next_entries[0]||0];return q`
          ${t[0]?vo(t[0]):""}
          <scheduler-relative-time .hass=${this.hass} .datetime=${new Date(e)}> </scheduler-relative-time>
          ${t[1]?vo(t[1]):""}
        `}if(null!==e.match(/^(<tag>[^<]*<\/tag>)+$/)){const t=e.split(/<tag>([^<]*)<\/tag>/).filter(e=>e);return q` <div class="tags">${null==t?void 0:t.map(e=>q`<span class="tag">${e}</span>`)}</div>`}return vo(e)};return Ps(this.schedule,e,this.hass,this.config.customize).filter(e=>e.length).map(e=>q`${t(e)}<br />`)}_handleItemClick(e){const t=new CustomEvent("editClick",{detail:{schedule_id:this.schedule_id}});this.dispatchEvent(t)}_handleIconClick(e){const t=new CustomEvent("editClick",{detail:{schedule_id:this.schedule_id}});this.dispatchEvent(t)}_toggleEnableDisable(e){const t=e.target.checked;this.hass.callService("switch",t?"turn_on":"turn_off",{entity_id:this.schedule.entity_id})}static get styles(){return r`
      :host {
        display: flex;
        align-items: center;
        flex-direction: row;
      }
      .info {
        margin-left: 16px;
        margin-right: 8px;
        margin-inline-start: 16px;
        margin-inline-end: 8px;
        flex: 1 1 30%;
        transition: color 0.2s ease-in-out;
        cursor: pointer;
        line-height: var(--ha-line-height-normal);
      }
      .info,
      .info > * {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .flex ::slotted(*) {
        margin-left: 8px;
        margin-inline-start: 8px;
        margin-inline-end: initial;
        min-width: 0;
      }
      .flex ::slotted([slot='secondary']) {
        margin-left: 0;
        margin-inline-start: 0;
        margin-inline-end: initial;
      }
      .secondary,
      ha-relative-time {
        color: var(--secondary-text-color);
        transition: color 0.2s ease-in-out;
      }
      .state {
        text-align: var(--float-end);
      }
      .value {
        direction: ltr;
      }
      ha-icon {
        display: flex;
        flex: 0 0 40px;
        color: var(--state-icon-color);
        transition: color 0.2s ease-in-out;
        cursor: pointer;
        align-items: center;
        justify-content: center;
      }
      ha-icon.disabled {
        color: var(--disabled-text-color);
      }
      div.disabled {
        --primary-text-color: var(--disabled-text-color);
        --secondary-text-color: var(--disabled-text-color);
        --state-icon-color: var(--disabled-text-color);
        color: var(--disabled-text-color);
      }
      div.tags {
        display: flex;
        gap: 5px;
        flex-wrap: wrap;
      }
      span.tag {
        height: 28px;
        border-radius: 14px;
        background: rgba(var(--rgb-primary-color), 0.4);
        color: var(--primary-text-color);
        line-height: 1.25rem;
        font-size: 0.875rem;
        padding: 0px 12px;
        display: flex;
        align-items: center;
        box-sizing: border-box;
      }
      .defective {
        text-decoration: line-through;
      }
    `}};return t([le()],ko.prototype,"hass",void 0),t([le()],ko.prototype,"schedule_id",void 0),t([le()],ko.prototype,"schedule",void 0),t([le()],ko.prototype,"config",void 0),ko=t([re("scheduler-item-row")],ko),e.SchedulerCard=class extends oe{constructor(){super(...arguments),this._config={},this.showDiscovered=!1,this.translationsLoaded=!1,this.connectionError=!1}async setConfig(e){e=(e=>{const t=[];if(Ke(e,"include")&&!Xe(e.include)&&t.push("'include' must be a list of strings"),Ke(e,"exclude")&&!Xe(e.exclude)&&t.push("'exclude' must be a list of strings"),Ke(e,"discover_existing")&&!Ge(e.discover_existing)&&t.push("'discover_existing' must be a boolean"),!Ke(e,"title")||Ge(e.title)||Ye(e.title)||t.push("'title' must be a boolean or string"),Ke(e,"time_step")&&(!Je(e.time_step)||Number(e.time_step)<1||Number(e.time_step)>30)&&t.push("'time_step' must be a number between 1 and 30"),Ke(e,"show_header_toggle")&&!Ge(e.show_header_toggle)&&t.push("'show_header_toggle' must be a boolean"),Ke(e,"show_add_button")&&!Ge(e.show_add_button)&&t.push("'show_add_button' must be a boolean"),Ke(e,"show_toggle_switches")&&!Ge(e.show_toggle_switches)&&t.push("'show_toggle_switches' must be a boolean"),Ke(e,"display_options")&&(Qe(e.display_options)?(!Ke(e.display_options,"primary_info")||Ye(e.display_options.primary_info)||Xe(e.display_options.primary_info)||t.push("in 'display_options': 'primary_info' must be a string or list of strings"),!Ke(e.display_options,"secondary_info")||Ye(e.display_options.secondary_info)||Xe(e.display_options.secondary_info)||t.push("in 'display_options': 'secondary_info' must be a string or list of strings"),!Ke(e.display_options,"icon")||Ye(e.display_options.icon)&&["action","entity"].includes(e.display_options.icon)||t.push("in 'display_options': 'icon' must be a set to either 'action' or 'entity' ")):t.push("'display_options' must be a struct")),!Ke(e,"sort_by")||Ye(e.sort_by)||Xe(e.sort_by)||t.push("'sort_by' must be a string or list of strings"),Ke(e,"customize")&&!Qe(e.customize))t.push("'customize' must be a struct");else if(Ke(e,"customize")){const i=Object.entries(e.customize).map(([e,t])=>et(e,t)).filter(Ze);i.length&&t.push(...i)}if(!Ke(e,"tags")||Ye(e.tags)||Xe(e.tags)||t.push("'tags' must be a string or list of strings"),!Ke(e,"exclude_tags")||Ye(e.exclude_tags)||Xe(e.exclude_tags)||t.push("'exclude_tags' must be a string or list of strings"),t.length)throw new Error(`Invalid configuration provided (${t.length} error${t.length>1?"s":""}): ${t.join(", ")}.`);return e})(e),this._config=Object.assign({},e)}async firstUpdated(){await(async()=>{if(customElements.get("ha-checkbox")&&customElements.get("ha-slider")&&customElements.get("ha-generic-picker"))return;await customElements.whenDefined("partial-panel-resolver");const e=document.createElement("partial-panel-resolver");e.hass={panels:[{url_path:"tmp",component_name:"config"}]},e._updateRoutes(),await e.routerOptions.routes.tmp.load(),await customElements.whenDefined("ha-panel-config");const t=document.createElement("ha-panel-config");await t.routerOptions.routes.automation.load()})();document.querySelector("home-assistant")._loadFragmentTranslations(this.hass.language,"config"),await Hs(this.hass).then(e=>{e=Object.fromEntries(Object.entries(e).filter(([e])=>is(e,this._config))),this._config=Object.assign(Object.assign({},this._config),{customize:Object.assign(Object.assign({},e),this._config.customize||{})})})}willUpdate(){this.hass.loadBackendTranslation("services")}__checkSubscribed(){void 0===this.__unsubs&&this.isConnected&&void 0!==this.hass&&(this.__unsubs=this.hassSubscribe())}connectedCallback(){super.connectedCallback(),this.__checkSubscribed()}disconnectedCallback(){if(super.disconnectedCallback(),this.__unsubs){for(;this.__unsubs.length;){const e=this.__unsubs.pop();e instanceof Promise?e.then(e=>e()):e()}this.__unsubs=void 0}}updated(e){super.updated(e),e.has("hass")&&this.__checkSubscribed()}hassSubscribe(){return this.loadSchedules(),[this.hass.connection.subscribeMessage(e=>this.handleScheduleItemUpdated(e),{type:"scheduler_updated"})]}shouldUpdate(e){const t=e.get("hass"),i=e.get("_config");if(i&&this._config){const e=Object.keys(i).filter(e=>i[e]!==this._config[e]);e.some(e=>["tags","discover_existing","sort_by","display_options"].includes(e))&&(async()=>{await this.loadSchedules()})()}return!this.translationsLoaded&&ns("component.input_boolean.services.turn_on.name",this.hass,!1).length&&ns("ui.panel.config.automation.editor.conditions.type.sun.sunrise",this.hass,!1).length?(this.translationsLoaded=!0,!0):!t||1!=e.size||!this.schedules||Object.values(this.schedules).some(e=>JSON.stringify(t.states[e.entity_id])!==JSON.stringify(this.hass.states[e.entity_id]))}render(){let e=[...this.schedules||[]],t=e.filter(e=>ss(e,this._config)),i=e.filter(e=>!ss(e,this._config));const s=this.showDiscovered?e.some(e=>{var t;return["on","triggered"].includes((null===(t=this.hass.states[e.entity_id])||void 0===t?void 0:t.state)||"")}):t.some(e=>{var t;return["on","triggered"].includes((null===(t=this.hass.states[e.entity_id])||void 0===t?void 0:t.state)||"")});return q`
      <ha-card>
        <div class="card-header">
          <div class="name">
            ${!Ze(this._config.title)||"boolean"==typeof this._config.title&&this._config.title?Ji("ui.panel.common.title",this.hass):"boolean"==typeof this._config.title?"":this._config.title}
          </div>

          ${Object.keys(this.schedules||{}).length&&this._config.show_header_toggle?q` <ha-switch ?checked=${s} @change=${this.toggleDisableAll}> </ha-switch> `:""}
        </div>

        <div class="card-content" id="states">
          ${this.connectionError?q`
                  <div>
                    <hui-warning .hass=${this.hass}>
                      <span style="white-space: normal">
                        ${Ji("ui.panel.overview.backend_error",this.hass)}
                      </span>
                    </hui-warning>
                  </div>
                `:Object.keys(e).length?t.map(e=>q`
                      <scheduler-item-row
                        .hass=${this.hass}
                        .config=${this._config}
                        .schedule_id=${e.schedule_id}
                        .schedule=${e}
                        @editClick=${t=>{this._handleEditClick(t,e)}}
                      >
                      </scheduler-item-row>
                    `):q` <div>${Ji("ui.panel.overview.no_entries",this.hass)}</div> `}
          ${Object.keys(e).length>t.length&&!1!==this._config.discover_existing?this.showDiscovered?q`
                    ${i.map(e=>q`
                        <scheduler-item-row
                          .hass=${this.hass}
                          .config=${this._config}
                          .schedule_id=${e.schedule_id}
                          .schedule=${e}
                          @editClick=${t=>{this._handleEditClick(t,e)}}
                        >
                        </scheduler-item-row>
                      `)}

                    <div>
                      <ha-button
                        appearance="plain"
                        @click=${()=>{this.showDiscovered=!1}}
                      >
                        ${Ji("ui.panel.overview.hide_excluded",this.hass)}
                      </ha-button>
                    </div>
                  `:q`
                    <div>
                      <ha-button
                        appearance="plain"
                        @click=${()=>{this.showDiscovered=!0}}
                      >
                        +
                        ${Ji("ui.panel.overview.excluded_items",this.hass,"{number}",Object.keys(e).length-t.length)}
                      </ha-button>
                    </div>
                  `:""}
        </div>
        ${!1!==this._config.show_add_button?q` <div class="card-actions">
                ${this.connectionError?q`
                        <ha-button appearance="plain" variant="warning" @click=${this._retryConnection}
                          >${ns("ui.common.refresh",this.hass)}
                        </ha-button>
                      `:q`
                        <ha-button appearance="plain" @click=${this._addClick}
                          >${ns("ui.common.add",this.hass)}
                        </ha-button>
                      `}
              </div>`:""}
      </ha-card>
    `}async loadSchedules(){Oe(this.hass).then(e=>{this.schedules=qs(e,this._config,this.hass)}).catch(e=>{this.schedules=[],this.connectionError=!0})}async getCardSize(){return new Promise(e=>{let t=0;const i=setInterval(()=>{var s;if(t++,!this._config||!this.schedules&&!this.connectionError&&t<50)return;let a=this._config.title||this._config.show_header_toggle?3:1;this._config.show_add_button&&(a+=1);const o=(([(null===(s=this._config.display_options)||void 0===s?void 0:s.secondary_info)||[]].flat().length||2)+1)/2;this.schedules&&(a+=this.showDiscovered?Object.keys(this.schedules).length*o:Object.values(this.schedules).filter(e=>ss(e,this._config)).length*o),clearInterval(i),e(Math.round(a))},50)})}_retryConnection(){setTimeout(async()=>{await this.loadSchedules()},100),this.connectionError=!1,this.requestUpdate()}async handleScheduleItemUpdated(e){"scheduler_item_removed"!=e.event?Rs(this.hass,e.schedule_id).then(t=>{const i=this.schedules.findIndex(t=>t.schedule_id==e.schedule_id),s=i>=0?this.schedules[i]:null;let a=[...this.schedules||[]];!t||!1===this._config.discover_existing&&!ss(t,this._config)?s&&(a=a.filter(t=>t.schedule_id!==e.schedule_id)):s?s.timestamps[s.next_entries[0]||0]==t.timestamps[t.next_entries[0]||0]?a=Object.assign(a,{[i]:t}):(a=Object.assign(a,{[i]:t}),a=qs(a,this._config,this.hass)):a=qs([...a,t],this._config,this.hass),this.schedules=[...a]}):this.schedules=(this.schedules||[]).filter(t=>t.schedule_id!==e.schedule_id)}_handleEditClick(e,t){if(!this.schedules)return;const i={schedule:qe(t,this.hass),cardConfig:this._config,editItem:t.schedule_id};Vs(e.target,"show-dialog",{dialogTag:"dialog-scheduler-editor",dialogImport:()=>Promise.resolve().then(function(){return _o}),dialogParams:i})}_addClick(e){const t=[this._config.tags||[]].flat().filter(e=>!["none","disabled","enabled"].includes(e));let i=this._config.default_editor==me.Scheme?JSON.parse(JSON.stringify(Be)):JSON.parse(JSON.stringify(We));const s={schedule:Object.assign(Object.assign({},i),{tags:1==t.length?t:[]}),cardConfig:this._config};Vs(this,"show-dialog",{dialogTag:"dialog-scheduler-editor",dialogImport:()=>Promise.resolve().then(function(){return _o}),dialogParams:s})}toggleDisableAll(e){if(!this.hass||!this.schedules)return;const t=e.target.checked,i=Object.values(this.schedules).filter(e=>this.showDiscovered||ss(e,this._config));i.forEach(e=>{this.hass.callService("switch",t?"turn_on":"turn_off",{entity_id:e.entity_id})})}static getConfigElement(){return document.createElement("scheduler-card-editor")}},e.SchedulerCard.styles=r`
    .card-header {
      display: flex;
      justify-content: space-between;
    }
    .card-header .name {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      display: flex;
    }
    .card-header ha-switch {
      display: flex;
      align-self: center;
      margin: 0px 6px;
      line-height: 24px;
    }

    #states > * {
      margin: 8px 0;
    }
    #states > *:first-child {
      margin-top: 0;
    }
    #states > *:last-child {
      margin-bottom: 0;
    }

    button.show-more {
      color: var(--primary-color);
      text-align: left;
      cursor: pointer;
      background: none;
      border-width: initial;
      border-style: none;
      border-color: initial;
      border-image: initial;
      font: inherit;
    }
    button.show-more:focus {
      outline: none;
      text-decoration: underline;
    }
    .card-actions,
    .card-actions > * {
      display: flex;
    }
  `,t([le({attribute:!1})],e.SchedulerCard.prototype,"hass",void 0),t([le()],e.SchedulerCard.prototype,"_config",void 0),t([ce()],e.SchedulerCard.prototype,"schedules",void 0),t([ce()],e.SchedulerCard.prototype,"showDiscovered",void 0),e.SchedulerCard=t([re("scheduler-card")],e.SchedulerCard),window.customCards=window.customCards||[],window.customCards.push({type:"scheduler-card",name:"Scheduler Card",description:"Card to manage schedule entities made with scheduler-component."}),console.info(`%c  SCHEDULER-CARD  \n%c  Version: ${"v4.0.20".padEnd(7," ")}`,"color: orange; font-weight: bold; background: black","color: white; font-weight: bold; background: dimgray"),e}({});
